import {env} from 'cloudflare:workers';
import {readCatalog,database} from '@/lib/store';
import {demoIntent,makePlan} from '@/lib/adapt';
import {interpret} from '@/lib/ai';
import {bodyOf,mealInput,sameOrigin,failure} from '@/lib/request';
export async function POST(request:Request){try{sameOrigin(request);const body=await bodyOf(request);const input=mealInput(body.input);const c=await readCatalog();const selected=typeof body.recipeId==='string'?body.recipeId:undefined;if(selected&&!c.recipes.some(r=>r.id===selected))throw new Error('선택한 원안이 없습니다.');const mode=body.mode==='demo'?'demo':'live';const key=(env as unknown as Record<string,string>).OPENAI_API_KEY;if(mode==='live'&&!key)throw new Error('AI 연결이 준비되지 않았습니다. 시연 모드를 선택해주세요.');const intent=mode==='live'?await interpret(input,c,key,selected):demoIntent(input,c);if(selected)intent.recipeId=selected;const plan=makePlan(input,intent,c,mode);await database().prepare('INSERT INTO plans(id,created_at,data) VALUES(?,?,?)').bind(plan.id,plan.createdAt,JSON.stringify({plan,intent})).run();return Response.json({plan})}catch(error){return failure(error)}}
