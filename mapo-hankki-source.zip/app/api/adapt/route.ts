import {env} from 'cloudflare:workers';
import {readCatalog,database} from '@/lib/store';
import {demoIntent,makePlan} from '@/lib/adapt';
import {interpret,AiInterpretError} from '@/lib/ai';
import {hasInput,hasSafetyRequest,originalIntent} from '@/lib/adaptation';
import type {AdaptResult} from '@/lib/api-types';
import {bodyOf,mealInput,sameOrigin,failure} from '@/lib/request';
export async function POST(request:Request){
 try{
  sameOrigin(request);const body=await bodyOf(request);const input=mealInput(body.input);const c=await readCatalog();
  const selected=typeof body.recipeId==='string'?body.recipeId:undefined;
  if(selected&&!c.recipes.some(r=>r.id===selected))throw new Error('선택한 원안이 없습니다.');
  const mode=(body.original===true||(!hasInput(input)&&!!selected))?'original':body.mode==='demo'?'demo':'live';
  let intent;
  if(mode==='original')intent=originalIntent(input,c,selected,body.discardConstraints);
  else if(mode==='live'){
   try{
    const config=env as unknown as Record<string,string>;
    const key=config.GEMINI_API_KEY||config.GOOGLE_API_KEY;
    if(!key)throw new AiInterpretError('unavailable');
    intent=await interpret(input,c,key,selected,config.GEMINI_MODEL||undefined);
   }catch(error){
    const issue=error instanceof AiInterpretError?error:new AiInterpretError('unavailable');
    return Response.json({plan:null,aiError:{code:issue.code,message:issue.message},fallbackAvailable:!hasSafetyRequest(input)} satisfies AdaptResult);
   }
  }else intent=demoIntent(input,c);
  if(selected)intent.recipeId=selected;
  const plan=makePlan(input,intent,c,mode);
  if(mode==='original'&&hasInput(input)&&!hasSafetyRequest(input))plan.warnings.push('원안 그대로 선택하여 입력한 변경 조건은 적용하지 않았습니다. 표시된 인분·재료·금액을 확인해주세요.');
  await database().prepare('INSERT INTO plans(id,created_at,data) VALUES(?,?,?)').bind(plan.id,plan.createdAt,JSON.stringify({plan,intent})).run();
  return Response.json({plan} satisfies AdaptResult);
 }catch(error){return failure(error)}
}
