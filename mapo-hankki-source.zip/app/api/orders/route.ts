import {database,readCatalog} from '@/lib/store';
import {makePlan} from '@/lib/adapt';
import {bodyOf,sameOrigin,failure} from '@/lib/request';
import {createWorkflowOrder,validateExtras,validatePickupSlot,validatePlanIds,workflowReceipt} from '@/lib/order-workflow';
import type {Plan,Intent} from '@/lib/catalog';
export async function POST(request:Request){try{
 sameOrigin(request);const b=await bodyOf(request),ids=validatePlanIds(b.planIds),slot=validatePickupSlot(b.slot),db=database(),c=await readCatalog(),plans:Plan[]=[];
 const extras=validateExtras(b.extras,c,b.sourceShopId);
 for(const id of ids){
  const consumed=await db.prepare("SELECT id FROM orders WHERE EXISTS(SELECT 1 FROM json_each(orders.data,'$.planIds') WHERE value=?) LIMIT 1").bind(id).first();if(consumed)throw new Error('이미 예약한 구성입니다. 새로운 한 끼를 만들어주세요.');
  const row=await db.prepare('SELECT data FROM plans WHERE id=?').bind(id).first<{data:string}>();if(!row)throw new Error('구성이 만료되었습니다. 다시 만들어주세요.');
  const saved=JSON.parse(row.data) as {plan:Plan;intent:Intent},r=c.recipes.find(r=>r.id===saved.plan.recipeId);if(saved.plan.blocked||!r||r.version!==saved.plan.recipeVersion)throw new Error('원안이 변경되었거나 확인이 필요합니다. 한 끼를 다시 만들어주세요.');
  const check=makePlan(saved.plan.input,saved.intent,c,saved.plan.mode);if(check.blocked||check.total!==saved.plan.total)throw new Error('상품 구성이 변경되었습니다. 한 끼를 다시 만들어주세요.');if(r.stock<=0)throw new Error('품절된 상품이 있습니다.');r.stock--;plans.push(saved.plan);
 }
 const order=createWorkflowOrder(plans,extras,c,slot,b.sourceShopId),receipt=workflowReceipt(order),oldRevision=c.revision;c.revision++;c.lastOrder=order.id;
 const stored={...receipt,createdAt:order.createdAt,planIds:ids,workflow:order};
 const result=await db.batch([
  db.prepare("UPDATE catalog_state SET revision=?,data=? WHERE id='main' AND revision=?").bind(c.revision,JSON.stringify(c),oldRevision),
  db.prepare("INSERT INTO orders(id,created_at,data) SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM catalog_state WHERE id='main' AND json_extract(data,'$.lastOrder')=?)").bind(order.id,order.createdAt,JSON.stringify(stored),order.id)
 ]);if(!result[0].meta.changes||!result[1].meta.changes)throw new Error('재고가 변경되었습니다. 다시 시도해주세요.');return Response.json({receipt,catalog:c,order});
}catch(e){return failure(e)}}
