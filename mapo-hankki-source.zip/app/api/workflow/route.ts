import {database,readCatalog} from '@/lib/store';
import {bodyOf,sameOrigin,failure} from '@/lib/request';
import {applyWorkflowAction} from '@/lib/order-workflow';
import type {WorkflowAction,WorkflowOrder} from '@/lib/api-types';
async function listOrders(){const rows=await database().prepare('SELECT data FROM orders ORDER BY created_at DESC LIMIT 100').all<{data:string}>();return rows.results.map(row=>JSON.parse(row.data).workflow as WorkflowOrder|undefined).filter((o):o is WorkflowOrder=>!!o);}
export async function GET(){try{return Response.json({orders:await listOrders()},{headers:{'Cache-Control':'no-store'}})}catch(e){return failure(e)}}
export async function POST(request:Request){try{
 sameOrigin(request);const action=await bodyOf(request) as WorkflowAction;if(typeof action.orderId!=='string')throw new Error('예약을 확인해주세요.');
 const db=database(),row=await db.prepare('SELECT data FROM orders WHERE id=?').bind(action.orderId).first<{data:string}>();if(!row)throw new Error('예약을 찾을 수 없습니다.');const stored=JSON.parse(row.data);if(!stored.workflow)throw new Error('이전 시연 예약입니다. 새 예약으로 준비 흐름을 체험해주세요.');
 const order=applyWorkflowAction(stored.workflow,action,await readCatalog()),result=await db.prepare('UPDATE orders SET data=? WHERE id=? AND data=?').bind(JSON.stringify({...stored,total:order.total,workflow:order}),order.id,row.data).run();if(!result.meta.changes)throw new Error('준비 상태가 바뀌었습니다. 새로고침 후 다시 확인해주세요.');return Response.json({order,orders:await listOrders()});
}catch(e){return failure(e)}}
