import {env} from "cloudflare:workers";
import {readCatalog} from "@/lib/store";
export async function GET(){try{return Response.json({catalog:await readCatalog(),aiConnected:!!(env as unknown as Record<string,string>).OPENAI_API_KEY},{headers:{"Cache-Control":"no-store"}})}catch{return Response.json({error:"상품 저장소 준비 중입니다. 잠시 뒤 새로고침해주세요."},{status:503})}}
