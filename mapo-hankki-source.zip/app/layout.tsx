import type { Metadata } from "next";
import "./globals.css";
export const metadata:Metadata={title:"마포한끼 | 우리 집에 맞춘 시장의 한 끼",description:"상인의 레시피에 우리 집 재료와 취향을 더하는 마포농수산물시장 밀키트 실험실",icons:{icon:"/images/logo-icon.png"}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ko"><body>{children}</body></html>}
