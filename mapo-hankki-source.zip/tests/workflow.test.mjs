import assert from 'node:assert/strict';
import {test,afterEach} from 'node:test';
import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const temp=mkdtempSync(resolve(tmpdir(),'mapo-workflow-'));
execFileSync(resolve('node_modules/esbuild/bin/esbuild'),['tests/runtime.ts','--bundle','--platform=node','--format=esm',`--outfile=${temp}/runtime.mjs`],{stdio:'pipe'});
const {initialCatalog,emptyInput,emptyIntent,makePlan,createWorkflowOrder,applyWorkflowAction,validateExtras,upgradeCatalog,staticApi}=await import(pathToFileURL(`${temp}/runtime.mjs`));
process.on('exit',()=>rmSync(temp,{recursive:true,force:true}));
let storage=new Map();globalThis.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value),removeItem:key=>storage.delete(key)};afterEach(()=>storage=new Map());
const c=()=>structuredClone(initialCatalog);
const plan=(catalog,id='tofu-pot')=>makePlan({...emptyInput},emptyIntent(id),catalog,'original');
const action=(order,a,extra={})=>({action:a,orderId:order.id,...extra});
test('joint order allocates line items and preparation fees exactly by shop, excluding pantry',()=>{
 const catalog=c(),p=plan(catalog),extras=validateExtras([{id:'mushroom',count:2,sourceShopId:'sea'}],catalog),o=createWorkflowOrder([p],extras,catalog,'17:00–18:00');
 assert.equal(o.total,p.total+8000);assert.equal(o.tasks.reduce((s,t)=>s+t.total,0),o.total);assert.equal(o.tasks.reduce((s,t)=>s+t.preparationFee,0),p.fee);
 assert(o.tasks.every(t=>t.total===t.ingredientTotal+t.preparationFee));assert(o.tasks.find(t=>t.shopId==='veg').lines.some(l=>l.kind==='extra'&&l.sourceShopId==='sea'&&l.quantity===400));
 const home=structuredClone(p);home.lines[0].source='home';home.total-=home.lines[0].price;const without=createWorkflowOrder([home],[],catalog,'11:00–12:00');assert(!without.tasks.some(t=>t.lines.some(l=>l.id===home.lines[0].id)));
});
test('all nine registered menus create valid shop tasks and allocate preparation fee to their host',()=>{
 const catalog=c();assert.equal(catalog.recipes.length,9);
 for(const recipe of catalog.recipes){const p=plan(catalog,recipe.id);assert.equal(p.blocked,false,recipe.id);const order=createWorkflowOrder([p],[],catalog,'17:00–18:00');assert.equal(order.total,p.total,recipe.id);assert.equal(order.tasks.reduce((sum,t)=>sum+t.preparationFee,0),p.fee);if(recipe.feeShopId)assert.equal(order.tasks.find(t=>t.shopId===recipe.feeShopId).preparationFee,p.fee);assert(order.tasks.every(t=>catalog.shops.some(shop=>shop.id===t.shopId)));}
});
test('ready requires every shop; pickup and simulated settlement are ordered and idempotent',()=>{
 const catalog=c();let o=createWorkflowOrder([plan(catalog)],[],catalog,'17:00–18:00');assert.throws(()=>applyWorkflowAction(o,action(o,'collect'),catalog));assert.throws(()=>applyWorkflowAction(o,action(o,'settle'),catalog));
 o=applyWorkflowAction(o,action(o,'prepare',{shopId:o.tasks[0].shopId}),catalog);assert.equal(o.status,'preparing');
 for(const task of o.tasks)o=applyWorkflowAction(o,action(o,'ready',{shopId:task.shopId}),catalog);
 assert.equal(o.status,'ready');o=applyWorkflowAction(o,action(o,'collect'),catalog);assert.equal(o.status,'collected');assert.deepEqual(applyWorkflowAction(o,action(o,'collect'),catalog),o);
 o=applyWorkflowAction(o,action(o,'settle'),catalog);assert.equal(o.status,'settled');assert.equal(o.settlement.simulated,true);assert.equal(o.settlement.status,'confirmed');assert.deepEqual(applyWorkflowAction(o,action(o,'settle'),catalog),o);assert.throws(()=>applyWorkflowAction(o,action(o,'add_extra',{ingredientId:'tofu',count:1}),catalog));
});
test('on-site extra purchases update attribution and totals, resetting preparation until pickup',()=>{
 const catalog=c();let o=createWorkflowOrder([plan(catalog)],[],catalog,'14:00–15:00');for(const task of o.tasks)o=applyWorkflowAction(o,action(o,'ready',{shopId:task.shopId}),catalog);const before=o.total;
 o=applyWorkflowAction(o,action(o,'add_extra',{ingredientId:'shrimp',count:1,sourceShopId:'veg'}),catalog);assert.equal(o.total,before+6500);assert.equal(o.extras[0].sourceShopId,'veg');assert.equal(o.tasks.find(t=>t.shopId==='sea').status,'pending');assert.throws(()=>applyWorkflowAction(o,action(o,'collect'),catalog));
 o=applyWorkflowAction(o,action(o,'ready',{shopId:'sea'}),catalog);o=applyWorkflowAction(o,action(o,'collect'),catalog);o=applyWorkflowAction(o,action(o,'add_extra',{ingredientId:'mushroom',count:1,sourceShopId:'sea'}),catalog);assert.equal(o.status,'collected');assert.equal(o.total,before+10500);
});
test('bad extras/ids/duplicate orders cannot consume stock or persist failed orders',async()=>{
 const catalog=c();for(const value of [[{id:'fake',count:1}],[{id:'tofu',count:0}],[{id:'tofu',count:1.5}],[{id:'tofu',count:1,sourceShopId:'fake'}]])assert.throws(()=>validateExtras(value,catalog));
 const {plan:p}=await staticApi('/api/adapt',{input:{...emptyInput},recipeId:'tofu-pot'}),before=(await staticApi('/api/catalog')).catalog.recipes[0].stock;
 for(const body of [{planIds:[p.id,p.id],extras:[]},{planIds:[p.id],extras:[{id:'fake',count:1}]},{planIds:[p.id],extras:[{id:'tofu',count:-1}]}])await assert.rejects(staticApi('/api/orders',{...body,slot:'17:00–18:00'}));
 assert.equal((await staticApi('/api/catalog')).catalog.recipes[0].stock,before);assert.equal((await staticApi('/api/workflow')).orders.length,0);
 const result=await staticApi('/api/orders',{planIds:[p.id],extras:[],slot:'17:00–18:00'});assert.equal(result.receipt.orderId,result.order.id);await assert.rejects(staticApi('/api/orders',{planIds:[p.id],extras:[],slot:'17:00–18:00'}));
});
test('browser seed migration retains saved stock, recipe edits and consumed plan IDs',async()=>{
 const old=c();old.recipes=old.recipes.slice(0,1);old.ingredients=old.ingredients.slice(0,2);old.shops=old.shops.slice(0,2);old.recipes[0].stock=3;old.recipes[0].subtitle='상인 편집';old.revision=8;
 const upgraded=upgradeCatalog(old);assert.equal(upgraded.recipes[0].stock,3);assert.equal(upgraded.recipes[0].subtitle,'상인 편집');assert.equal(upgraded.recipes.length,initialCatalog.recipes.length);assert.equal(upgraded.ingredients.length,initialCatalog.ingredients.length);
 storage.set('mapo-public-demo-v2',JSON.stringify({catalog:old,plans:{},used:['already']}));const result=await staticApi('/api/catalog');assert.equal(result.catalog.recipes[0].stock,3);assert.equal(result.catalog.recipes.length,initialCatalog.recipes.length);assert.equal((await staticApi('/api/workflow')).orders.length,0);
});
