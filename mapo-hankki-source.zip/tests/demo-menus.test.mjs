import assert from 'node:assert/strict';
import {test} from 'node:test';
import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const temp=mkdtempSync(resolve(tmpdir(),'mapo-demo-menus-'));
execFileSync(resolve('node_modules/esbuild/bin/esbuild'),['tests/runtime.ts','--bundle','--platform=node','--format=esm',`--outfile=${temp}/runtime.mjs`],{stdio:'pipe'});
const {initialCatalog,emptyInput,demoIntent,makePlan}=await import(pathToFileURL(`${temp}/runtime.mjs`));
process.on('exit',()=>rmSync(temp,{recursive:true,force:true}));
const input=patch=>({...emptyInput,...patch});
const catalog=()=>structuredClone(initialCatalog);

test('all nine exact registered menu names select their original and remain orderable',()=>{
 const c=catalog();assert.equal(c.recipes.length,9);
 for(const recipe of c.recipes){const v=input({meal:recipe.name}),intent=demoIntent(v,c);assert.equal(intent.recipeId,recipe.id,recipe.name);assert.equal(makePlan(v,intent,c,'demo').blocked,false,recipe.name);}
});
test('registered names are matched dynamically before general keywords',()=>{
 const c=catalog();c.recipes[0].name='오늘의 특별한 볶음';assert.equal(demoIntent(input({meal:c.recipes[0].name}),c).recipeId,'tofu-pot');
});
test('specific new meal keywords precede broad hotpot and stir-fry keywords',()=>{
 const cases=[['소고기 전골','beef-pot'],['샤브','beef-pot'],['beef','beef-pot'],['닭 볶음','chicken-pan'],['치킨','chicken-pan'],['조개 국물','clam-soup'],['생선 조림','fish-radish'],['대구와 무','fish-radish'],['오징어 볶음','squid-pan'],['구운 채소','veggie-bowl'],['채소두부 한상','veggie-bowl']];
 for(const [meal,id] of cases)assert.equal(demoIntent(input({meal}),catalog()).recipeId,id,meal);
});
test('three original prices and pantry/addition example remain unchanged',()=>{
 for(const [meal,total] of [['두부 버섯 전골',18000],['해물 전골',21000],['새우 볶음',20000]]){const v=input({meal});const p=makePlan(v,demoIntent(v,catalog()),catalog(),'demo');assert.equal(p.total,total);assert.equal(p.blocked,false);}
 const v=input({people:'2명',meal:'두부 버섯 전골',pantry:'두부 300g',add:'버섯 200g',budget:'2만 원',time:'25분',equipment:'냄비'});assert.equal(makePlan(v,demoIntent(v,catalog()),catalog(),'demo').total,19000);
});
test('single-syllable ingredient aliases never match inside unrelated words',()=>{
 for(const text of ['아무거나','무조건','파스타','까닭','감귤색'])for(const key of ['add','pantry','exclude']){const i=demoIntent(input({[key]:text}),catalog());assert.deepEqual(i.additions,[],text);assert.deepEqual(i.pantry,[],text);assert.deepEqual(i.excluded,[],text);}
 const v=input({meal:'파스타'});assert.equal(demoIntent(v,catalog()).recipeId,null);assert(makePlan(v,demoIntent(v,catalog()),catalog(),'demo').blocked);
});
test('ingredient aliases support quantities and Korean particles without inventing quantities',()=>{
 for(const [add,id,q] of [['무300g','radish',300],['무는 300g','radish',300],['파 50g','onion',50],['닭 250g','chicken',250],['귤 500g','mandarin',500],['버섯과 두부','mushroom',null]]){const i=demoIntent(input({add}),catalog());assert.equal(i.additions.find(x=>x.id===id)?.quantity,q,add);}
 const i=demoIntent(input({add:'무조건 300g, 무'}),catalog());assert.equal(i.additions.find(x=>x.id==='radish')?.quantity,null);assert(i.unresolved.length>0);
 const c=catalog();c.ingredients.find(i=>i.id==='mushroom').aliases.push('버섯(혼합)');const i2=demoIntent(input({add:'버섯(혼합) 200g'}),c);assert.equal(i2.additions.find(i=>i.id==='mushroom')?.quantity,200);
});
test('unrecognized mixed ingredients and health conditions stay blocked',()=>{
 for(const v of [input({add:'버섯 200g과 우유'}),input({meal:'닭고기 버섯볶음',notes:'저염으로'}),input({meal:'바지락 채소 맑은탕',notes:'조개 알레르기'})])assert(makePlan(v,demoIntent(v,catalog()),catalog(),'demo').blocked);
});
test('existing spicy original accepts matching taste but cannot silently become mild',()=>{
 const c=catalog();c.recipes.find(r=>r.id==='squid-pan').spicy=true;
 for(const [taste,blocked] of [['매콤하게',false],['순한 맛',true]]){const v=input({meal:'오징어 채소볶음',taste});assert.equal(makePlan(v,demoIntent(v,c),c,'demo').blocked,blocked,taste);}
 const v=input({meal:'버섯 가득 두부전골',taste:'매콤하게'});assert.equal(makePlan(v,demoIntent(v,c),c,'demo').blocked,true);
});
