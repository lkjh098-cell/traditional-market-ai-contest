import assert from 'node:assert/strict';
import {test} from 'node:test';
import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const temp=mkdtempSync(resolve(tmpdir(),'mapo-flavor-'));
execFileSync(resolve('node_modules/esbuild/bin/esbuild'),['tests/runtime.ts','--bundle','--platform=node','--format=esm',`--outfile=${temp}/runtime.mjs`],{stdio:'pipe'});
const {initialCatalog,emptyInput,emptyIntent,demoIntent,makePlan,buildIntentJsonSchema,createIntentSchema}=await import(pathToFileURL(`${temp}/runtime.mjs`));
process.on('exit',()=>rmSync(temp,{recursive:true,force:true}));
const catalog=()=>structuredClone(initialCatalog);
const input=taste=>({...emptyInput,meal:'두부 버섯 전골',taste});
test('garlic preference produces priced quantity in supplier preparation lines',()=>{
 const c=catalog(),v=input('마늘 많이'),i=demoIntent(v,c),p=makePlan(v,i,c,'demo');
 assert.equal(p.blocked,false);const garlic=p.lines.find(l=>l.id==='garlic');assert(garlic);assert.equal(garlic.quantity,20);assert.equal(garlic.price,800);assert.equal(garlic.shopId,'sauce');assert.equal(p.total,p.originalTotal+800);assert(p.evidenceChecks.some(check=>check.field.startsWith('flavorRuleIds')&&check.status==='accepted'));
});
test('live missing flavor interpretation recovers only a registered named request',()=>{
 const c=catalog(),v=input('마늘 많이'),i=emptyIntent('tofu-pot');i.unresolved=[{type:'ambiguous',text:'마늘 많이의 분량은 명시되지 않았습니다.'}];
 const p=makePlan(v,i,c,'live');assert.equal(p.blocked,false);assert.equal(p.lines.find(l=>l.id==='garlic').quantity,20);
});
test('mixed unsupported, health and negated garlic requests are never silently cleared',()=>{
 const c=catalog();for(const taste of ['마늘 많이, 설탕 없게','마늘 많이 넣지 마세요','마늘 많이, 저염으로']){
  const v=input(taste),i=emptyIntent('tofu-pot');i.unresolved=[{type:'no_rule',text:taste}];const p=makePlan(v,i,c,'live');assert.equal(p.blocked,true,taste);assert(p.unresolved.some(issue=>issue.text===taste));if(taste.includes('넣지'))assert(!p.lines.some(line=>line.id==='garlic'));
 }
});
test('opposed garlic preferences and additional same garlic quantity cannot be double applied',()=>{
 const c=catalog(),v=input('마늘 많이, 마늘 조금');assert.equal(makePlan(v,demoIntent(v,c),c,'demo').blocked,true);
 const v2={...input('마늘 많이'),add:'마늘 10g'};assert.equal(makePlan(v2,demoIntent(v2,c),c,'demo').blocked,true);
});
test('seasoning intensity changes actual portion and total, not just a memo',()=>{
 const c=catalog(),v={...input('간 약하게'),meal:'새우 채소 한 팬 볶음'},i=demoIntent(v,c);i.recipeId='shrimp-pan';
 const p=makePlan(v,i,c,'demo'),r=c.recipes.find(r=>r.id==='shrimp-pan'),original=r.lines.find(l=>l.id==='sauce');assert.equal(p.blocked,false);assert.equal(p.lines.find(l=>l.id==='sauce').quantity,original.quantity*0.75);assert(p.total<p.originalTotal);assert(p.changes.some(change=>change.label==='양념량 가볍게'));
});
test('flavor wire enum is required but old local intents remain compatible; invented evidence fails',()=>{
 const c=catalog(),wire=buildIntentJsonSchema(c);assert(wire.required.includes('flavorRuleIds'));assert(wire.properties.flavorRuleIds.items.properties.id.enum.includes('tofu-pot:garlic-more'));
 const old=emptyIntent('tofu-pot');delete old.flavorRuleIds;assert(createIntentSchema(c).safeParse(old).success);
 const i=emptyIntent('tofu-pot');i.flavorRuleIds=[{id:'tofu-pot:garlic-more',evidence:'존재하지 않는 요청',reason:'추가'}];assert(makePlan(input(''),i,c,'live').blocked);
});

test('qualitative garlic classified as a default addition is normalized without buying twice',()=>{
 const c=catalog(),v=input('마늘 많이'),i=emptyIntent('tofu-pot');i.additions=[{id:'garlic',quantity:null,evidence:'마늘 많이',reason:'마늘 추가'}];i.unresolved=[{type:'ambiguous',text:'마늘 많이의 분량 불명확'}];const p=makePlan(v,i,c,'live');assert.equal(p.blocked,false);assert.equal(p.lines.find(line=>line.id==='garlic').quantity,20);assert.equal(p.total,p.originalTotal+800);
});
