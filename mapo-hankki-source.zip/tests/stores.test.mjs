import assert from 'node:assert/strict';
import {test,afterEach} from 'node:test';
import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const temp=mkdtempSync(resolve(tmpdir(),'mapo-stores-'));
execFileSync(resolve('node_modules/esbuild/bin/esbuild'),['tests/runtime.ts','--bundle','--platform=node','--format=esm',`--outfile=${temp}/runtime.mjs`],{stdio:'pipe'});
const {initialCatalog,emptyInput,emptyIntent,makePlan,upgradeCatalog,validateExtras,createWorkflowOrder,staticApi}=await import(pathToFileURL(`${temp}/runtime.mjs`));
process.on('exit',()=>rmSync(temp,{recursive:true,force:true}));
let storage=new Map();
globalThis.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value),removeItem:key=>storage.delete(key)};
afterEach(()=>storage=new Map());
const legacyIds=new Set(['veg','tofu','sauce','sea','meat','fruit']);
const oldOwners={tofu:'tofu',mushroom:'veg',cabbage:'veg',onion:'veg',broth:'sauce',shrimp:'sea',fish:'sea',squid:'sea',sauce:'sauce',pepper:'sauce',beef:'meat',chicken:'meat',radish:'veg',clam:'sea',carrot:'veg',zucchini:'veg',apple:'fruit',mandarin:'fruit'};
function legacyCatalog(){
 const old=structuredClone(initialCatalog);delete old.seedVersion;old.revision=8;
 old.shops=old.shops.filter(s=>legacyIds.has(s.id));
 for(const shop of old.shops){shop.name=`옛 가게 ${shop.id}`;delete shop.geo;shop.map={x:22,y:30};}
 old.ingredients=old.ingredients.filter(i=>i.id in oldOwners);
 for(const ingredient of old.ingredients)ingredient.shopId=oldOwners[ingredient.id];
 for(const recipe of old.recipes)recipe.version=1;
 Object.assign(old.recipes[0],{stock:3,fee:4875,version:4,subtitle:'상인 편집',steps:['상인이 편집한 조리법']});
 old.ingredients[0].price=3250;
 return old;
}
test('18 distinct stores all have purchasable products and recipe references resolve',()=>{
 const catalog=initialCatalog,ids=new Set(catalog.shops.map(s=>s.id));
 assert.equal(catalog.shops.length,18);assert.equal(ids.size,18);assert.equal(new Set(catalog.shops.map(s=>s.name)).size,18);
 for(const shop of catalog.shops)assert(catalog.ingredients.some(i=>i.shopId===shop.id&&i.id!=='pepper'),`product for ${shop.id}`);
 const ingredients=new Map(catalog.ingredients.map(i=>[i.id,i]));assert.equal(ingredients.size,catalog.ingredients.length);
 for(const ingredient of ingredients.values())assert(ids.has(ingredient.shopId),`owner of ${ingredient.id}`);
 for(const recipe of catalog.recipes){
  assert(ids.has(recipe.feeShopId),`fee owner of ${recipe.id}`);
  const refs=[...recipe.lines.map(l=>l.id),...recipe.additions,...recipe.swaps.flatMap(s=>[s.from,s.to])];
  for(const id of refs)assert(ingredients.has(id),`${recipe.id} references ${id}`);
 }
});
test('legacy migration refreshes ownership and identities, preserves merchant edits, and is idempotent',()=>{
 const old=legacyCatalog(),upgraded=upgradeCatalog(old);
 assert.equal(upgraded.seedVersion,3);assert.equal(upgraded.shops.length,18);
 for(const shop of upgraded.shops){assert.equal(shop.name,initialCatalog.shops.find(s=>s.id===shop.id).name);assert(!('map' in shop));}
 for(const ingredient of upgraded.ingredients)assert.equal(ingredient.shopId,initialCatalog.ingredients.find(i=>i.id===ingredient.id).shopId);
 const edited=upgraded.recipes[0];assert.equal(edited.stock,3);assert.equal(edited.fee,4875);assert.equal(edited.subtitle,'상인 편집');assert.deepEqual(edited.steps,['상인이 편집한 조리법']);assert.equal(edited.version,6);
 assert.equal(upgraded.ingredients[0].price,3250);assert.equal(upgraded.revision,8);
 for(const recipe of upgraded.recipes)assert(recipe.version>old.recipes.find(r=>r.id===recipe.id).version);
 assert.deepEqual(upgradeCatalog(upgraded),upgraded);assert.equal(old.shops.length,6);assert.equal(old.ingredients.find(i=>i.id==='cabbage').shopId,'veg');
});
test('browser migration rejects an old saved plan without consuming stock',async()=>{
 const old=legacyCatalog(),intent=emptyIntent('tofu-pot'),plan=makePlan({...emptyInput},intent,old,'original');
 storage.set('mapo-public-demo-v2',JSON.stringify({catalog:old,plans:{[plan.id]:{plan,intent}},used:[],orders:[]}));
 const before=(await staticApi('/api/catalog')).catalog;
 assert.equal(before.shops.length,18);assert.equal(before.revision,9);
 await assert.rejects(staticApi('/api/orders',{planIds:[plan.id],extras:[],slot:'17:00–18:00'}),/원안이 바뀌었어요/);
 assert.equal((await staticApi('/api/catalog')).catalog.recipes[0].stock,3);assert.equal((await staticApi('/api/workflow')).orders.length,0);
});
test('a new-store extra creates its own task with correct attribution and total',()=>{
 const catalog=structuredClone(initialCatalog),plan=makePlan({...emptyInput},emptyIntent('tofu-pot'),catalog,'original');
 const product=catalog.ingredients.find(i=>!legacyIds.has(i.shopId)&&!plan.lines.some(l=>l.shopId===i.shopId));assert(product);
 const extra=validateExtras([{id:product.id,count:2,sourceShopId:product.shopId}],catalog);
 const order=createWorkflowOrder([plan],extra,catalog,'14:00–15:00',product.shopId);
 const task=order.tasks.find(t=>t.shopId===product.shopId);assert(task);assert.equal(task.shopName,catalog.shops.find(s=>s.id===product.shopId).name);
 assert.equal(task.total,product.price*2);assert.equal(task.lines[0].sourceShopId,product.shopId);assert.equal(order.sourceShopId,product.shopId);
 assert.equal(order.total,plan.total+product.price*2);assert.equal(order.tasks.reduce((sum,t)=>sum+t.total,0),order.total);
});
