import assert from 'node:assert/strict';
import {test} from 'node:test';
import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const temp=mkdtempSync(resolve(tmpdir(),'mapo-ranges-'));
execFileSync(resolve('node_modules/esbuild/bin/esbuild'),['lib/constraints.ts','--bundle','--platform=node','--format=esm',`--outfile=${temp}/ranges.mjs`],{stdio:'pipe'});
const {parseConstraintRange}=await import(pathToFileURL(`${temp}/ranges.mjs`));
process.on('exit',()=>rmSync(temp,{recursive:true,force:true}));
test('selected ranges use the upper limit, not the first numeral',()=>{
 assert.deepEqual(parseConstraintRange('10,000 ~ 20,000원','budget'),{min:10000,max:20000});
 assert.deepEqual(parseConstraintRange('1~2만 원','budget'),{min:10000,max:20000});
 assert.deepEqual(parseConstraintRange('1만원~2만원','budget'),{min:10000,max:20000});
 assert.deepEqual(parseConstraintRange('10~20분','time'),{min:10,max:20});
 assert.deepEqual(parseConstraintRange('30분~1시간','time'),{min:30,max:60});
});
test('legacy ceilings and no preference remain compatible; inverted ranges reject',()=>{
 assert.deepEqual(parseConstraintRange('2만 원 이하','budget'),{min:null,max:20000});
 assert.deepEqual(parseConstraintRange('25분 이내','time'),{min:null,max:25});
 assert.deepEqual(parseConstraintRange('상관없음','budget'),{min:null,max:null});
 assert.deepEqual(parseConstraintRange('','time'),{min:null,max:null});
 assert.deepEqual(parseConstraintRange('30000~20000원','budget'),{min:null,max:null});
});
