import assert from 'node:assert/strict';
import {test,afterEach} from 'node:test';
import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const temp=mkdtempSync(resolve(tmpdir(),'mapo-intent-'));
execFileSync(resolve('node_modules/esbuild/bin/esbuild'),['tests/runtime.ts','--bundle','--platform=node','--format=esm',`--outfile=${temp}/runtime.mjs`],{stdio:'pipe'});
const {initialCatalog,emptyInput,emptyIntent,createIntentSchema,buildIntentJsonSchema,validateIntentEvidence,demoIntent,makePlan,decodeIntentResponse,interpret,AiInterpretError,originalIntent,staticApi}=await import(pathToFileURL(`${temp}/runtime.mjs`));
process.on('exit',()=>rmSync(temp,{recursive:true,force:true}));
const input=more=>({...emptyInput,...more});
const catalog=()=>structuredClone(initialCatalog);
const sample=input({people:'2명',meal:'두부 버섯 전골',pantry:'두부 300g',add:'버섯 200g',budget:'2만 원',time:'25분',equipment:'냄비'});
const grounded=(value,evidence)=>({value,evidence,reason:'명시한 입력 조건입니다.'});
const response=body=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(body)}]}]});
const errors=(code)=>error=>error instanceof AiInterpretError&&error.code===code;
const realFetch=globalThis.fetch;
let storage=new Map();
globalThis.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value),removeItem:key=>storage.delete(key)};
afterEach(()=>{globalThis.fetch=realFetch;storage=new Map()});

test('catalog enums change per request and disallow arbitrary recipe/ingredient/swap IDs',()=>{
 const c=catalog(),wire=buildIntentJsonSchema(c);
 assert.deepEqual(wire.properties.recipeId.enum,['tofu-pot','sea-pot','shrimp-pan',null]);
 assert.equal(wire.properties.pantry.items.properties.id.enum.length,10);
 assert.deepEqual(wire.properties.swapRuleIds.items.properties.id.enum,['sea-pot:shrimp>fish']);
 for(const mutate of [i=>i.recipeId='fake',i=>i.pantry=[{id:'fake',quantity:100,evidence:'가짜',reason:'요청'}],i=>i.swapRuleIds=[{id:'tofu-pot:shrimp>fish',evidence:'교체',reason:'요청'}]]){const i=emptyIntent();mutate(i);assert.equal(createIntentSchema(c).safeParse(i).success,false)}
 c.ingredients.push({id:'new',name:'새재료',aliases:['새재료'],shopId:'veg',unit:'g',pack:100,price:1000,allergens:[]});
 assert(buildIntentJsonSchema(c).properties.additions.items.properties.id.enum.includes('new'));
});
test('catalog without swaps accepts empty array and rejects any rule',()=>{
 const c=catalog();c.recipes.forEach(r=>r.swaps=[]);
 assert(createIntentSchema(c).safeParse(emptyIntent()).success);
 const i=emptyIntent();i.swapRuleIds=[{id:'sea-pot:shrimp>fish',evidence:'교체',reason:'요청'}];
 assert.equal(createIntentSchema(c).safeParse(i).success,false);
 assert.equal(buildIntentJsonSchema(c).properties.swapRuleIds.maxItems,0);
});
test('blank conditions retain defaults without invented evidence',()=>{
 const p=makePlan(input({}),emptyIntent('tofu-pot'),catalog(),'original');
 assert.equal(p.total,18000);assert.equal(p.servings,2);assert.equal(p.blocked,false);assert.deepEqual(p.evidenceChecks,[]);
});
test('sample keeps pantry deduction, quantities and 19000 won server total',()=>{
 const c=catalog(),i=demoIntent(sample,c),p=makePlan(sample,i,c,'demo');
 assert.equal(p.blocked,false);assert.equal(p.total,19000);
 assert.equal(p.lines.find(l=>l.id==='tofu').source,'home');assert.equal(p.lines.find(l=>l.id==='mushroom').quantity,400);
 assert(p.evidenceChecks.length>=6);assert(p.evidenceChecks.every(e=>e.status==='accepted'));
});
test('fabricated evidence drops the change and blocks purchase',()=>{
 const c=catalog(),i=emptyIntent('tofu-pot');i.additions=[{id:'mushroom',quantity:200,evidence:'버섯을 추가해줘',reason:'추가 요청'}];
 const p=makePlan(input({notes:'오늘 저녁'}),i,c,'live');
 assert.equal(p.blocked,true);assert.equal(p.total,18000);assert.equal(p.lines.find(l=>l.id==='mushroom').quantity,200);
 assert(p.evidenceChecks.some(e=>e.status==='rejected'));assert(p.unresolved.some(u=>u.type==='ambiguous'));
});
test('missing quote and empty reason are both rejected',()=>{
 const c=catalog();for(const [evidence,reason] of [['','이유'],['4명','']]){const i=emptyIntent('tofu-pot');i.servings={value:4,evidence,reason};const p=makePlan(input({people:'4명'}),i,c,'live');assert.equal(p.blocked,true);assert.equal(p.servings,2)}
});
test('evidence cannot be invented by concatenating separate fields',()=>{
 const i=emptyIntent('tofu-pot');i.additions=[{id:'mushroom',quantity:200,evidence:'버섯 200g',reason:'추가'}];
 assert(validateIntentEvidence(input({meal:'버섯',add:'200g'}),i,catalog()).blocked);
});
test('evidence matching does not mutate the raw intent used for revalidation',()=>{
 const i=emptyIntent('tofu-pot');i.budget=grounded(10000,'존재하지 않는 예산');const copy=structuredClone(i);
 const p=makePlan(input({budget:'2만 원'}),i,catalog(),'live');assert(p.blocked);assert.deepEqual(i,copy);
});
test('duplicate additions cannot exceed the per-ingredient cap',()=>{
 const i=emptyIntent('tofu-pot');i.additions=[200,400].map(quantity=>({id:'mushroom',quantity,evidence:'버섯 200g, 버섯 400g',reason:'추가'}));
 const p=makePlan(input({add:'버섯 200g, 버섯 400g'}),i,catalog(),'live');assert(p.blocked);assert.equal(p.lines.find(l=>l.id==='mushroom').quantity,200);
});
test('only registered swap runs and preserves squid cooking guidance',()=>{
 const c=catalog(),v=input({meal:'해물 전골',substitute:'새우 대신 생선'}),p=makePlan(v,demoIntent(v,c),c,'demo');
 assert.equal(p.blocked,false);assert(p.lines.some(l=>l.id==='fish'));assert(!p.lines.some(l=>l.id==='shrimp'));assert(p.steps.some(s=>s.includes('오징어')));
 const i=emptyIntent('tofu-pot');i.swapRuleIds=[{id:'sea-pot:shrimp>fish',evidence:v.substitute,reason:'교체'}];
 assert(makePlan(v,i,c,'live').unresolved.some(u=>u.type==='no_rule'));
});
test('unresolved types are preserved and block purchase',()=>{
 for(const type of ['not_registered','no_rule','health_claim','ambiguous']){const i=emptyIntent('tofu-pot');i.unresolved=[{type,text:'해결되지 않은 요청'}];const p=makePlan(input({}),i,catalog(),'live');assert(p.blocked);assert(p.unresolved.some(u=>u.type===type))}
});
test('core constraint regressions: unknown input, tool, zero time, budget, core exclusion and pantry',()=>{
 const c=catalog();for(const v of [{meal:'파스타'},{add:'버섯 200g과 우유'},{equipment:'냄비 없음, 전자레인지만'},{time:'0분'},{budget:'1만원'},{exclude:'버섯'},{pantry:'버섯 200g'}]){const x=input(v);assert.equal(makePlan(x,demoIntent(x,c),c,'demo').blocked,true,JSON.stringify(v))}
});
test('unsupported values, zero/negative/nonfinite quantities fail local validation',()=>{
 for(const quantity of [0,-1,Infinity]){const i=emptyIntent();i.additions=[{id:'mushroom',quantity,evidence:'버섯 추가',reason:'요청'}];assert(!createIntentSchema(catalog()).safeParse(i).success)}
 const i=emptyIntent();i.servings=grounded(2.5,'2.5명');assert(!createIntentSchema(catalog()).safeParse(i).success);
});
test('raw allergy and health input remains blocked even when AI omits safety',()=>{
 for(const notes of ['새우 알레르기','저염으로','당뇨 식단']){const v=input({notes}),p=makePlan(v,emptyIntent('tofu-pot'),catalog(),'live');assert(p.blocked);assert(p.unresolved.some(u=>u.type==='health_claim'))}
});
test('decoder differentiates refusal, incomplete, failed and malformed outputs',()=>{
 const c=catalog();assert.throws(()=>decodeIntentResponse({status:'completed',output:[{content:[{type:'refusal',refusal:'거절'}]}]},c),errors('refusal'));
 assert.throws(()=>decodeIntentResponse({status:'incomplete',output:[]},c),errors('incomplete'));
 assert.throws(()=>decodeIntentResponse({status:'failed'},c),errors('unavailable'));
 for(const d of [{status:'completed',output:[]},{status:'completed',output:[{content:[{type:'output_text',text:'{"broken"'}]}]},response({...emptyIntent(),recipeId:'missing'})])assert.throws(()=>decodeIntentResponse(d,c),errors('invalid_response'));
 assert.equal(decodeIntentResponse(response(emptyIntent('tofu-pot')),c).recipeId,'tofu-pot');
});
test('mock API request uses strict current catalog schema; server calculates total',async()=>{
 let request;const c=catalog();globalThis.fetch=async(url,init)=>{assert.equal(url,'https://api.openai.com/v1/responses');request=JSON.parse(init.body);return Response.json(response(demoIntent(sample,c)))};
 const i=await interpret(sample,c,'test-key-not-a-credential');assert.equal(request.text.format.strict,true);assert.deepEqual(request.text.format.schema.properties.recipeId.enum,['tofu-pot','sea-pot','shrimp-pan',null]);
 assert.equal(makePlan(sample,i,c,'live').total,19000);assert.equal(request.store,false);
});
test('mock API distinguishes quota and ordinary rate limiting',async()=>{
 for(const [body,code] of [[{error:{code:'insufficient_quota'}},'quota'],[{error:{code:'credit_balance_exhausted'}},'quota'],[{error:{code:'rate_limit_exceeded'}},'rate_limit']]){globalThis.fetch=async()=>Response.json(body,{status:429});await assert.rejects(interpret(input({}),catalog(),'test-key-not-a-credential'),errors(code))}
});
test('mock network failures and invalid success bodies have separate errors',async()=>{
 globalThis.fetch=async()=>{throw new Error('offline')};await assert.rejects(interpret(input({}),catalog(),'test-key-not-a-credential'),errors('unavailable'));
 globalThis.fetch=async()=>new Response('invalid JSON',{status:200});await assert.rejects(interpret(input({}),catalog(),'test-key-not-a-credential'),errors('invalid_response'));
});
test('original recovery requires explicit selection and constraint-discard acknowledgement',()=>{
 const c=catalog(),v=input({budget:'1만원'});
 assert.throws(()=>originalIntent(v,c,undefined,true));assert.throws(()=>originalIntent(v,c,'fake',true));assert.throws(()=>originalIntent(v,c,'tofu-pot',false));
 const p=makePlan(v,originalIntent(v,c,'tofu-pot',true),c,'original');assert.equal(p.mode,'original');assert.equal(p.total,18000);assert.equal(p.input.budget,'1만원');assert(p.context.includes('적용하지'));
});
test('original recovery never bypasses safety or sold-out inventory',()=>{
 const c=catalog();for(const notes of ['새우 알레르기','저염으로'])assert.throws(()=>originalIntent(input({notes}),c,'tofu-pot',true));
 c.recipes[0].stock=0;const v=input({});assert(makePlan(v,originalIntent(v,c,'tofu-pot',false),c,'original').blocked);
});
test('public demo failure is explicit and offers no safety fallback',async()=>{
 const failure=await staticApi('/api/adapt',{input:sample,mode:'live'});assert.equal(failure.plan,null);assert.equal(failure.aiError.code,'unavailable');assert.equal(failure.fallbackAvailable,true);
 const safety=await staticApi('/api/adapt',{input:input({notes:'새우 알레르기'}),mode:'live'});assert.equal(safety.plan,null);assert.equal(safety.fallbackAvailable,false);
});
test('public demo supports original selection without AI and revalidates reservation',async()=>{
 const result=await staticApi('/api/adapt',{input:input({}),mode:'live',recipeId:'tofu-pot'});assert.equal(result.plan.mode,'original');assert.equal(result.plan.total,18000);
 const order=await staticApi('/api/orders',{planIds:[result.plan.id],extras:[],slot:'17:00–18:00'});assert.equal(order.receipt.total,18000);
 await assert.rejects(staticApi('/api/orders',{planIds:[result.plan.id],extras:[],slot:'17:00–18:00'}));
});
