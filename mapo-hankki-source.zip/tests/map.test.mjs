import assert from 'node:assert/strict';
import {test} from 'node:test';
import {execFileSync} from 'node:child_process';
import {mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const temp=mkdtempSync(resolve(tmpdir(),'mapo-map-'));
execFileSync(resolve('node_modules/esbuild/bin/esbuild'),['tests/runtime.ts','--bundle','--platform=node','--format=esm',`--outfile=${temp}/runtime.mjs`],{stdio:'pipe'});
const m=await import(pathToFileURL(`${temp}/runtime.mjs`));
process.on('exit',()=>rmSync(temp,{recursive:true,force:true}));
const {MARKET,PICKUP_POINT,DEFAULT_SHOP_GEO,offsetLatLng,shopLatLng,pixelOffset,metersPerPixel,panCamera,zoomForWidth,shopBlock,insideFootprint,googleSatelliteEmbedUrl,googleMapsViewUrl,googleDirectionsUrl,googleMapsScriptUrl,usableMapsKey,NAV_ITEMS,DEFAULT_PAGE,initialCatalog,upgradeCatalog,createWorkflowOrder,DEMO_PICKUP}=m;
const src=path=>readFileSync(resolve(path),'utf8');

// 두 좌표 사이 거리(m)
function distance(a,b){const R=6371008.8,r=x=>x*Math.PI/180,dLat=r(b.lat-a.lat),dLng=r(b.lng-a.lng);const h=Math.sin(dLat/2)**2+Math.cos(r(a.lat))*Math.cos(r(b.lat))*Math.sin(dLng/2)**2;return 2*R*Math.asin(Math.sqrt(h));}

test('main menu order is AI 한 끼 → 공동 메뉴 → 시장 지도 → 주문·픽업 → 추가 장보기',()=>{
 assert.deepEqual(NAV_ITEMS.map(n=>n.id),['meal','kits','map','orders','shops']);
 assert.deepEqual(NAV_ITEMS.map(n=>n.label),['AI 한 끼','공동 메뉴','시장 지도','주문·픽업','추가 장보기']);
 assert.equal(DEFAULT_PAGE,'meal');
});

test('header and mobile navigation are both rendered from NAV_ITEMS, first screen is the first menu',()=>{
 const page=src('app/page.tsx');
 assert.match(page,/useState<Page>\(DEFAULT_PAGE\)/);
 assert.equal((page.match(/NAV_ITEMS\.map\(/g)||[]).length,2,'header + mobile nav');
 assert.doesNotMatch(page,/\[\['map','시장 지도'/,'no hard-coded legacy nav order');
});

test('shared pickup point is the market building centre (OSM centroid, cross-checked with other map sources)',()=>{
 assert.deepEqual(PICKUP_POINT,MARKET.center);
 assert.equal(MARKET.address,'서울 마포구 월드컵로 235');
 for(const ref of [{lat:37.565222,lng:126.898512},{lat:37.564907,lng:126.89858}])assert(distance(MARKET.center,ref)<50,`within 50m of ${ref.lat},${ref.lng}`);
});

test('virtual shops are scattered across the interior and stay inside the visible satellite view',()=>{
 const shops=initialCatalog.shops,points=shops.map((s,i)=>shopLatLng(s,i,shops.length));
 assert.equal(new Set(points.map(p=>`${p.lat},${p.lng}`)).size,shops.length,'distinct positions');
 for(const p of points){const d=distance(PICKUP_POINT,p);assert(d>15&&d<85,`shop ${d.toFixed(1)}m from pickup`);}
 const avg={lat:points.reduce((a,p)=>a+p.lat,0)/points.length,lng:points.reduce((a,p)=>a+p.lng,0)/points.length};
 assert(distance(avg,PICKUP_POINT)<15,'shops remain distributed around the pickup');
 for(const [width,height] of [[760,700],[340,440]]){const z=zoomForWidth(width);for(const p of points){const o=pixelOffset(MARKET.center,p,z);assert(Math.abs(o.x)<width/2-40&&Math.abs(o.y)<height/2-20,`visible at ${width}px (z${z}): ${o.x},${o.y}`);}}
 for(const s of shops)assert(DEFAULT_SHOP_GEO[s.id],`default geo for ${s.id}`);
});

test('custom or unknown shops fall back to a ring layout and ignore invalid coordinates',()=>{
 const p=shopLatLng({id:'new-shop'},0,4),q=shopLatLng({id:'veg',geo:{north:9999,east:0}},0,6);
 assert(Math.abs(distance(PICKUP_POINT,p)-34)<0.5);
 assert.deepEqual(q,offsetLatLng(PICKUP_POINT,DEFAULT_SHOP_GEO.veg));
 const custom=shopLatLng({id:'veg',geo:{north:0,east:10}},0,6);assert(Math.abs(distance(PICKUP_POINT,custom)-10)<0.2);
});

test('Web Mercator projection matches Google tile scale',()=>{
 assert.deepEqual(pixelOffset(MARKET.center,MARKET.center,19),{x:0,y:0});
 const mpp=metersPerPixel(MARKET.center.lat,19);assert(mpp>0.23&&mpp<0.24,String(mpp));
 const east=offsetLatLng(MARKET.center,{north:0,east:40}),north=offsetLatLng(MARKET.center,{north:40,east:0});
 assert(Math.abs(pixelOffset(MARKET.center,east,19).x-40/mpp)<1);
 assert(pixelOffset(MARKET.center,north,19).y<0,'north is up');
 assert(Math.abs(distance(MARKET.center,offsetLatLng(MARKET.center,{north:100,east:0}))-100)<0.5);
 assert.equal(zoomForWidth(1024),19);assert.equal(zoomForWidth(390),18);
});

test('Google satellite URLs: keyless embed by default, key only when explicitly provided',()=>{
 const u=new URL(googleSatelliteEmbedUrl(MARKET.center,19));
 assert.equal(u.hostname,'maps.google.com');assert.equal(u.searchParams.get('t'),'k');assert.equal(u.searchParams.get('output'),'embed');assert.equal(u.searchParams.get('z'),'19');assert.equal(u.searchParams.get('q'),`${MARKET.center.lat},${MARKET.center.lng}`);assert(!u.searchParams.has('key'));
 const k=new URL(googleSatelliteEmbedUrl(MARKET.center,18,'AIzaTestKey_1234567890abcdef'));
 assert.equal(k.pathname,'/maps/embed/v1/view');assert.equal(k.searchParams.get('maptype'),'satellite');assert.equal(k.searchParams.get('zoom'),'18');
 assert.equal(new URL(googleMapsViewUrl()).searchParams.get('basemap'),'satellite');
 assert.equal(new URL(googleDirectionsUrl()).searchParams.get('destination'),`${MARKET.center.lat},${MARKET.center.lng}`);
 const s=new URL(googleMapsScriptUrl('AIzaTestKey_1234567890abcdef'));assert.equal(s.searchParams.get('loading'),'async');assert.equal(s.searchParams.get('callback'),'__mapoGoogleMapsReady');
});

test('only a well-formed browser key enables the Maps JavaScript API mode',()=>{
 for(const bad of [undefined,'',' ','YOUR_KEY','your-google-maps-key here',42])assert.equal(usableMapsKey(bad),undefined,String(bad));
 assert.equal(usableMapsKey(' AIzaTestKey_1234567890abcdef '),'AIzaTestKey_1234567890abcdef');
 assert.match(src('vite.pages.config.ts'),/envPrefix:'VITE_GOOGLE_MAPS_'/,'only Maps variables reach the browser bundle');
 assert.doesNotMatch(src('.env.example'),/VITE_GOOGLE_MAPS_API_KEY=\S/,'no key committed in the example');
});

test('legacy SVG layout coordinates are dropped and pickup label points to the market centre',()=>{
 const old=structuredClone(initialCatalog);old.shops[0].map={x:22,y:30};
 assert.equal('map' in upgradeCatalog(old).shops[0],false);
 assert.match(DEMO_PICKUP,/시장 중심 공동 픽업대/);
 const c=structuredClone(initialCatalog),v={...m.emptyInput,meal:'두부 버섯 전골'};
 const plan=m.makePlan(v,m.demoIntent(v,c),c,'demo');
 assert.match(createWorkflowOrder([plan],[],c,'11:00–12:00').pickup,/시장 중심 공동 픽업대/);
});

test('teams stay attached to every co-created menu and are shown on the map panel',()=>{
 for(const r of initialCatalog.recipes)assert(r.team&&r.team.trim().length>0,r.id);
 assert.match(src('components/market-map.tsx'),/r\.team/);
 assert.match(src('components/interactive-market-map.tsx'),/className="sat-pickup"/);
});

test('all shop block corners stay within the surveyed main-building footprint',()=>{
 for(const [i,shop] of initialCatalog.shops.entries()){
  const centre=shopLatLng(shop,i,initialCatalog.shops.length);
  assert(insideFootprint(centre),`${shop.id} centre`);
  for(const corner of shopBlock(centre,shop.block?.width,shop.block?.height,shop.block?.angle))assert(insideFootprint(corner),`${shop.id} block corner`);
 }
 assert.equal(insideFootprint(offsetLatLng(PICKUP_POINT,{north:0,east:60})),false,'previous roadside placement is outside');
});
test('saved old layout moves inside roof without changing menu version or stock',()=>{
 const old=structuredClone(initialCatalog);old.layoutVersion=1;old.shops[0].geo={north:42,east:-60};old.recipes[0].stock=3;old.recipes[0].version=6;
 const updated=upgradeCatalog(old);assert.equal(updated.layoutVersion,3);assert(insideFootprint(shopLatLng(updated.shops[0],0,18)));assert.equal(updated.recipes[0].stock,3);assert.equal(updated.recipes[0].version,6);assert.deepEqual(upgradeCatalog(updated),updated);
});

test('controlled Google camera movement preserves geographic pin coordinates',()=>{
 const p=shopLatLng(initialCatalog.shops[0],0,18),before=pixelOffset(MARKET.center,p,19);
 const next=panCamera(MARKET.center,80,-40,19),after=pixelOffset(next,p,19);
 assert(Math.abs(after.x-before.x-80)<.3);assert(Math.abs(after.y-before.y+40)<.3);
 assert.deepEqual(p,shopLatLng(initialCatalog.shops[0],0,18));
});
