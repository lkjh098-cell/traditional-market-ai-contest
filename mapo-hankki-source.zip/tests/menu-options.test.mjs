import assert from 'node:assert/strict';
import {test} from 'node:test';
import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const temp=mkdtempSync(resolve(tmpdir(),'mapo-options-'));
execFileSync(resolve('node_modules/esbuild/bin/esbuild'),['tests/runtime.ts','--bundle','--platform=node','--format=esm',`--outfile=${temp}/runtime.mjs`],{stdio:'pipe'});
const {initialCatalog,emptyInput,demoIntent,makePlan,menuOptions,interpret,emptyIntent,AiInterpretError}=await import(pathToFileURL(`${temp}/runtime.mjs`));
process.on('exit',()=>rmSync(temp,{recursive:true,force:true}));
function preview(more){const input={...emptyInput,...more},c=structuredClone(initialCatalog),intent=demoIntent(input,c),plan=makePlan(input,intent,c,'demo');return {input,c,intent,plan,options:menuOptions(input,intent,c,'demo',plan)}}
test('near-overrun previews keep strict primary plan blocked, and disclose both differences',()=>{
 const {input,c,intent,plan,options}=preview({people:'2명',meal:'두부 버섯 전골',budget:'15000원 이하',time:'15분 이내'});
 assert(plan.blocked);const tofu=options.find(o=>o.recipeId==='tofu-pot');assert(tofu);assert.equal(tofu.budgetOverrun,3000);assert.equal(tofu.timeOverrun,5);assert(tofu.requiresConsent);assert.equal(tofu.proposedBudget,18000);assert.equal(tofu.proposedMinutes,20);assert(!('id' in tofu));
 assert(makePlan(input,intent,c,'demo').blocked,'preview did not relax the order');
 const next={...input,budget:`${tofu.proposedBudget}원 이하`,time:`${tofu.proposedMinutes}분 이내`};const changed=demoIntent(next,c);changed.recipeId=tofu.recipeId;assert.equal(makePlan(next,changed,c,'demo').blocked,false);
});
test('outside the disclosed budget/time allowance is excluded',()=>{
 const {options}=preview({budget:'10000원 이하',time:'10분 이내'});
 for(const o of options){assert(o.budgetOverrun<=2000);assert(o.timeOverrun<=10);assert(o.proposedBudget-10000<=2000);assert(o.proposedMinutes-10<=10)}
 assert(!options.some(o=>o.recipeId==='tofu-pot'));
});
test('ingredient changes remain priced, and unavailable/equipment mismatches never become options',()=>{
 const {input,c,intent,plan}=preview({people:'2명',meal:'두부 버섯 전골',pantry:'두부 300g',add:'버섯 200g',budget:'18000원 이하',time:'15분 이내',equipment:'냄비'});
 const options=menuOptions(input,intent,c,'demo',plan),tofu=options.find(o=>o.recipeId==='tofu-pot');assert(tofu);assert.equal(tofu.total,19000);assert.equal(tofu.budgetOverrun,1000);assert(options.every(o=>o.equipment==='냄비'));
 c.recipes.find(r=>r.id==='tofu-pot').stock=0;assert(!menuOptions(input,intent,c,'demo',plan).some(o=>o.recipeId==='tofu-pot'));
});
test('health/allergy and fabricated evidence cannot be bypassed by alternative previews',()=>{
 for(const notes of ['땅콩 알레르기','당뇨 질병식']){const p=preview({budget:'20000원 이하',time:'30분 이내',notes});assert.equal(p.options.length,0)}
 const {input,c,intent,plan}=preview({budget:'20000원 이하',time:'30분 이내'});intent.pantry=[{id:'tofu',quantity:300,evidence:'입력에 없는 두부',reason:'차감'}];assert.equal(menuOptions(input,intent,c,'demo',plan).length,0);
});
test('transport or 503 errors retry once; quota/permission/safety errors do not retry',async()=>{
 const real=globalThis.fetch;const response={candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(emptyIntent('tofu-pot'))}]}}]};
 try{
  for(const failure of ['network','503']){let calls=0;globalThis.fetch=async()=>{calls++;if(calls===1){if(failure==='network')throw new Error('offline');return Response.json({}, {status:503})}return Response.json(response)};await interpret({...emptyInput},initialCatalog,'test-key-not-a-credential');assert.equal(calls,2)}
  for(const status of [403,429]){let calls=0;globalThis.fetch=async()=>{calls++;return Response.json({error:{message:status===429?'Quota exceeded for requestsPerDay':'denied'}},{status})};await assert.rejects(interpret({...emptyInput},initialCatalog,'test-key-not-a-credential'),e=>e instanceof AiInterpretError);assert.equal(calls,1)}
  let calls=0;globalThis.fetch=async()=>{calls++;return Response.json({promptFeedback:{blockReason:'SAFETY'}})};await assert.rejects(interpret({...emptyInput},initialCatalog,'test-key-not-a-credential'),e=>e.code==='refusal');assert.equal(calls,1);
 }finally{globalThis.fetch=real}
});
