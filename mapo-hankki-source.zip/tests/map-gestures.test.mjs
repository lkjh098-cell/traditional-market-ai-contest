import assert from 'node:assert/strict';
import {test} from 'node:test';
import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const temp=mkdtempSync(resolve(tmpdir(),'mapo-gestures-'));
execFileSync(resolve('node_modules/esbuild/bin/esbuild'),['lib/map-gestures.ts','--bundle','--platform=node','--format=esm',`--outfile=${temp}/gestures.mjs`],{stdio:'pipe'});
const {anchoredCamera,cameraScreenPoint,cameraTransform,snapCamera,pointerGeometry,wheelPixels}=await import(pathToFileURL(`${temp}/gestures.mjs`));
process.on('exit',()=>rmSync(temp,{recursive:true,force:true}));
const size={width:760,height:600},base={center:{lat:37.56519,lng:126.8985},zoom:18};
const near=(actual,expected,tolerance=1e-6)=>assert(Math.abs(actual-expected)<tolerance,`${actual} != ${expected}`);
const same=(a,b)=>{near(a.x,b.x);near(a.y,b.y)};
// Independent inverse projection retrieves the geographic point beneath a screen anchor.
function geographicAnchor(camera,p){
 const x=256*(.5+camera.center.lng/360)+(p.x-size.width/2)/2**camera.zoom;
 const sin=Math.sin(camera.center.lat*Math.PI/180);
 const y=256*(.5-Math.log((1+sin)/(1-sin))/(4*Math.PI))+(p.y-size.height/2)/2**camera.zoom;
 return {lng:x/256*360-180,lat:Math.atan(Math.sinh(Math.PI*(1-2*y/256)))*180/Math.PI};
}

test('cursor wheel zoom retains the geographic location beneath an off-centre cursor',()=>{
 for(const anchor of [{x:75,y:90},{x:710,y:515},{x:380,y:300}]){
  const geo=geographicAnchor(base,anchor);
  for(const zoom of [16,17.25,18.6,20.8,21])same(cameraScreenPoint(anchoredCamera(base,zoom,anchor,anchor,size),geo,size),anchor);
 }
});

test('mouse/marker drag moves all geographic points by the same screen distance',()=>{
 const start={x:123,y:222},end={x:310,y:178};
 const next=anchoredCamera(base,base.zoom,start,end,size);
 for(const point of [base.center,{lat:37.5655,lng:126.8982},{lat:37.5645,lng:126.8989}]){
  const before=cameraScreenPoint(base,point,size),after=cameraScreenPoint(next,point,size);
  same(after,{x:before.x+end.x-start.x,y:before.y+end.y-start.y});
 }
});

test('two-finger pinch and pan retain the initial world coordinate at the moving midpoint',()=>{
 const start=pointerGeometry([{x:160,y:190},{x:420,y:230}]),end=pointerGeometry([{x:105,y:250},{x:565,y:310}]);
 const targetZoom=base.zoom+Math.log2(end.distance/start.distance);
 const next=anchoredCamera(base,targetZoom,start.midpoint,end.midpoint,size);
 same(cameraScreenPoint(next,geographicAnchor(base,start.midpoint),size),end.midpoint);
 near(next.zoom,targetZoom);
});

test('zoom clamps still preserve the pinch anchor and snapping preserves its world coordinate',()=>{
 const a={x:601,y:98};
 for(const [requested,expected] of [[5,16],[29,21]]){
  const next=anchoredCamera(base,requested,a,a,size);assert.equal(next.zoom,expected);
  same(cameraScreenPoint(next,geographicAnchor(base,a),size),a);
 }
 const fractional=anchoredCamera(base,19.67,a,a,size),snapped=snapCamera(fractional,a,size);
 assert.equal(snapped.zoom,20);same(cameraScreenPoint(snapped,geographicAnchor(fractional,a),size),a);
});

test('shared preview transform exactly matches geographic overlay projection during loading',()=>{
 const target=anchoredCamera(base,20.35,{x:215,y:83},{x:280,y:173},size),transform=cameraTransform(base,target);
 for(const point of [base.center,{lat:37.5655,lng:126.8982},{lat:37.5645,lng:126.8989}]){
  const before=cameraScreenPoint(base,point,size);
  same({x:size.width/2+(before.x-size.width/2)*transform.scale+transform.x,y:size.height/2+(before.y-size.height/2)*transform.scale+transform.y},cameraScreenPoint(target,point,size));
 }
 // A frame loaded for an earlier camera can replace the visible frame even while input continues.
 const loaded=snapCamera(target,{x:280,y:173},size),latest=anchoredCamera(target,20.8,{x:500,y:400},{x:515,y:405},size),replacement=cameraTransform(loaded,latest);
 const before=cameraScreenPoint(loaded,base.center,size);
 same({x:size.width/2+(before.x-size.width/2)*replacement.scale+replacement.x,y:size.height/2+(before.y-size.height/2)*replacement.scale+replacement.y},cameraScreenPoint(latest,base.center,size));
});

test('lifting one finger and rebasing to drag causes no camera discontinuity',()=>{
 const pinch=anchoredCamera(base,19.3,{x:290,y:210},{x:330,y:255},size),remaining={x:520,y:320};
 const still=anchoredCamera(pinch,pinch.zoom,remaining,remaining,size);
 same(cameraScreenPoint(still,base.center,size),cameraScreenPoint(pinch,base.center,size));
 const drag=anchoredCamera(pinch,pinch.zoom,remaining,{x:remaining.x+30,y:remaining.y-10},size),before=cameraScreenPoint(pinch,base.center,size);
 same(cameraScreenPoint(drag,base.center,size),{x:before.x+30,y:before.y-10});
});

test('wheel delta normalization handles pixel, line and page devices',()=>{
 assert.equal(wheelPixels(3,0,600),3);assert.equal(wheelPixels(3,1,600),48);assert.equal(wheelPixels(-1,2,600),-600);
 const one=pointerGeometry([{x:41,y:52}]);assert.deepEqual(one,{midpoint:{x:41,y:52},distance:0});
});
