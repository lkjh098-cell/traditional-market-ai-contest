"use client";
import {useEffect,useRef,useState,type CSSProperties,type ReactNode} from 'react';
import {createPortal} from 'react-dom';
import {ArrowRight,MapPin,Store,ShoppingBag,Navigation,ScanLine,Leaf,Fish,CookingPot,Move,Satellite,ExternalLink} from 'lucide-react';
import {money,recipePrice,type Catalog,type Recipe} from '@/lib/catalog';
import {MARKET,PICKUP_POINT,googleDirectionsUrl,googleMapsViewUrl,googleSatelliteEmbedUrl,pixelOffset,shopLatLng,usableMapsKey,zoomForWidth,type LatLng} from '@/lib/market-geo';
import {createHtmlLayer,loadGoogleMaps,onGoogleMapsAuthFailure,type GoogleNamespace,type HtmlLayer} from '@/lib/google-maps-loader';

type Shop=Catalog['shops'][number];
type Props={busy?:boolean;catalog:Catalog;selected:string|null;onSelect:(id:string)=>void;onMenu:(recipe:Recipe)=>void;onIngredient:(id:string)=>void;onPickup:()=>void;urlFor:(kind:string,id:string)=>string;renderQr:(url:string,label:string)=>ReactNode;asset:(path:string)=>string;};
type PinsProps={shops:Shop[];points:Record<string,LatLng>;selected:string|null;onSelect:(id:string)=>void;onPickup:()=>void;place:(p:LatLng)=>{style?:CSSProperties;data?:Record<string,string>}};

const MAPS_KEY=usableMapsKey(import.meta.env?.VITE_GOOGLE_MAPS_API_KEY);
const area=(place:string)=>place.match(/구역\s*([A-Z])/i)?.[1]||'기타';
const shopIcon=(s:Shop)=>s.category.includes('수산')?<Fish size={16}/>:s.category.includes('채소')?<Leaf size={16}/>:<Store size={16}/>;

/** 점포·공동 픽업대 마커. 위치 계산(place)만 지도 방식별로 다르다. */
function MapPins({shops,points,selected,onSelect,onPickup,place}:PinsProps){
 return <>{shops.map(s=>{const p=place(points[s.id]);return <button key={s.id} type="button" className={`sat-pin ${selected===s.id?'selected':''}`} style={{...p.style,['--pin' as string]:s.color}} {...p.data} onClick={()=>onSelect(s.id)} aria-pressed={selected===s.id} aria-label={`${s.name} (${s.category}) 선택`} title={s.name}><span>{shopIcon(s)}</span><strong>{s.name}</strong></button>})}
 {(()=>{const p=place(PICKUP_POINT);return <button type="button" className="sat-pickup" style={p.style} {...p.data} onClick={onPickup} aria-label="공동 픽업대 — 주문·픽업으로 이동"><ShoppingBag size={18}/><span><strong>공동 픽업대</strong><small>시장 중심 · 한 번에 수령</small></span></button>})()}</>;
}

/** 키 없이 열리는 Google 위성 임베드 + 같은 투영으로 계산한 가상 배치 오버레이 */
function EmbedSatellite({pins,selected,points}:{pins:Omit<PinsProps,'place'>;selected:string|null;points:Record<string,LatLng>}){
 const box=useRef<HTMLDivElement>(null);
 const [width,setWidth]=useState(0),[explore,setExplore]=useState(false),[nonce,setNonce]=useState(0);
 useEffect(()=>{const el=box.current;if(!el)return;const update=()=>setWidth(el.clientWidth);update();if(typeof ResizeObserver==='undefined')return;const ro=new ResizeObserver(update);ro.observe(el);return()=>ro.disconnect()},[]);
 const zoom=zoomForWidth(width);
 const at=(p:LatLng)=>{const o=pixelOffset(MARKET.center,p,zoom);return {style:{left:`calc(50% + ${o.x}px)`,top:`calc(50% + ${o.y}px)`}}};
 const sel=selected&&points[selected]?pixelOffset(MARKET.center,points[selected],zoom):null;
 return <div className={`sat-map embed ${explore?'exploring':''}`} ref={box}>
  {width>0&&<iframe key={`${zoom}-${nonce}`} title={`${MARKET.name} Google 위성지도`} src={googleSatelliteEmbedUrl(MARKET.center,zoom)} loading="lazy" referrerPolicy="no-referrer-when-downgrade" allowFullScreen tabIndex={explore?0:-1}/>}
  {!explore&&<div className="sat-overlay">
   {sel&&<svg className="sat-route" width="1" height="1" aria-hidden="true"><line x1="0" y1="0" x2={sel.x} y2={sel.y}/></svg>}
   <MapPins {...pins} place={at}/>
  </div>}
  <div className="sat-tools">
   <button type="button" onClick={()=>{if(explore)setNonce(n=>n+1);setExplore(v=>!v)}}>{explore?<><Satellite size={14}/>가상 배치 다시 보기</>:<><Move size={14}/>지도 직접 움직이기</>}</button>
  </div>
 </div>;
}

/** 브라우저 키가 있을 때: Maps JavaScript API 위성지도 + 좌표에 붙는 HTML 마커 */
function ApiSatellite({apiKey,pins,selected,points,onFail}:{apiKey:string;pins:Omit<PinsProps,'place'>;selected:string|null;points:Record<string,LatLng>;onFail:()=>void}){
 const box=useRef<HTMLDivElement>(null);
 const layer=useRef<HtmlLayer|null>(null);
 const route=useRef<{setPath:(p:LatLng[])=>void;setVisible:(v:boolean)=>void;setMap:(m:unknown)=>void}|null>(null);
 const [container,setContainer]=useState<HTMLDivElement|null>(null);
 const [status,setStatus]=useState<'loading'|'ready'>('loading');
 useEffect(()=>{let cancelled=false;const el=box.current;if(!el)return;
  const off=onGoogleMapsAuthFailure(onFail);
  const holder=document.createElement('div');holder.className='sat-overlay api';
  loadGoogleMaps(apiKey).then((google:GoogleNamespace)=>{if(cancelled)return;
   const map=new google.maps.Map(el,{center:MARKET.center,zoom:zoomForWidth(el.clientWidth),mapTypeId:'satellite',tilt:0,heading:0,mapTypeControl:true,mapTypeControlOptions:{mapTypeIds:['satellite','hybrid']},streetViewControl:false,fullscreenControl:true,clickableIcons:false,gestureHandling:'cooperative'});
   route.current=new google.maps.Polyline({map,path:[],visible:false,strokeColor:'#ffd36b',strokeOpacity:0.95,strokeWeight:3,clickable:false});
   const l=createHtmlLayer(google,holder);l.setMap(map);layer.current=l;
   setContainer(holder);setStatus('ready');
  }).catch(()=>{if(!cancelled)onFail()});
  return()=>{cancelled=true;off();layer.current?.setMap(null);route.current?.setMap(null);layer.current=null;route.current=null};
 },[apiKey,onFail]);
 useEffect(()=>{layer.current?.draw();const r=route.current;if(!r)return;const p=selected?points[selected]:undefined;r.setPath(p?[PICKUP_POINT,p]:[]);r.setVisible(!!p)});
 const at=(p:LatLng)=>({data:{'data-lat':String(p.lat),'data-lng':String(p.lng)}});
 return <div className="sat-map api">
  <div className="sat-canvas" ref={box} aria-label={`${MARKET.name} Google 위성지도`}/>
  {status==='loading'&&<div className="sat-loading"><Satellite size={22}/>Google 위성지도를 불러오는 중…</div>}
  {container&&createPortal(<MapPins {...pins} place={at}/>,container)}
 </div>;
}

export function MarketMap({busy=false,catalog,selected,onSelect,onMenu,onIngredient,onPickup,urlFor,renderQr,asset}:Props){
 const [zone,setZone]=useState('전체');
 const [apiFailed,setApiFailed]=useState(false);
 const [failHandler]=useState(()=>()=>setApiFailed(true));
 const zones=[...new Set(catalog.shops.map(s=>area(s.place)))];
 const visible=catalog.shops.filter(s=>zone==='전체'||area(s.place)===zone);
 const shop=catalog.shops.find(s=>s.id===selected);
 const points=Object.fromEntries(catalog.shops.map((s,i)=>[s.id,shopLatLng(s,i,catalog.shops.length)]));
 const pins={shops:visible,points,selected,onSelect,onPickup};
 const useApi=!!MAPS_KEY&&!apiFailed;
 return <><div className="page-intro map-intro"><p className="eyebrow">한 끼로 연결되는 시장</p><h1>시장에 들어서면,<br/><span>오늘의 한 끼가 보여요.</span></h1><p>실제 마포농수산물시장 위성지도 위에서 가게를 눌러 공동 메뉴를 고르고, 시장 한가운데 공동 픽업대에서 한 번에 받아요.</p><div className="map-intro-actions"><a className="outline" href={googleDirectionsUrl()} target="_blank" rel="noreferrer"><Navigation size={16}/>Google 지도 길찾기</a><a className="outline" href="https://map.naver.com/p/search/%EB%A7%88%ED%8F%AC%EB%86%8D%EC%88%98%EC%82%B0%EB%AC%BC%EC%8B%9C%EC%9E%A5" target="_blank" rel="noreferrer">네이버 지도</a><a className="outline" href="https://map.kakao.com/link/search/%EB%A7%88%ED%8F%AC%EB%86%8D%EC%88%98%EC%82%B0%EB%AC%BC%EC%8B%9C%EC%9E%A5" target="_blank" rel="noreferrer">카카오 지도 <ArrowRight size={15}/></a><span><MapPin size={14}/>{MARKET.address}</span></div></div>
 <div className="market-map-layout"><section className="market-map-card"><div className="map-card-heading"><div><span className="small-label">마포농수산물시장 · Google 위성지도</span><h2>시장 한가운데 공동 픽업대, 둘러싼 여섯 가게</h2></div><span className="badge">점포 위치는 가상 배치</span></div>
 <div className="map-zone-tabs" aria-label="시장 구역 필터">{['전체',...zones].map(z=><button key={z} className={zone===z?'active':''} onClick={()=>{setZone(z);const first=catalog.shops.find(s=>area(s.place)===z);if(z!=='전체'&&first)onSelect(first.id)}}>{z==='전체'?'전체 구역':`${z} 구역`}</button>)}</div>
 <div className="map-shop-filters" aria-label="점포 선택">{visible.map(s=><button key={s.id} className={selected===s.id?'active':''} onClick={()=>onSelect(s.id)}>{s.category}</button>)}</div>
 {useApi?<ApiSatellite apiKey={MAPS_KEY!} pins={pins} selected={selected} points={points} onFail={failHandler}/>:<EmbedSatellite pins={pins} selected={selected} points={points}/>}
 <p className="map-footnote"><InfoIcon/><span>위성 영상은 Google 지도이며, 공동 픽업대는 시장 건물 중심 좌표({MARKET.center.lat}, {MARKET.center.lng})에 둡니다. 점포 위치·메뉴·재고는 가상 시연입니다. <a href={googleMapsViewUrl()} target="_blank" rel="noreferrer">Google 지도에서 크게 보기 <ExternalLink size={11}/></a></span></p></section>
 <aside className="map-side-panel">{shop?<><span className="small-label">지금 만난 가게</span><h2><Store size={23}/>{shop.name}</h2><p>{shop.description}</p><span className="shop-location"><MapPin size={14}/>{shop.place} · 공동 픽업대 인근</span><h3>이 가게가 함께 만드는 메뉴</h3><div className="map-linked-menus">{!catalog.recipes.some(r=>r.lines.some(l=>catalog.ingredients.find(i=>i.id===l.id)?.shopId===shop.id))&&<p className="muted">이 가게는 현장 추가 장보기로 함께해요. 아래 재료를 한 끼와 같이 담아보세요.</p>}{catalog.recipes.filter(r=>r.lines.some(l=>catalog.ingredients.find(i=>i.id===l.id)?.shopId===shop.id)).map(r=><button key={r.id} onClick={()=>onMenu(r)}>{r.image?<img src={asset(r.image)} alt={`${r.name} AI 생성 예시`}/>:<CookingPot size={26}/>}<span><strong>{r.name}</strong><small>{r.team} · {money(recipePrice(r,catalog))}</small></span><ArrowRight size={15}/></button>)}</div><h3>현장에서 보고 더 담기</h3><div className="map-products">{catalog.ingredients.filter(i=>i.shopId===shop.id&&i.id!=='pepper').map(i=><button key={i.id} disabled={busy} onClick={()=>onIngredient(i.id)}><span>{i.name}<small>{i.pack}{i.unit} · {money(i.price)}</small></span><PlusIcon/></button>)}</div><div className="qr-section"><div><ScanLine size={19}/><strong>점포 QR로 바로 들어오기</strong></div>{renderQr(urlFor('shop',shop.id),`${shop.name} 점포 안내`)}<a className="text-button" href={urlFor('shop',shop.id)}>점포 상품·공동 메뉴 링크 <ArrowRight size={14}/></a></div></>:<div className="map-empty"><Store size={42} strokeWidth={1.2}/><h2>어느 가게부터 만날까요?</h2><p>위성지도의 가게를 눌러 참여 메뉴와 재료를 살펴보세요. 가운데 공동 픽업대를 누르면 주문·픽업으로 이동해요.</p><div className="map-flow-mini"><span>점포 선택</span><ArrowRight size={14}/><span>공동 메뉴</span><ArrowRight size={14}/><span>공동 픽업대</span></div></div>}</aside></div>
 <section className="map-bottom-story"><div><span>01</span><strong>AI 한 끼로 시작해요</strong><p>우리 집 조건을 말하면 상인 원안 안에서 한 끼를 구성해요.</p></div><div><span>02</span><strong>공동 메뉴를 골라요</strong><p>팀을 이룬 점포들이 함께 만든 메뉴와 참여 점포를 확인해요.</p></div><div><span>03</span><strong>시장 중심에서 받아요</strong><p>점포별 준비가 끝나면 시장 한가운데 공동 픽업대에서 한 번에 수령해요.</p></div><div><span>04</span><strong>마음에 들면 더 장봐요</strong><p>현장 추가 구매까지 주문과 점포별 시연 정산에 연결해요.</p></div></section></>;
}
function InfoIcon(){return <span aria-hidden="true">ⓘ</span>}
function PlusIcon(){return <span aria-hidden="true">＋</span>}
