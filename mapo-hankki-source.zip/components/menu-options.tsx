"use client";
import {Clock3,ShoppingBag,ArrowRight} from 'lucide-react';
import type {MenuOption} from '@/lib/api-types';
import {money} from '@/lib/catalog';
type Props={options:MenuOption[];busy:boolean;asset:(path:string)=>string;onChoose:(option:MenuOption)=>void};
export function MenuOptions({options,busy,asset,onChoose}:Props){
 if(!options.length)return null;
 return <section className="menu-options" aria-label="조건에 맞는 다른 메뉴와 초과 대안"><div className="section-heading"><div><p className="eyebrow">조금 다른 한 끼도 살펴보세요</p><h3>예산과 시간으로 골라본 다른 메뉴</h3><p>같은 인원·재료 조건으로 비교했어요. 초과 대안은 예산의 20%(최대 5,000원), 시간 최대 10분까지 보여드려요.</p></div></div><div className="menu-option-grid">{options.map(o=><article key={o.recipeId} className={`menu-option${o.requiresConsent?' flexible':''}`}><div className="menu-option-photo">{o.image&&<img src={asset(o.image)} alt={`${o.name} 사진`}/>}<span>{o.requiresConsent?'조금 늘리면 가능한 대안':'선택한 범위 안'}</span></div><div className="menu-option-body"><small>{o.team} · {o.servings}인분</small><h4>{o.name}</h4><div className="menu-option-meta"><strong><ShoppingBag size={14}/>{money(o.total)}</strong><span><Clock3 size={14}/>{o.minutes}분 · 메뉴 기준</span></div><div className="menu-option-deltas">{o.budgetOverrun>0&&<span>예산 +{money(o.budgetOverrun)}</span>}{o.timeOverrun>0&&<span>시간 +{o.timeOverrun}분</span>}{!o.requiresConsent&&<span>예산·시간 범위 안에 들어와요</span>}</div><button className="outline" type="button" disabled={busy} onClick={()=>onChoose(o)}>{o.requiresConsent?'늘어난 조건 확인하기':'이 메뉴로 다시 구성'}<ArrowRight size={14}/></button></div></article>)}</div><p className="hint">대안은 비교용이며 바로 주문되지 않아요. 선택 후 조건을 확인해 다시 계산해요. 재료·인원 변경 후 조리시간은 시험 확인이 필요해요.</p></section>;
}
