'use client';
import * as React from 'react';
import {Dialog as Primitive} from 'radix-ui';
import {X} from 'lucide-react';
export const Dialog=Primitive.Root;
export const DialogTitle=Primitive.Title;
export const DialogDescription=Primitive.Description;
export function DialogHeader({children}:React.PropsWithChildren){return <div className="dialog-header">{children}</div>}
export function DialogContent({children,className,...props}:React.ComponentProps<typeof Primitive.Content>){return <Primitive.Portal><Primitive.Overlay className="dialog-overlay"/><Primitive.Content {...props} className={`dialog-content ${className||''}`}>{children}<Primitive.Close className="dialog-close" aria-label="닫기"><X size={19}/></Primitive.Close></Primitive.Content></Primitive.Portal>}
