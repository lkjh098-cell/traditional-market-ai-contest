"use client";
import {useEffect,useRef,useState,type PointerEvent} from 'react';
import {createPortal} from 'react-dom';
import {ShoppingBag} from 'lucide-react';
import type {Catalog} from '@/lib/catalog';
import {MARKET,MARKET_FOOTPRINT,PICKUP_POINT,shopBlock,pixelOffset,googleSatelliteEmbedUrl,usableMapsKey,type LatLng} from '@/lib/market-geo';
import {anchoredCamera,cameraScreenPoint,cameraTransform,clampMapZoom,pointerGeometry,snapCamera,wheelPixels,type MapCamera,type ScreenPoint} from '@/lib/map-gestures';
import {loadGoogleMaps,onGoogleMapsAuthFailure,createHtmlLayer,type HtmlLayer} from '@/lib/google-maps-loader';

type Shop=Catalog['shops'][number];
type Props={shops:Shop[];points:Record<string,LatLng>;selected:string|null;onSelect:(id:string)=>void;onPickup:()=>void};
type Frame={id:number;camera:MapCamera};
type Frames={active:Frame;pending:Frame|null};
type TrackedPointer=ScreenPoint&{start:ScreenPoint;target:Element};
const INITIAL_CAMERA:MapCamera={center:MARKET.center,zoom:18};
export function InteractiveMarketMap({shops,points,selected,onSelect,onPickup}:Props){
 const root=useRef<HTMLDivElement>(null),host=useRef<HTMLDivElement>(null),map=useRef<any>(null),google=useRef<any>(null),layer=useRef<HtmlLayer|null>(null);
 const [holder,setHolder]=useState<HTMLElement|null>(null);
 useEffect(()=>{setHolder(document.createElement('div'))},[]);
 const [native,setNative]=useState(false),[zoom,setZoom]=useState(18),[center,setCenter]=useState<LatLng>(MARKET.center),[size,setSize]=useState({width:760,height:600});
 const [camera,setCamera]=useState<MapCamera>(INITIAL_CAMERA),cameraRef=useRef(INITIAL_CAMERA);
 const [frames,setFrames]=useState<Frames>({active:{id:0,camera:INITIAL_CAMERA},pending:null}),framesRef=useRef(frames),frameId=useRef(0);
 const pointers=useRef(new Map<number,TrackedPointer>()),baseline=useRef<{camera:MapCamera;points:ScreenPoint[]}|null>(null),moved=useRef(false),suppressClickUntil=useRef(0);
 const wheelTimer=useRef<ReturnType<typeof setTimeout>|null>(null),lastAnchor=useRef<ScreenPoint>({x:380,y:300});
 const key=usableMapsKey(import.meta.env.VITE_GOOGLE_MAPS_API_KEY);
 const updateCamera=(next:MapCamera)=>{cameraRef.current=next;setCamera(next)};
 const requestFrame=(next:MapCamera)=>{
  updateCamera(next);setCenter(next.center);setZoom(next.zoom);
  const active=framesRef.current.active;
  if(active.camera.zoom===next.zoom&&active.camera.center.lat===next.center.lat&&active.camera.center.lng===next.center.lng){
   framesRef.current={active,pending:null};setFrames(framesRef.current);return;
  }
  framesRef.current={active,pending:{id:++frameId.current,camera:next}};setFrames(framesRef.current);
 };
 const loadedFrame=(id:number)=>{
  const pending=framesRef.current.pending;if(pending?.id!==id)return;
  // Keep the previous iframe and its matching overlay visible until this exact camera loads.
  framesRef.current={active:pending,pending:null};setFrames(framesRef.current);
 };
 const commitCamera=()=>requestFrame(snapCamera(cameraRef.current,lastAnchor.current,size));
 const clearWheel=()=>{if(wheelTimer.current!==null){clearTimeout(wheelTimer.current);wheelTimer.current=null}};
 const wholeZoom=()=>{
  const offsets=MARKET_FOOTPRINT.map(p=>pixelOffset(MARKET.center,p,18));
  const w=Math.max(...offsets.map(p=>Math.abs(p.x)))*2,h=Math.max(...offsets.map(p=>Math.abs(p.y)))*2;
  return Math.max(16,Math.min(19,18+Math.floor(Math.log2(Math.min((size.width-80)/w,(size.height-80)/h)))));
 };
 const fitMarket=()=>{clearWheel();const z=wholeZoom();if(map.current){map.current.setCenter(MARKET.center);map.current.setZoom(z)}else requestFrame({center:MARKET.center,zoom:z})};
 useEffect(()=>{
  const el=root.current;if(!el)return;
  const resize=new ResizeObserver(()=>setSize({width:el.clientWidth,height:el.clientHeight}));resize.observe(el);
  return()=>resize.disconnect();
 },[]);
 useEffect(()=>{
  if(!key||!host.current||!holder)return;
  let disposed=false;let listeners:any[]=[];
  const fail=()=>{if(disposed)return;layer.current?.setMap(null);layer.current=null;map.current=null;setNative(false)};
  const unsubscribe=onGoogleMapsAuthFailure(fail);
  loadGoogleMaps(key).then(g=>{
   if(disposed||!host.current)return;google.current=g;
   const instance=new g.maps.Map(host.current,{center:MARKET.center,zoom:18,mapTypeId:'satellite',tilt:0,heading:0,disableDefaultUI:true,gestureHandling:'greedy',minZoom:16,maxZoom:21});
   map.current=instance;layer.current=createHtmlLayer(g,holder);layer.current.setMap(instance);
   listeners=[instance.addListener('zoom_changed',()=>setZoom(instance.getZoom()??18)),instance.addListener('center_changed',()=>{const c=instance.getCenter();if(c)setCenter({lat:c.lat(),lng:c.lng()})})];
   setNative(true);
  }).catch(fail);
  return()=>{disposed=true;unsubscribe();listeners.forEach(l=>l.remove());layer.current?.setMap(null);layer.current=null;map.current=null;};
 },[key,holder]);
 useEffect(()=>{
  if(!native||!google.current||!map.current)return;
  clearWheel();pointers.current.clear();baseline.current=null;
  const g=google.current,objects:any[]=[];
  objects.push(new g.maps.Polygon({map:map.current,paths:MARKET_FOOTPRINT,strokeColor:'#f6d169',strokeWeight:2,fillColor:'#e7dfc6',fillOpacity:.06,clickable:false}));
  for(const s of shops){const p=points[s.id];if(!p)continue;const b=s.block;
   const block=new g.maps.Polygon({map:map.current,paths:shopBlock(p,b?.width,b?.height,b?.angle),strokeColor:selected===s.id?'#ffd36b':'#244e3d',strokeWeight:selected===s.id?3:1.5,fillColor:s.color,fillOpacity:.65});
   block.addListener('click',()=>{if(Date.now()>=suppressClickUntil.current)onSelect(s.id)});objects.push(block);
  }
  if(selected&&points[selected])objects.push(new g.maps.Polyline({map:map.current,path:[PICKUP_POINT,points[selected]],strokeColor:'#ffe18a',strokeOpacity:.8,strokeWeight:2,clickable:false}));
  layer.current?.draw();return()=>objects.forEach(o=>{g.maps.event.clearInstanceListeners(o);o.setMap(null)});
 },[native,shops,points,selected,onSelect]);
 useEffect(()=>{
  if(!selected||!points[selected])return;
  // Only selection triggers recentering: normal user panning is left alone.
  if(native){map.current?.panTo(points[selected]);return;}
  const current=cameraRef.current,o=pixelOffset(current.center,points[selected],current.zoom);
  if(Math.abs(o.x)>size.width/2-65||Math.abs(o.y)>size.height/2-65){clearWheel();requestFrame({center:points[selected],zoom:Math.round(current.zoom)})}
 // eslint-disable-next-line react-hooks/exhaustive-deps
 },[selected,native]);
 useEffect(()=>{
  const el=root.current;if(!el||native)return;
  const wheel=(e:WheelEvent)=>{
   if((e.target as Element).closest('.market-map-controls'))return;
   e.preventDefault();if(pointers.current.size)return;
   const rect=el.getBoundingClientRect(),anchor={x:e.clientX-rect.left,y:e.clientY-rect.top};lastAnchor.current=anchor;
   const current=cameraRef.current,delta=wheelPixels(e.deltaY,e.deltaMode,size.height);
   if(!delta)return;
   updateCamera(anchoredCamera(current,current.zoom-delta*(e.ctrlKey?0.02:0.006),anchor,anchor,size));
   clearWheel();wheelTimer.current=setTimeout(()=>{wheelTimer.current=null;commitCamera()},180);
  };
  el.addEventListener('wheel',wheel,{passive:false});
  return()=>{el.removeEventListener('wheel',wheel);clearWheel()};
 // Camera changes use refs so wheel input does not repeatedly reattach the listener.
 // eslint-disable-next-line react-hooks/exhaustive-deps
 },[native,size.width,size.height]);
 const changeZoom=(delta:number)=>{
  if(map.current){map.current.setZoom(clampMapZoom(zoom+delta));return}
  clearWheel();const anchor={x:size.width/2,y:size.height/2};requestFrame(anchoredCamera(cameraRef.current,Math.round(cameraRef.current.zoom)+delta,anchor,anchor,size));
 };
 const pan=(dx:number,dy:number)=>{
  if(map.current){map.current.panBy(-dx,-dy);return}
  clearWheel();const anchor={x:size.width/2,y:size.height/2};requestFrame(anchoredCamera(cameraRef.current,Math.round(cameraRef.current.zoom),anchor,{x:anchor.x+dx,y:anchor.y+dy},size));
 };
 const pointerPoint=(e:PointerEvent<HTMLDivElement>)=>{const rect=e.currentTarget.getBoundingClientRect();return {x:e.clientX-rect.left,y:e.clientY-rect.top}};
 const rebasePointers=()=>{baseline.current={camera:cameraRef.current,points:Array.from(pointers.current.values()).slice(0,2).map(({x,y})=>({x,y}))}};
 const startDrag=(e:PointerEvent<HTMLDivElement>)=>{
  if((e.pointerType==='mouse'&&e.button!==0)||(e.target as Element).closest('.market-map-controls,a'))return;
  const p=pointerPoint(e);if(!pointers.current.size)moved.current=false;
  pointers.current.set(e.pointerId,{...p,start:p,target:e.target as Element});
  if(pointers.current.size>1)moved.current=true;
  if(native)return;clearWheel();rebasePointers();e.currentTarget.setPointerCapture(e.pointerId);
 };
 const moveDrag=(e:PointerEvent<HTMLDivElement>)=>{
  const p=pointers.current.get(e.pointerId);if(!p)return;
  Object.assign(p,pointerPoint(e));
  if(Math.hypot(p.x-p.start.x,p.y-p.start.y)>4)moved.current=true;
  if(native||!baseline.current||!moved.current)return;
  const previous=pointerGeometry(baseline.current.points),current=pointerGeometry(Array.from(pointers.current.values()).slice(0,2));
  const nextZoom=baseline.current.camera.zoom+(previous.distance>0&&current.distance>0?Math.log2(current.distance/previous.distance):0);
  lastAnchor.current=current.midpoint;
  updateCamera(anchoredCamera(baseline.current.camera,nextZoom,previous.midpoint,current.midpoint,size));
 };
 const finishDrag=(e:PointerEvent<HTMLDivElement>,cancelled=false)=>{
  const p=pointers.current.get(e.pointerId);if(!p)return;
  if(!cancelled)moveDrag(e);
  pointers.current.delete(e.pointerId);
  if(native){if(moved.current)suppressClickUntil.current=Date.now()+500;if(!pointers.current.size)moved.current=false;return}
  // Root capture makes drag reliable even when it starts on a marker. Deliver an unmoved tap explicitly.
  suppressClickUntil.current=Date.now()+500;
  if(!cancelled&&!moved.current){
   const shop=p.target.closest('[data-shop-id],[data-block-id]') as HTMLElement|null;
   const id=shop?.dataset.shopId||shop?.dataset.blockId;
   if(id)onSelect(id);else if(p.target.closest('.sat-pickup'))onPickup();
  }
  if(pointers.current.size)rebasePointers();else{baseline.current=null;if(moved.current)commitCamera();moved.current=false}
 };
 const position=(p:LatLng,base:MapCamera={center,zoom})=>{const o=cameraScreenPoint(base,p,size);return {left:o.x,top:o.y}};
 const polygon=(pts:LatLng[],base:MapCamera)=>pts.map(p=>{const s=position(p,base);return `${s.left},${s.top}`}).join(' ');
 const pins=(base?:MapCamera)=><>{shops.map(s=>{const p=points[s.id];if(!p)return null;return <button type="button" key={s.id} className={`sat-pin ${selected===s.id?'selected':''}`} style={{...(!native?position(p,base):{}),['--pin' as string]:s.color}} data-shop-id={s.id} data-lat={p.lat} data-lng={p.lng} aria-pressed={selected===s.id} aria-label={`${s.name} (${s.category}) 선택`} title={s.name} onClick={()=>onSelect(s.id)}><span>{s.place.match(/([A-Z]-\d+)/)?.[1]}</span><strong>{s.name}</strong></button>})}<button type="button" className="sat-pickup" style={!native?position(PICKUP_POINT,base):{}} data-lat={PICKUP_POINT.lat} data-lng={PICKUP_POINT.lng} aria-label="공동 픽업대 — 주문·픽업으로 이동" onClick={onPickup}><ShoppingBag size={18}/><span><strong>공동 픽업대</strong><small>시장 중심 · 한 번에 수령</small></span></button></>;
 return <div className="interactive-map-shell">
  <div ref={root} className={`sat-map interactive-map google-market-map ${(native?zoom:camera.zoom)>=20?'detailed-map':''}`} data-map-provider="google" data-map-mode={native?'javascript':'embed'} data-map-zoom={native?zoom:camera.zoom} tabIndex={0} aria-label="Google 시장 지도 — 드래그로 이동, 휠·두 손가락으로 확대·축소. 방향키로 이동, 더하기·빼기 키로 확대·축소" onPointerDownCapture={startDrag} onPointerMoveCapture={moveDrag} onPointerUpCapture={e=>finishDrag(e)} onPointerCancelCapture={e=>finishDrag(e,true)} onLostPointerCapture={e=>finishDrag(e,true)} onClickCapture={e=>{if((e.target as Element).closest('.market-map-controls'))return;if(e.detail>0&&Date.now()<suppressClickUntil.current){e.preventDefault();e.stopPropagation()}}} onKeyDown={e=>{if(e.target!==e.currentTarget)return;const d:Record<string,[number,number]>={ArrowUp:[0,80],ArrowDown:[0,-80],ArrowLeft:[80,0],ArrowRight:[-80,0]};if(d[e.key]){e.preventDefault();pan(...d[e.key])}else if(e.key==='+'||e.key==='='||e.key==='-'||e.key==='_'){e.preventDefault();changeZoom(e.key==='+'||e.key==='='?1:-1)}else if(e.key==='Home'){e.preventDefault();fitMarket()}}}>
   <div ref={host} className="sat-canvas" style={{visibility:native?'visible':'hidden'}}/>
   {!native&&[frames.active,frames.pending].filter((frame):frame is Frame=>!!frame).map(frame=>{
    const active=frame.id===frames.active.id,t=cameraTransform(frame.camera,camera);
    return <div key={frame.id} className="google-controlled-view" aria-hidden={!active} style={{visibility:active?'visible':'hidden',pointerEvents:active?'auto':'none',transformOrigin:'50% 50%',transform:`translate(${t.x}px,${t.y}px) scale(${t.scale})`,willChange:'transform'}}>
     <iframe title="마포농수산물시장 Google 위성지도" src={googleSatelliteEmbedUrl(frame.camera.center,frame.camera.zoom)} onLoad={()=>loadedFrame(frame.id)} tabIndex={-1} aria-hidden="true" referrerPolicy="no-referrer-when-downgrade"/>
     {active&&<><svg className="market-blocks" width="100%" height="100%" aria-hidden="true"><polygon points={polygon(MARKET_FOOTPRINT,frame.camera)} fill="#e7dfc6" fillOpacity=".06" stroke="#f6d169" strokeWidth="2"/>{shops.map(s=>{const p=points[s.id];if(!p)return null;return <polygon key={s.id} data-block-id={s.id} points={polygon(shopBlock(p,s.block?.width,s.block?.height,s.block?.angle),frame.camera)} fill={s.color} fillOpacity=".65" stroke={selected===s.id?'#ffd36b':'#244e3d'} strokeWidth={selected===s.id?3:1.5} onClick={()=>onSelect(s.id)}/>})}{selected&&points[selected]&&<polyline points={polygon([PICKUP_POINT,points[selected]],frame.camera)} fill="none" stroke="#ffe18a" strokeWidth="2" strokeDasharray="6 6"/>}</svg><div className="sat-overlay">{pins(frame.camera)}</div></>}
    </div>;
   })}
   {native&&holder&&createPortal(pins(),holder)}
   <div className="market-map-controls"><button type="button" className="fit-market" onClick={fitMarket}>시장 전체</button></div>
  </div><p className="map-gesture-hint">Google 위성지도 · 드래그로 이동 · 휠·두 손가락으로 확대·축소 · 점포 블록은 위치에 고정돼요.</p>
 </div>;
}
