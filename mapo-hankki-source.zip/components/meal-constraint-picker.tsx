"use client";

import {useEffect,useId,useMemo,useRef,useState,type KeyboardEvent} from 'react';
import {Check,ChevronsUpDown} from 'lucide-react';
import {parseConstraintRange} from '../lib/constraints';

type Props={kind:'budget'|'time';label:string;value:string;onChange:(value:string)=>void};
type Choice={value:string;label:string;amount:number|null};

export function MealConstraintPicker({kind,label,value,onChange}:Props){
 const id=useId(),root=useRef<HTMLDivElement>(null),trigger=useRef<HTMLButtonElement>(null),list=useRef<HTMLDivElement>(null),options=useRef<(HTMLButtonElement|null)[]>([]);
 const [open,setOpen]=useState(false),[activeIndex,setActiveIndex]=useState(0);
 const choices=useMemo(()=>{
  const ranges=kind==='budget'?[[0,10000],[10000,20000],[20000,30000],[30000,40000],[40000,50000],[50000,70000],[70000,100000]]:[[0,10],[10,20],[20,30],[30,45],[45,60],[60,90]];
  const format=(n:number)=>kind==='budget'?`${n.toLocaleString('ko-KR')}원`:`${n}분`;
  const result:Choice[]=[{value:'',label:'상관없음',amount:null},...ranges.map(([min,max])=>({amount:max,value:kind==='budget'?(min?`${min}~${max}원`:`${max}원 이하`):(min?`${min}~${max}분`:`${max}분 이내`),label:min?`${format(min)} ~ ${format(max)}`:`${format(max)} ${kind==='budget'?'이하':'이내'}`}))];
  // Preserve earlier saved ceilings and explicitly approved alternatives exactly.
  if(value.trim()&&!result.some(choice=>choice.value===value)){
   const range=parseConstraintRange(value,kind);
   result.push({value,label:range.max===null?value:range.min!==null?`${format(range.min)} ~ ${format(range.max)}`:`${format(range.max)} ${kind==='budget'?'이하':'이내'}`,amount:range.max});
  }
  return result;
 },[kind,value]);
 const selectedIndex=value.trim()?choices.findIndex(choice=>choice.value===value):0;
 const selected=choices[Math.max(0,selectedIndex)];

 useEffect(()=>{
  if(!open)return;
  const option=options.current[activeIndex],container=list.current;
  if(option&&container){container.scrollTop=option.offsetTop-(container.clientHeight-option.clientHeight)/2;option.focus({preventScroll:true});}
 },[open,activeIndex]);
 useEffect(()=>{
  if(!open)return;
  function outside(event:PointerEvent){if(event.target instanceof Node&&!root.current?.contains(event.target))setOpen(false);}
  document.addEventListener('pointerdown',outside);
  return()=>document.removeEventListener('pointerdown',outside);
 },[open]);
 function show(){setActiveIndex(Math.max(0,selectedIndex));setOpen(true);}
 function close(){setOpen(false);trigger.current?.focus({preventScroll:true});}
 function choose(index:number){onChange(choices[index].value);close();}
 function move(event:KeyboardEvent){
  let next=activeIndex;
  if(event.key==='ArrowDown')next=Math.min(choices.length-1,activeIndex+1);
  else if(event.key==='ArrowUp')next=Math.max(0,activeIndex-1);
  else if(event.key==='Home')next=0;
  else if(event.key==='End')next=choices.length-1;
  else if(event.key==='PageDown')next=Math.min(choices.length-1,activeIndex+5);
  else if(event.key==='PageUp')next=Math.max(0,activeIndex-5);
  else if(event.key==='Escape'){event.preventDefault();close();return;}
  else if(event.key==='Enter'||event.key===' '){event.preventDefault();choose(activeIndex);return;}
  else return;
  event.preventDefault();setActiveIndex(next);
 }
 return <div className="constraint-field" ref={root} onBlur={event=>{if(!event.currentTarget.contains(event.relatedTarget as Node|null))setOpen(false);}}>
  <span id={`${id}-label`} className="constraint-label">{label}</span>
  <button ref={trigger} type="button" className={`constraint-trigger${open?' open':''}`} aria-labelledby={`${id}-label ${id}-value`} aria-haspopup="listbox" aria-expanded={open} aria-controls={open?`${id}-list`:undefined} onClick={()=>open?setOpen(false):show()} onKeyDown={event=>{if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();show();}}}>
   <span id={`${id}-value`}>{selected.label}</span><ChevronsUpDown size={17} aria-hidden="true"/>
  </button>
  {open&&<div className="constraint-popup">
   <p className="constraint-instruction">스크롤해서 원하는 범위를 선택하세요 · 더 저렴하거나 빠른 메뉴도 가능해요</p>
   <div id={`${id}-list`} ref={list} className="constraint-wheel" role="listbox" aria-labelledby={`${id}-label`} onKeyDown={move}>
    {choices.map((choice,index)=><button key={choice.value} ref={element=>{options.current[index]=element;}} type="button" className={`constraint-option${index===selectedIndex?' selected':''}`} role="option" aria-selected={index===selectedIndex} tabIndex={index===activeIndex?0:-1} onFocus={()=>setActiveIndex(index)} onClick={()=>choose(index)}><span>{choice.label}</span>{index===selectedIndex&&<Check size={16} aria-hidden="true"/>}</button>)}
   </div>
  </div>}
 </div>;
}
