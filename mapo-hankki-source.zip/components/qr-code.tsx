"use client";
import {useMemo,useState} from 'react';
import {qrcode} from '@/vendor/qrcode-generator.mjs';

export function QrCode({value,label='마포한끼 안내'}:{value:string;label?:string}){
 const [copied,setCopied]=useState(false);
 const code=useMemo(()=>{
  const qr=qrcode(0,'M');qr.addData(value,'Byte');qr.make();
  const n=qr.getModuleCount(),size=n+8;
  let path='';for(let y=0;y<n;y++)for(let x=0;x<n;x++)if(qr.isDark(y,x))path+=`M${x+4} ${y+4}h1v1h-1z`;
  return {size,path};
 },[value]);
 function download(){
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${code.size} ${code.size}" width="640" height="640"><rect width="100%" height="100%" fill="white"/><path d="${code.path}" fill="#173528"/></svg>`;
  const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'})),a=document.createElement('a');a.href=url;a.download=`마포한끼-${label.replace(/[^가-힣a-zA-Z0-9_-]/g,'-')}-QR.svg`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }
 async function copy(){try{await navigator.clipboard.writeText(value);setCopied(true);setTimeout(()=>setCopied(false),2000)}catch{setCopied(false)}}
 return <div className="qr-code-block"><svg className="qr-code-image" viewBox={`0 0 ${code.size} ${code.size}`} role="img" aria-label={`${label} QR 코드`} shapeRendering="crispEdges"><rect width="100%" height="100%" fill="white"/><path d={code.path} fill="#173528"/></svg><div className="qr-code-details"><strong>{label}</strong><p>카메라로 스캔하면 이 안내를 열어요.</p><div className="qr-code-actions"><button type="button" className="text-button" onClick={download}>QR 저장</button><button type="button" className="text-button" onClick={copy}>{copied?'주소 복사됨':'주소 복사'}</button></div><a href={value} className="qr-address">안내 주소 열기</a></div></div>;
}
