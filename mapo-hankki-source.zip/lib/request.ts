import {fields,type MealInput} from './catalog';
export async function bodyOf(request:Request){if(Number(request.headers.get('content-length')||0)>16000)throw new Error('입력 내용이 너무 깁니다.');const raw=await request.text();if(raw.length>16000)throw new Error('입력 내용이 너무 깁니다.');return JSON.parse(raw)}
export function mealInput(value:unknown):MealInput{if(!value||typeof value!=='object')throw new Error('입력 내용을 확인해주세요.');const v=value as Record<string,unknown>;return Object.fromEntries(fields.map(k=>{if(typeof v[k]!=='string'||v[k].length>500)throw new Error('각 입력은 500자 이내로 적어주세요.');return [k,v[k].trim()]})) as MealInput}
export function sameOrigin(request:Request){const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)throw new Error('이 사이트에서 다시 요청해주세요.')}
export function failure(error:unknown,status=400){return Response.json({error:error instanceof Error?error.message:'요청을 처리하지 못했습니다.'},{status})}
