export type ConstraintRange={min:number|null;max:number|null};
export type ConstraintKind='budget'|'time';
/** Picker ranges are preferences: the upper end is the spending/time ceiling. */
export function parseConstraintRange(value:string,kind:ConstraintKind):ConstraintRange{
 const text=value.replace(/[,\s]/g,'');
 if(!text||/상관없|제한없/.test(text))return {min:null,max:null};
 const tokens=[...text.matchAll(/(\d+(?:\.\d+)?)(만|천|시간|분|원)?/g)];
 if(!tokens.length)return {min:null,max:null};
 const range=/[~～〜–—-]|부터/.test(text)&&tokens.length===2;
 const convert=(token:RegExpMatchArray,inherit?:string)=>{
  const unit=token[2]||inherit;
  return Number(token[1])*(kind==='budget'?(unit==='만'?10000:unit==='천'?1000:1):(unit==='시간'?60:1));
 };
 const max=convert(tokens[range?1:0]);
 const min=range?convert(tokens[0],tokens[1][2]):null;
 if(!Number.isFinite(max)||max<0||min!==null&&(!Number.isFinite(min)||min<0||min>max))return {min:null,max:null};
 return {min,max};
}
