import type {Catalog,Intent,MealInput,Plan} from './catalog';
import {makePlan} from './adapt';
import {validateIntentEvidence} from './intent';
import type {MenuOption} from './api-types';
import {parseConstraintRange} from './constraints';

/** Read-only menu previews: they have no plan/order ID and never relax an order's limits. */
export function menuOptions(input:MealInput,rawIntent:Intent,catalog:Catalog,mode:Plan['mode'],current:Plan):MenuOption[]{
 const checked=validateIntentEvidence(input,rawIntent,catalog);
 if(mode==='original'||checked.blocked)return [];
 const intent=checked.intent;
 const budget=parseConstraintRange(input.budget,'budget').max??intent.budget.value,minutes=parseConstraintRange(input.time,'time').max??intent.minutes.value;
 const budgetMin=parseConstraintRange(input.budget,'budget').min,minutesMin=parseConstraintRange(input.time,'time').min;
 if(budget===null&&minutes===null)return [];
 const budgetAllowance=budget===null?0:Math.min(5000,Math.floor(budget*.2));
 const previews:MenuOption[]=[];
 for(const recipe of catalog.recipes){
  // Meal-specific swaps and all other input conditions remain enforced.
  const candidate=structuredClone(intent);candidate.recipeId=recipe.id;
  candidate.flavorRuleIds=(candidate.flavorRuleIds??[]).map(entry=>({...entry,id:`${recipe.id}:${entry.id.split(':')[1]}`}));
  candidate.budget={value:null,evidence:'',reason:''};candidate.minutes={value:null,evidence:'',reason:''};
  const plan=makePlan({...input,budget:'',time:''},candidate,catalog,mode);
  if(plan.blocked)continue;
  const budgetOverrun=budget===null?0:Math.max(0,plan.total-budget);
  const timeOverrun=minutes===null?0:Math.max(0,recipe.minutes-minutes);
  if(budgetOverrun>budgetAllowance||timeOverrun>10)continue;
  if(recipe.id===current.recipeId&&!budgetOverrun&&!timeOverrun)continue;
  // Keep picker values round and disclose any expanded limit before selection.
  const proposedBudget=budgetOverrun?Math.ceil(plan.total/1000)*1000:budget;
  const proposedMinutes=timeOverrun?Math.ceil(recipe.minutes/5)*5:minutes;
  if(budget!==null&&proposedBudget!==null&&proposedBudget-budget>budgetAllowance)continue;
  if(minutes!==null&&proposedMinutes!==null&&proposedMinutes-minutes>10)continue;
  previews.push({recipeId:recipe.id,recipeVersion:recipe.version,name:recipe.name,team:recipe.team,image:recipe.image,total:plan.total,servings:plan.servings,minutes:recipe.minutes,equipment:recipe.equipment,budgetOverrun,timeOverrun,requestedBudget:budget,requestedMinutes:minutes,proposedBudget,proposedMinutes,requiresConsent:budgetOverrun>0||timeOverrun>0});
 }
 const score=(option:MenuOption)=>(budgetMin!==null&&option.total<budgetMin ? 0.2 : 0)+(minutesMin!==null&&option.minutes<minutesMin ? 0.1 : 0)+(option.requiresConsent?1:0)+(budget?option.budgetOverrun/budget:0)+(minutes?option.timeOverrun/minutes:0);
 const sorted=previews.sort((a,b)=>score(a)-score(b)||a.total-b.total||a.minutes-b.minutes);
 // Reserve room for small-overrun choices even when several strict matches exist.
 return [...sorted.filter(o=>!o.requiresConsent).slice(0,2),...sorted.filter(o=>o.requiresConsent).slice(0,3)];
}
