export type Ingredient={id:string;name:string;aliases:string[];shopId:string;unit:string;pack:number;price:number;allergens:string[]};
export type Recipe={id:string;version:number;name:string;subtitle:string;team:string;servings:number;minutes:number;equipment:string;stock:number;fee:number;lines:{id:string;quantity:number;removable:boolean}[];additions:string[];swaps:{from:string;to:string;quantity:number;step:string}[];steps:string[];spicy:boolean;image?:string;note:string};
export type Catalog={revision:number;lastOrder?:string;ingredients:Ingredient[];recipes:Recipe[];shops:{id:string;name:string;category:string;place:string;description:string;hours:string;color:string}[]};
export const initialCatalog:Catalog={revision:1,shops:[
{id:"veg",name:"초록채소",category:"채소·버섯",place:"시연 구역 A-01",description:"전골용 채소와 버섯을 함께 준비하는 채소점입니다.",hours:"시연 픽업 11:00–18:00",color:"#e2ecd8"},
{id:"tofu",name:"고소한두부",category:"두부",place:"시연 구역 A-02",description:"한 끼에 필요한 분량으로 두부를 준비합니다.",hours:"시연 픽업 11:00–18:00",color:"#f4eccd"},
{id:"sauce",name:"한술양념",category:"육수·양념",place:"시연 구역 B-01",description:"팀의 원안 레시피에 맞춰 육수와 양념을 계량합니다.",hours:"시연 픽업 11:00–18:00",color:"#f2ded1"},
{id:"sea",name:"바다한상",category:"수산물",place:"시연 구역 B-02",description:"손질한 수산물을 공급하고 팀 밀키트를 취합합니다.",hours:"시연 픽업 11:00–18:00",color:"#dbe8ed"}
],ingredients:[
{id:"tofu",name:"두부",aliases:["두부"],shopId:"tofu",unit:"g",pack:300,price:3000,allergens:["대두"]},
{id:"mushroom",name:"모둠버섯",aliases:["버섯","표고","느타리"],shopId:"veg",unit:"g",pack:200,price:4000,allergens:[]},
{id:"cabbage",name:"알배추",aliases:["배추","알배추"],shopId:"veg",unit:"g",pack:200,price:2000,allergens:[]},
{id:"onion",name:"대파",aliases:["대파","파"],shopId:"veg",unit:"g",pack:50,price:1000,allergens:[]},
{id:"broth",name:"채소육수",aliases:["육수"],shopId:"sauce",unit:"ml",pack:600,price:3500,allergens:["대두","밀"]},
{id:"shrimp",name:"손질새우",aliases:["새우"],shopId:"sea",unit:"g",pack:200,price:6500,allergens:["새우"]},
{id:"fish",name:"손질흰살생선",aliases:["생선","흰살생선","대구"],shopId:"sea",unit:"g",pack:200,price:6500,allergens:["생선"]},
{id:"squid",name:"손질오징어",aliases:["오징어"],shopId:"sea",unit:"g",pack:150,price:4500,allergens:["오징어"]},
{id:"sauce",name:"순한볶음소스",aliases:["소스","양념"],shopId:"sauce",unit:"g",pack:60,price:2500,allergens:["대두","밀"]},
{id:"pepper",name:"매운양념",aliases:["고추","매운양념","고춧가루"],shopId:"sauce",unit:"g",pack:20,price:500,allergens:[]}
],recipes:[
{id:"tofu-pot",version:1,name:"버섯 가득 두부전골",subtitle:"담백한 육수, 넉넉한 버섯",team:"초록한상 팀",servings:2,minutes:20,equipment:"냄비",stock:12,fee:4500,lines:[{id:"tofu",quantity:300,removable:true},{id:"mushroom",quantity:200,removable:false},{id:"cabbage",quantity:200,removable:true},{id:"onion",quantity:50,removable:true},{id:"broth",quantity:600,removable:false}],additions:["mushroom","tofu","cabbage"],swaps:[],steps:["냄비에 제공된 채소육수와 배추를 넣고 끓여주세요.","버섯과 두부를 넣고 재료가 충분히 익도록 끓여주세요.","대파를 넣고 마무리한 뒤 나누어 담아주세요."],spicy:false,image:"/images/jeongol.webp",note:"냄비 하나로 준비하는 맑은 전골. 시연용 원안이며 실제 판매 전 시험 조리가 필요합니다."},
{id:"sea-pot",version:1,name:"온가족 맑은 해물전골",subtitle:"손질 해물로 준비하는 저녁",team:"바다채소 팀",servings:2,minutes:25,equipment:"냄비",stock:8,fee:3500,lines:[{id:"shrimp",quantity:200,removable:false},{id:"squid",quantity:150,removable:true},{id:"cabbage",quantity:200,removable:true},{id:"onion",quantity:50,removable:true},{id:"broth",quantity:600,removable:false}],additions:["mushroom","tofu","cabbage"],swaps:[{from:"shrimp",to:"fish",quantity:200,step:"새우 대신 제공된 흰살생선을 넣고 충분히 익혀주세요."}],steps:["냄비에 채소육수와 배추를 넣고 끓여주세요.","손질된 해물을 넣고 충분히 익혀주세요.","대파를 넣고 마무리하세요. 생선 대체 시 잔가시를 확인하세요."],spicy:false,note:"수산점과 채소점이 함께 준비하는 시연용 상품입니다."},
{id:"shrimp-pan",version:1,name:"새우버섯 한 팬 볶음",subtitle:"팬 하나에 담은 든든함",team:"바다초록 팀",servings:2,minutes:15,equipment:"프라이팬",stock:10,fee:6000,lines:[{id:"shrimp",quantity:200,removable:false},{id:"mushroom",quantity:200,removable:false},{id:"onion",quantity:50,removable:true},{id:"sauce",quantity:60,removable:false}],additions:["mushroom","tofu"],swaps:[],steps:["팬을 예열하고 집에 있는 식용유를 소량 둘러주세요.","손질새우와 버섯을 넣고 충분히 익도록 볶아주세요.","볶음소스와 대파를 넣고 고루 섞어 마무리하세요."],spicy:false,note:"식용유는 집에서 준비합니다. 시연용 원안입니다."}
]};
export const fields=["people","meal","occasion","taste","budget","time","equipment","pantry","add","exclude","substitute","notes"] as const;
export type MealInput=Record<typeof fields[number],string>;
export const emptyInput:MealInput=Object.fromEntries(fields.map(k=>[k,""])) as MealInput;
export function money(v:number){return new Intl.NumberFormat("ko-KR").format(v)+"원"}
export function recipePrice(recipe:Recipe,catalog:Catalog){return recipe.fee+recipe.lines.reduce((sum,l)=>{const p=catalog.ingredients.find(i=>i.id===l.id)!;return sum+p.price*l.quantity/p.pack},0)}
export type Evidence={evidence:string;reason:string};
export type GroundedValue<T>=Evidence & {value:T};
export type Unresolved={type:"not_registered"|"no_rule"|"health_claim"|"ambiguous";text:string};
// recipeId is a model selection from registered originals, so it does not claim an explicit user change.
export type Intent={recipeId:string|null;servings:GroundedValue<number|null>;budget:GroundedValue<number|null>;minutes:GroundedValue<number|null>;equipment:GroundedValue<string|null>;spicy:GroundedValue<boolean|null>;excluded:(Evidence & {id:string})[];pantry:(Evidence & {id:string;quantity:number|null})[];additions:(Evidence & {id:string;quantity:number|null})[];swapRuleIds:(Evidence & {id:string})[];allergy:GroundedValue<boolean>;unresolved:Unresolved[];context:string};
export type EvidenceCheck=Evidence & {field:string;status:"accepted"|"rejected";message:string};
export type Plan={id:string;catalogRevision:number;recipeId:string;recipeVersion:number;name:string;team:string;servings:number;minutes:number;equipment:string;lines:{id:string;name:string;shopId:string;quantity:number;unit:string;price:number;source:"market"|"home"}[];fee:number;total:number;originalTotal:number;changes:{label:string;detail:string}[];steps:string[];warnings:string[];blocked:boolean;mode:"live"|"demo"|"original";context:string;input:MealInput;createdAt:string;evidenceChecks?:EvidenceCheck[];unresolved?:Unresolved[]};
