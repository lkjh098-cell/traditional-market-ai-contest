export type Ingredient={id:string;name:string;aliases:string[];shopId:string;unit:string;pack:number;price:number;allergens:string[]};
export type Recipe={id:string;version:number;name:string;subtitle:string;team:string;servings:number;minutes:number;equipment:string;stock:number;fee:number;lines:{id:string;quantity:number;removable:boolean}[];additions:string[];swaps:{from:string;to:string;quantity:number;step:string}[];steps:string[];spicy:boolean;image?:string;category?:"채소"|"수산"|"정육";feeShopId?:string;note:string};
export type Catalog={revision:number;seedVersion?:number;lastOrder?:string;ingredients:Ingredient[];recipes:Recipe[];shops:{id:string;name:string;category:string;place:string;description:string;hours:string;color:string;/** 픽업대(시장 중심) 기준 가상 배치(m). 없으면 lib/market-geo의 기본 배치 */geo?:{north:number;east:number};/** @deprecated 이전 SVG 안내도 좌표(저장된 카탈로그 호환용) */map?:{x:number;y:number}}[]};
export const initialCatalog:Catalog={
  "revision": 1,
  "shops": [
    {
      "id": "veg",
      "name": "들녘버섯상회",
      "category": "채소·버섯",
      "place": "시연 구역 A-01",
      "description": "전골과 볶음에 쓰는 모둠버섯을 계량해 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#e2ecd8",
      "geo": {
        "north": 36,
        "east": -55
      }
    },
    {
      "id": "veg-cabbage",
      "name": "해뜰채소",
      "category": "채소·배추",
      "place": "시연 구역 A-02",
      "description": "알배추와 애호박을 한 끼 분량으로 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#e2ecd8",
      "geo": {
        "north": 36,
        "east": -33
      }
    },
    {
      "id": "veg-green",
      "name": "길목채소상회",
      "category": "채소·대파",
      "place": "시연 구역 A-03",
      "description": "국물과 볶음에 곁들일 대파를 다듬어 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#e2ecd8",
      "geo": {
        "north": 36,
        "east": -11
      }
    },
    {
      "id": "veg-root",
      "name": "뿌리농산",
      "category": "채소·뿌리채소",
      "place": "시연 구역 A-04",
      "description": "생선조림과 볶음에 필요한 무와 당근을 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#e2ecd8",
      "geo": {
        "north": 36,
        "east": 11
      }
    },
    {
      "id": "veg-leaf",
      "name": "한잎채소",
      "category": "채소·쌈채소",
      "place": "시연 구역 A-05",
      "description": "현장에서 보고 더 담을 수 있는 깻잎과 쌈채소를 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#e2ecd8",
      "geo": {
        "north": 36,
        "east": 33
      }
    },
    {
      "id": "sea",
      "name": "물결새우상회",
      "category": "수산·새우",
      "place": "시연 구역 B-01",
      "description": "전골과 한 팬 볶음에 쓰는 손질새우를 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#dbe8ed",
      "geo": {
        "north": 36,
        "east": 55
      }
    },
    {
      "id": "sea-fish",
      "name": "은빛생선상회",
      "category": "수산·생선",
      "place": "시연 구역 B-02",
      "description": "조림과 전골용 흰살생선을 손질해 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#dbe8ed",
      "geo": {
        "north": 18,
        "east": 55
      }
    },
    {
      "id": "sea-squid",
      "name": "해뜰오징어",
      "category": "수산·오징어",
      "place": "시연 구역 B-03",
      "description": "볶음과 전골용 오징어를 손질해 계량합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#dbe8ed",
      "geo": {
        "north": 0,
        "east": 55
      }
    },
    {
      "id": "sea-clam",
      "name": "갯마을조개상회",
      "category": "수산·조개",
      "place": "시연 구역 B-04",
      "description": "맑은탕에 쓰는 해감바지락을 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#dbe8ed",
      "geo": {
        "north": -18,
        "east": 55
      }
    },
    {
      "id": "sea-dried",
      "name": "바다뜰건어물",
      "category": "수산·건어물",
      "place": "시연 구역 B-05",
      "description": "식사에 곁들이거나 집에서 쓸 건미역을 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#dbe8ed",
      "geo": {
        "north": -36,
        "east": 55
      }
    },
    {
      "id": "meat",
      "name": "한결축산",
      "category": "정육·소고기",
      "place": "시연 구역 C-01",
      "description": "샤브전골에 맞게 얇게 썬 소고기를 계량합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#efded8",
      "geo": {
        "north": -36,
        "east": 33
      }
    },
    {
      "id": "meat-chicken",
      "name": "다온닭상회",
      "category": "정육·닭고기",
      "place": "시연 구역 C-02",
      "description": "버섯볶음에 쓰는 닭고기를 손질해 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#efded8",
      "geo": {
        "north": -36,
        "east": 11
      }
    },
    {
      "id": "meat-pork",
      "name": "고운정육점",
      "category": "정육·돼지고기",
      "place": "시연 구역 C-03",
      "description": "현장 추가 장보기로 담을 수 있는 돼지고기를 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#efded8",
      "geo": {
        "north": -36,
        "east": -11
      }
    },
    {
      "id": "tofu",
      "name": "콩마루두부",
      "category": "두부·단단한 두부",
      "place": "시연 구역 D-01",
      "description": "전골과 채소 한상에 쓸 두부를 분량에 맞춰 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#f4eccd",
      "geo": {
        "north": -36,
        "east": -33
      }
    },
    {
      "id": "tofu-soft",
      "name": "고소담두부",
      "category": "두부·연두부",
      "place": "시연 구역 D-02",
      "description": "식사에 곁들일 연두부를 별도로 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#f4eccd",
      "geo": {
        "north": -36,
        "east": -55
      }
    },
    {
      "id": "sauce",
      "name": "한술양념상회",
      "category": "양념·소스",
      "place": "시연 구역 E-01",
      "description": "공동 메뉴 원안에 맞춘 볶음소스와 양념을 계량합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#f2ded1",
      "geo": {
        "north": -18,
        "east": -55
      }
    },
    {
      "id": "sauce-broth",
      "name": "국물곳간",
      "category": "양념·육수",
      "place": "시연 구역 E-02",
      "description": "전골과 맑은탕에 쓰는 채소육수를 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#f2ded1",
      "geo": {
        "north": 0,
        "east": -55
      }
    },
    {
      "id": "fruit",
      "name": "계절담과일",
      "category": "과일·제철 과일",
      "place": "시연 구역 F-01",
      "description": "식사 후 곁들일 사과와 감귤을 준비합니다.",
      "hours": "시연 픽업 11:00–18:00",
      "color": "#f5e6b7",
      "geo": {
        "north": 18,
        "east": -55
      }
    }
  ],
  "ingredients": [
    {
      "id": "tofu",
      "name": "두부",
      "aliases": [
        "두부"
      ],
      "shopId": "tofu",
      "unit": "g",
      "pack": 300,
      "price": 3000,
      "allergens": [
        "대두"
      ]
    },
    {
      "id": "mushroom",
      "name": "모둠버섯",
      "aliases": [
        "버섯",
        "표고",
        "느타리"
      ],
      "shopId": "veg",
      "unit": "g",
      "pack": 200,
      "price": 4000,
      "allergens": []
    },
    {
      "id": "cabbage",
      "name": "알배추",
      "aliases": [
        "배추",
        "알배추"
      ],
      "shopId": "veg-cabbage",
      "unit": "g",
      "pack": 200,
      "price": 2000,
      "allergens": []
    },
    {
      "id": "onion",
      "name": "대파",
      "aliases": [
        "대파",
        "파"
      ],
      "shopId": "veg-green",
      "unit": "g",
      "pack": 50,
      "price": 1000,
      "allergens": []
    },
    {
      "id": "broth",
      "name": "채소육수",
      "aliases": [
        "육수"
      ],
      "shopId": "sauce-broth",
      "unit": "ml",
      "pack": 600,
      "price": 3500,
      "allergens": [
        "대두",
        "밀"
      ]
    },
    {
      "id": "shrimp",
      "name": "손질새우",
      "aliases": [
        "새우"
      ],
      "shopId": "sea",
      "unit": "g",
      "pack": 200,
      "price": 6500,
      "allergens": [
        "새우"
      ]
    },
    {
      "id": "fish",
      "name": "손질흰살생선",
      "aliases": [
        "생선",
        "흰살생선",
        "대구"
      ],
      "shopId": "sea-fish",
      "unit": "g",
      "pack": 200,
      "price": 6500,
      "allergens": [
        "생선"
      ]
    },
    {
      "id": "squid",
      "name": "손질오징어",
      "aliases": [
        "오징어"
      ],
      "shopId": "sea-squid",
      "unit": "g",
      "pack": 150,
      "price": 4500,
      "allergens": [
        "오징어"
      ]
    },
    {
      "id": "sauce",
      "name": "순한볶음소스",
      "aliases": [
        "소스",
        "양념"
      ],
      "shopId": "sauce",
      "unit": "g",
      "pack": 60,
      "price": 2500,
      "allergens": [
        "대두",
        "밀"
      ]
    },
    {
      "id": "pepper",
      "name": "매운양념",
      "aliases": [
        "고추",
        "매운양념",
        "고춧가루"
      ],
      "shopId": "sauce",
      "unit": "g",
      "pack": 20,
      "price": 500,
      "allergens": []
    },
    {
      "id": "beef",
      "name": "샤브용 소고기",
      "aliases": [
        "소고기",
        "쇠고기",
        "샤브고기"
      ],
      "shopId": "meat",
      "unit": "g",
      "pack": 200,
      "price": 8000,
      "allergens": [
        "쇠고기"
      ]
    },
    {
      "id": "chicken",
      "name": "손질닭고기",
      "aliases": [
        "닭고기",
        "닭다리살",
        "닭"
      ],
      "shopId": "meat-chicken",
      "unit": "g",
      "pack": 250,
      "price": 5500,
      "allergens": [
        "닭고기"
      ]
    },
    {
      "id": "radish",
      "name": "손질무",
      "aliases": [
        "무",
        "무우"
      ],
      "shopId": "veg-root",
      "unit": "g",
      "pack": 300,
      "price": 2000,
      "allergens": []
    },
    {
      "id": "clam",
      "name": "해감바지락",
      "aliases": [
        "바지락",
        "조개"
      ],
      "shopId": "sea-clam",
      "unit": "g",
      "pack": 300,
      "price": 5500,
      "allergens": [
        "조개류(바지락)"
      ]
    },
    {
      "id": "carrot",
      "name": "당근",
      "aliases": [
        "당근"
      ],
      "shopId": "veg-root",
      "unit": "g",
      "pack": 100,
      "price": 1000,
      "allergens": []
    },
    {
      "id": "zucchini",
      "name": "애호박",
      "aliases": [
        "애호박",
        "호박"
      ],
      "shopId": "veg-cabbage",
      "unit": "g",
      "pack": 200,
      "price": 2000,
      "allergens": []
    },
    {
      "id": "apple",
      "name": "사과",
      "aliases": [
        "사과"
      ],
      "shopId": "fruit",
      "unit": "g",
      "pack": 500,
      "price": 5000,
      "allergens": []
    },
    {
      "id": "mandarin",
      "name": "감귤",
      "aliases": [
        "감귤",
        "귤"
      ],
      "shopId": "fruit",
      "unit": "g",
      "pack": 500,
      "price": 4000,
      "allergens": []
    },
    {
      "id": "perilla",
      "name": "깻잎",
      "aliases": [
        "깻잎"
      ],
      "shopId": "veg-leaf",
      "unit": "g",
      "pack": 50,
      "price": 1500,
      "allergens": []
    },
    {
      "id": "seaweed",
      "name": "건미역",
      "aliases": [
        "건미역",
        "미역"
      ],
      "shopId": "sea-dried",
      "unit": "g",
      "pack": 50,
      "price": 3000,
      "allergens": []
    },
    {
      "id": "pork",
      "name": "돼지고기",
      "aliases": [
        "돼지고기",
        "돼지"
      ],
      "shopId": "meat-pork",
      "unit": "g",
      "pack": 300,
      "price": 6000,
      "allergens": [
        "돼지고기"
      ]
    },
    {
      "id": "soft-tofu",
      "name": "연두부",
      "aliases": [
        "연두부"
      ],
      "shopId": "tofu-soft",
      "unit": "g",
      "pack": 300,
      "price": 2500,
      "allergens": [
        "대두"
      ]
    }
  ],
  "recipes": [
    {
      "id": "tofu-pot",
      "version": 2,
      "name": "버섯 가득 두부전골",
      "subtitle": "담백한 육수, 넉넉한 버섯",
      "team": "초록한상 팀",
      "servings": 2,
      "minutes": 20,
      "equipment": "냄비",
      "stock": 12,
      "fee": 4500,
      "lines": [
        {
          "id": "tofu",
          "quantity": 300,
          "removable": true
        },
        {
          "id": "mushroom",
          "quantity": 200,
          "removable": false
        },
        {
          "id": "cabbage",
          "quantity": 200,
          "removable": true
        },
        {
          "id": "onion",
          "quantity": 50,
          "removable": true
        },
        {
          "id": "broth",
          "quantity": 600,
          "removable": false
        }
      ],
      "additions": [
        "mushroom",
        "tofu",
        "cabbage"
      ],
      "swaps": [],
      "steps": [
        "냄비에 제공된 채소육수와 배추를 넣고 끓여주세요.",
        "버섯과 두부를 넣고 재료가 충분히 익도록 끓여주세요.",
        "대파를 넣고 마무리한 뒤 나누어 담아주세요."
      ],
      "spicy": false,
      "image": "/images/recipes/tofu-pot.webp",
      "note": "냄비 하나로 준비하는 맑은 전골. 시연용 원안이며 실제 판매 전 시험 조리가 필요합니다.",
      "category": "채소",
      "feeShopId": "tofu"
    },
    {
      "id": "sea-pot",
      "version": 2,
      "name": "온가족 맑은 해물전골",
      "subtitle": "손질 해물로 준비하는 저녁",
      "team": "바다채소 팀",
      "servings": 2,
      "minutes": 25,
      "equipment": "냄비",
      "stock": 8,
      "fee": 3500,
      "lines": [
        {
          "id": "shrimp",
          "quantity": 200,
          "removable": false
        },
        {
          "id": "squid",
          "quantity": 150,
          "removable": true
        },
        {
          "id": "cabbage",
          "quantity": 200,
          "removable": true
        },
        {
          "id": "onion",
          "quantity": 50,
          "removable": true
        },
        {
          "id": "broth",
          "quantity": 600,
          "removable": false
        }
      ],
      "additions": [
        "mushroom",
        "tofu",
        "cabbage"
      ],
      "swaps": [
        {
          "from": "shrimp",
          "to": "fish",
          "quantity": 200,
          "step": "새우 대신 제공된 흰살생선을 넣고 충분히 익혀주세요."
        }
      ],
      "steps": [
        "냄비에 채소육수와 배추를 넣고 끓여주세요.",
        "손질된 해물을 넣고 충분히 익혀주세요.",
        "대파를 넣고 마무리하세요. 생선 대체 시 잔가시를 확인하세요."
      ],
      "spicy": false,
      "note": "수산점과 채소점이 함께 준비하는 시연용 상품입니다.",
      "image": "/images/recipes/sea-pot.webp",
      "category": "수산",
      "feeShopId": "sea"
    },
    {
      "id": "shrimp-pan",
      "version": 2,
      "name": "새우버섯 한 팬 볶음",
      "subtitle": "팬 하나에 담은 든든함",
      "team": "바다초록 팀",
      "servings": 2,
      "minutes": 15,
      "equipment": "프라이팬",
      "stock": 10,
      "fee": 6000,
      "lines": [
        {
          "id": "shrimp",
          "quantity": 200,
          "removable": false
        },
        {
          "id": "mushroom",
          "quantity": 200,
          "removable": false
        },
        {
          "id": "onion",
          "quantity": 50,
          "removable": true
        },
        {
          "id": "sauce",
          "quantity": 60,
          "removable": false
        }
      ],
      "additions": [
        "mushroom",
        "tofu"
      ],
      "swaps": [],
      "steps": [
        "팬을 예열하고 집에 있는 식용유를 소량 둘러주세요.",
        "손질새우와 버섯을 넣고 충분히 익도록 볶아주세요.",
        "볶음소스와 대파를 넣고 고루 섞어 마무리하세요."
      ],
      "spicy": false,
      "note": "식용유는 집에서 준비합니다. 시연용 원안입니다.",
      "image": "/images/recipes/shrimp-pan.webp",
      "category": "수산",
      "feeShopId": "sea"
    },
    {
      "version": 2,
      "servings": 2,
      "spicy": false,
      "swaps": [],
      "id": "beef-pot",
      "name": "소고기 채소 샤브전골",
      "subtitle": "얇게 썬 소고기와 아삭한 채소",
      "team": "든든초록 팀",
      "category": "정육",
      "feeShopId": "meat",
      "minutes": 20,
      "equipment": "냄비",
      "stock": 9,
      "fee": 4500,
      "lines": [
        {
          "id": "beef",
          "quantity": 200,
          "removable": false
        },
        {
          "id": "cabbage",
          "quantity": 200,
          "removable": true
        },
        {
          "id": "mushroom",
          "quantity": 200,
          "removable": true
        },
        {
          "id": "onion",
          "quantity": 50,
          "removable": true
        },
        {
          "id": "broth",
          "quantity": 600,
          "removable": false
        }
      ],
      "additions": [
        "mushroom",
        "tofu",
        "cabbage"
      ],
      "steps": [
        "냄비에 채소육수와 배추를 넣고 끓여주세요.",
        "버섯과 소고기를 넣고 고기가 충분히 익도록 끓여주세요.",
        "대파를 넣고 마무리한 뒤 나누어 담아주세요."
      ],
      "note": "얇게 손질한 소고기를 사용하는 시연용 원안입니다. 실제 판매 전 시험 조리가 필요합니다.",
      "image": "/images/recipes/beef-pot.webp"
    },
    {
      "version": 2,
      "servings": 2,
      "spicy": false,
      "swaps": [],
      "id": "fish-radish",
      "name": "무를 곁들인 생선조림",
      "subtitle": "부드러운 흰살생선과 달큰한 무",
      "team": "바다한술 팀",
      "category": "수산",
      "feeShopId": "sea-fish",
      "minutes": 30,
      "equipment": "냄비",
      "stock": 7,
      "fee": 4000,
      "lines": [
        {
          "id": "fish",
          "quantity": 200,
          "removable": false
        },
        {
          "id": "radish",
          "quantity": 300,
          "removable": false
        },
        {
          "id": "onion",
          "quantity": 50,
          "removable": true
        },
        {
          "id": "sauce",
          "quantity": 60,
          "removable": false
        },
        {
          "id": "broth",
          "quantity": 300,
          "removable": false
        }
      ],
      "additions": [
        "radish",
        "tofu"
      ],
      "steps": [
        "냄비에 무와 채소육수를 넣고 무가 부드러워지도록 끓여주세요.",
        "흰살생선과 순한볶음소스를 넣고 속까지 충분히 익도록 조려주세요.",
        "대파를 넣어 마무리하고 생선의 잔가시를 확인하세요."
      ],
      "note": "맵지 않은 간장 계열 소스를 쓰는 시연용 조림입니다. 실제 판매 전 조리시간과 간 확인이 필요합니다.",
      "image": "/images/recipes/fish-radish.webp"
    },
    {
      "version": 2,
      "servings": 2,
      "spicy": false,
      "swaps": [],
      "id": "squid-pan",
      "name": "오징어 채소볶음",
      "subtitle": "탱글한 오징어와 채소의 한 팬 만남",
      "team": "바다채소 팀",
      "category": "수산",
      "feeShopId": "sea-squid",
      "minutes": 20,
      "equipment": "프라이팬",
      "stock": 8,
      "fee": 5000,
      "lines": [
        {
          "id": "squid",
          "quantity": 300,
          "removable": false
        },
        {
          "id": "cabbage",
          "quantity": 200,
          "removable": true
        },
        {
          "id": "carrot",
          "quantity": 100,
          "removable": true
        },
        {
          "id": "onion",
          "quantity": 50,
          "removable": true
        },
        {
          "id": "sauce",
          "quantity": 60,
          "removable": false
        }
      ],
      "additions": [
        "mushroom",
        "carrot",
        "cabbage"
      ],
      "steps": [
        "팬을 예열하고 집에 있는 식용유를 소량 둘러주세요.",
        "당근과 배추를 볶다가 손질오징어를 넣고 충분히 익혀주세요.",
        "순한볶음소스와 대파를 넣고 고루 볶아 마무리하세요."
      ],
      "note": "고춧가루 없이 담백하게 볶는 시연용 원안입니다. 식용유는 집에서 준비합니다.",
      "image": "/images/recipes/squid-pan.webp"
    },
    {
      "version": 2,
      "servings": 2,
      "spicy": false,
      "swaps": [],
      "id": "chicken-pan",
      "name": "닭고기 버섯볶음",
      "subtitle": "부드러운 닭고기에 버섯을 넉넉히",
      "team": "든든버섯 팀",
      "category": "정육",
      "feeShopId": "meat-chicken",
      "minutes": 25,
      "equipment": "프라이팬",
      "stock": 10,
      "fee": 5000,
      "lines": [
        {
          "id": "chicken",
          "quantity": 250,
          "removable": false
        },
        {
          "id": "mushroom",
          "quantity": 200,
          "removable": false
        },
        {
          "id": "carrot",
          "quantity": 100,
          "removable": true
        },
        {
          "id": "onion",
          "quantity": 50,
          "removable": true
        },
        {
          "id": "sauce",
          "quantity": 60,
          "removable": false
        }
      ],
      "additions": [
        "mushroom",
        "carrot",
        "zucchini"
      ],
      "steps": [
        "팬을 예열하고 집에 있는 식용유를 소량 둘러주세요.",
        "손질닭고기와 당근을 넣고 볶다가 버섯을 넣어 고기 중심까지 충분히 익혀주세요.",
        "순한볶음소스와 대파를 넣고 고루 볶아 마무리하세요."
      ],
      "note": "닭고기의 중심까지 충분한 가열이 필요한 시연용 원안입니다. 실제 판매 전 시험 조리가 필요합니다.",
      "image": "/images/recipes/chicken-pan.webp"
    },
    {
      "version": 2,
      "servings": 2,
      "spicy": false,
      "swaps": [],
      "id": "clam-soup",
      "name": "바지락 채소 맑은탕",
      "subtitle": "시원한 바지락에 채소를 더한 국물",
      "team": "바다맑음 팀",
      "category": "수산",
      "feeShopId": "sea-clam",
      "minutes": 20,
      "equipment": "냄비",
      "stock": 8,
      "fee": 4000,
      "lines": [
        {
          "id": "clam",
          "quantity": 300,
          "removable": false
        },
        {
          "id": "radish",
          "quantity": 150,
          "removable": true
        },
        {
          "id": "zucchini",
          "quantity": 200,
          "removable": true
        },
        {
          "id": "onion",
          "quantity": 50,
          "removable": true
        },
        {
          "id": "broth",
          "quantity": 600,
          "removable": false
        }
      ],
      "additions": [
        "tofu",
        "zucchini",
        "radish"
      ],
      "steps": [
        "냄비에 채소육수와 무를 넣고 끓여주세요.",
        "해감한 바지락과 애호박을 넣고 충분히 끓여주세요.",
        "대파를 넣고 마무리하세요. 손질과 보관 상태를 확인한 바지락을 사용하세요."
      ],
      "note": "해감 완료된 바지락을 제공한다는 시연용 구성입니다. 실제 판매 전 원재료 관리와 시험 조리가 필요합니다.",
      "image": "/images/recipes/clam-soup.webp"
    },
    {
      "version": 2,
      "servings": 2,
      "spicy": false,
      "swaps": [],
      "id": "veggie-bowl",
      "name": "구운 채소 두부 한상",
      "subtitle": "노릇한 두부와 색색의 구운 채소",
      "team": "초록두부 팀",
      "category": "채소",
      "feeShopId": "tofu",
      "minutes": 20,
      "equipment": "프라이팬",
      "stock": 12,
      "fee": 4000,
      "lines": [
        {
          "id": "tofu",
          "quantity": 300,
          "removable": false
        },
        {
          "id": "zucchini",
          "quantity": 200,
          "removable": true
        },
        {
          "id": "carrot",
          "quantity": 100,
          "removable": true
        },
        {
          "id": "mushroom",
          "quantity": 200,
          "removable": true
        },
        {
          "id": "sauce",
          "quantity": 60,
          "removable": false
        }
      ],
      "additions": [
        "mushroom",
        "tofu",
        "zucchini"
      ],
      "steps": [
        "두부의 물기를 제거하고 채소를 먹기 좋게 준비해주세요.",
        "팬에 집에 있는 식용유를 소량 두른 뒤 두부와 채소를 충분히 익도록 구워주세요.",
        "구운 두부와 채소를 담고 순한볶음소스를 곁들여주세요."
      ],
      "note": "밥이 포함되지 않은 두부·채소 한상 시연 상품입니다. 식용유는 집에서 준비합니다.",
      "image": "/images/recipes/veggie-bowl.webp"
    }
  ],
  "seedVersion": 2
};
export const fields=["people","meal","occasion","taste","budget","time","equipment","pantry","add","exclude","substitute","notes"] as const;
export type MealInput=Record<typeof fields[number],string>;
export const emptyInput:MealInput=Object.fromEntries(fields.map(k=>[k,""])) as MealInput;
export function money(v:number){return new Intl.NumberFormat("ko-KR").format(v)+"원"}
export function recipePrice(recipe:Recipe,catalog:Catalog){return recipe.fee+recipe.lines.reduce((sum,l)=>{const p=catalog.ingredients.find(i=>i.id===l.id)!;return sum+p.price*l.quantity/p.pack},0)}
export type Evidence={evidence:string;reason:string};
export type GroundedValue<T>=Evidence & {value:T};
export type Unresolved={type:"not_registered"|"no_rule"|"health_claim"|"ambiguous";text:string};
// recipeId is a model selection from registered originals, so it does not claim an explicit user change.
export type Intent={recipeId:string|null;servings:GroundedValue<number|null>;budget:GroundedValue<number|null>;minutes:GroundedValue<number|null>;equipment:GroundedValue<string|null>;spicy:GroundedValue<boolean|null>;excluded:(Evidence & {id:string})[];pantry:(Evidence & {id:string;quantity:number|null})[];additions:(Evidence & {id:string;quantity:number|null})[];swapRuleIds:(Evidence & {id:string})[];allergy:GroundedValue<boolean>;unresolved:Unresolved[];context:string};
export type EvidenceCheck=Evidence & {field:string;status:"accepted"|"rejected";message:string};
export type Plan={id:string;catalogRevision:number;recipeId:string;recipeVersion:number;name:string;team:string;servings:number;minutes:number;equipment:string;lines:{id:string;name:string;shopId:string;quantity:number;unit:string;price:number;source:"market"|"home"}[];fee:number;total:number;originalTotal:number;changes:{label:string;detail:string}[];steps:string[];warnings:string[];blocked:boolean;mode:"live"|"demo"|"original";context:string;input:MealInput;createdAt:string;evidenceChecks?:EvidenceCheck[];unresolved?:Unresolved[]};
