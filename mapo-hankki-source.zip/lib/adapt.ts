import {type Catalog,type MealInput,type Intent,type Plan,fields,recipePrice} from "./catalog";
function numberText(s:string){return s.replace(/두\s*명/g,"2명").replace(/세\s*명/g,"3명").replace(/네\s*명/g,"4명").replace(/한\s*명/g,"1명");}
function findIds(s:string,c:Catalog){return c.ingredients.filter(i=>i.aliases.some(a=>a==="파"?/(?:^|\s)파(?:\s|$)/.test(s):s.includes(a))).map(i=>i.id)}
function quantity(s:string,id:string,c:Catalog){const i=c.ingredients.find(x=>x.id===id)!;for(const a of i.aliases){const m=s.match(new RegExp(a+"\\s*(\\d+(?:\\.\\d+)?)\\s*(kg|g|ml|그램|킬로|팩|모|개)?","i"));if(m)return Number(m[1])*(m[2]==="kg"||m[2]==="킬로"?1000:m[2]==="팩"||m[2]==="모"?i.pack:1)}return null}
export function demoIntent(input:MealInput,c:Catalog):Intent{
 const people=numberText(input.people);const counts=[...people.matchAll(/(\d+)\s*(?:명|인|인분)/g)].map(m=>+m[1]);const servings=counts.length?counts.reduce((a,b)=>a+b,0):/^\d+$/.test(people.trim())?+people:null;
 const bm=input.budget.replace(/,/g,"").match(/(\d+(?:\.\d+)?)\s*(만|천)?/);const budget=bm?Number(bm[1])*(bm[2]==="만"?10000:bm[2]==="천"?1000:1):null;
 const tm=input.time.match(/(\d+)\s*(시간|분)?/);const minutes=tm?+tm[1]*(tm[2]==="시간"?60:1):null;
 let recipeId:string|null=null;const menu=input.meal+input.occasion;
 if(/볶음|팬/.test(menu))recipeId="shrimp-pan";else if(/해물|수산|생선|새우/.test(menu))recipeId="sea-pot";else if(/두부|버섯|전골|국물|따뜻/.test(menu))recipeId="tofu-pot";
 const ex=findIds(input.exclude,c);const all=fields.map(k=>input[k]).join(" ");const allergy=/알레르기|알러지|allerg/i.test(all);
 let spicy:null|boolean=null;if(/안\s*맵|맵지|순한|담백/.test(input.taste))spicy=false;else if(/맵|매콤/.test(input.taste))spicy=true;
 const subs=input.substitute.split(/대신|→|에서/);const swaps=subs.length===2?findIds(subs[0],c).slice(0,1).flatMap(from=>findIds(subs[1],c).slice(0,1).map(to=>({from,to}))):[];
 const unresolved:string[]=[];
 if(input.meal&&!recipeId&&!/상관|아무|없/.test(input.meal))unresolved.push("시연 모드에서 해당 메뉴를 이해하지 못했습니다. 등록 원안을 선택하거나 AI 모드를 사용해주세요.");
 if(input.people&&servings===null)unresolved.push("인원을 숫자로 확인해 주세요. 현재 원안 인분을 적용했습니다.");
 if(input.substitute&&!swaps.length)unresolved.push("대체할 재료를 ‘새우 대신 생선’처럼 적어주세요.");
 for(const [key,label] of [["add","추가"],["exclude","제외"],["pantry","보유"]] as const){if(input[key]&&!findIds(input[key],c).length&&!/없|상관/.test(input[key]))unresolved.push(`${label} 요청 ‘${input[key]}’은 등록 재료로 확인하지 못했습니다.`)}
 for(const key of ["add","pantry","exclude"] as const){let remainder=input[key];for(const item of c.ingredients)for(const alias of [...item.aliases].sort((a,b)=>b.length-a.length))remainder=remainder.split(alias).join("");remainder=remainder.replace(/\d+(?:\.\d+)?\s*(?:kg|g|ml|그램|킬로|팩|모|개)?/g,"").replace(/없음|상관없음|넉넉히|추가|보유|제외|조금|더|있어요|있음|으로|하고|이랑|[과와,，\s]/g,"");if(remainder)unresolved.push(`시연 모드가 ${key==="add"?"추가":key==="pantry"?"보유":"제외"} 조건을 모두 이해하지 못했어요. AI 모드를 사용하거나 재료명과 g/ml 단위로 적어주세요.`)}
 const nuanced=[input.occasion,input.notes,input.taste].filter(s=>s&&!/안\s*맵|맵지|순한|담백/.test(s));if(nuanced.length)unresolved.push("시연 모드에서는 상황·기타 취향을 의미까지 이해하지 못합니다. 입력 메모를 확인해 주세요.");
 return {recipeId,servings,budget,minutes,equipment:input.equipment||null,spicy,excluded:ex,pantry:findIds(input.pantry,c).map(id=>({id,quantity:quantity(input.pantry,id,c)})),additions:findIds(input.add,c).map(id=>({id,quantity:quantity(input.add,id,c)})),swaps,allergy,unresolved,context:input.meal||"시장의 원안으로 준비하는 한 끼"};
}
export function makePlan(input:MealInput,intent:Intent,c:Catalog,mode:"live"|"demo"):Plan{
 const r=c.recipes.find(x=>x.id===intent.recipeId)||c.recipes[0];
 const warnings=[...intent.unresolved];const changes:Plan["changes"]=[];let blocked=false;
 const block=(s:string)=>{warnings.push(s);blocked=true};
 if(intent.recipeId&&!c.recipes.some(x=>x.id===intent.recipeId))block("선택한 원안이 등록되어 있지 않습니다.");
 for(const id of [...intent.excluded,...intent.pantry.map(i=>i.id),...intent.additions.map(i=>i.id),...intent.swaps.flatMap(i=>[i.from,i.to])])if(!c.ingredients.some(i=>i.id===id))block("등록되지 않은 재료 변경이 있습니다. 상인 확인이 필요합니다.");
 const duplicate=(ids:string[])=>new Set(ids).size!==ids.length;
 if(duplicate(intent.additions.map(i=>i.id))||duplicate(intent.pantry.map(i=>i.id))||duplicate(intent.swaps.map(i=>i.from)))block("중복된 재료 변경이 있습니다. 다시 만들어주세요.");
 const requested=intent.servings??r.servings;
 const servings=[2,3,4].includes(requested)?requested:r.servings;
 if(![2,3,4].includes(requested))block("시연 상품은 2–4인분만 준비할 수 있습니다. 인원을 수정해주세요.");
 const ratio=servings/r.servings;
 if(servings!==r.servings)changes.push({label:`${r.servings}인분 → ${servings}인분`,detail:"원안 비율에 따라 재료 분량과 가격을 조정했어요."});
 let lines=r.lines.map(l=>({id:l.id,quantity:l.quantity*ratio,home:false,removable:l.removable}));
 const steps=[...r.steps];
 for(const swap of intent.swaps){const rule=r.swaps.find(s=>s.from===swap.from&&s.to===swap.to);const old=lines.find(l=>l.id===swap.from);if(!rule||!old){block("요청한 재료 대체는 이 원안의 허용 범위에 없습니다. 상인 검토가 필요합니다.");continue}const to=c.ingredients.find(i=>i.id===swap.to)!;const from=c.ingredients.find(i=>i.id===swap.from)!;old.id=swap.to;old.quantity=rule.quantity*ratio;steps[1]=`${rule.step} ${lines.some(l=>l.id==="squid")?"오징어도 함께 넣고 충분히 익혀주세요.":""}`;changes.push({label:`${from.name} → ${to.name}`,detail:"원안에 등록된 대체 재료와 조리 안내를 적용했어요."})}
 for(const id of intent.excluded){const l=lines.find(x=>x.id===id);const item=c.ingredients.find(i=>i.id===id);if(!item){block("등록되지 않은 제외 재료가 있습니다.");continue}if(l){if(!l.removable){block(`${item.name}은 이 원안의 핵심 재료여서 제외할 수 없습니다. 다른 원안을 선택해주세요.`)}else{lines=lines.filter(x=>x.id!==id);changes.push({label:`${item.name} 제외`,detail:"등록된 제외 옵션의 금액을 차감했어요."})}}}
 for(const add of intent.additions){const p=c.ingredients.find(i=>i.id===add.id);if(!p||!r.additions.includes(add.id)){block("요청한 추가 재료는 이 원안에서 바로 주문할 수 없습니다.");continue}if(intent.excluded.includes(add.id)){block(`${p.name}의 추가와 제외가 동시에 요청되었습니다.`);continue}const q=add.quantity??p.pack;if(q<=0||q>p.pack*2||q%p.pack!==0){block(`${p.name} 추가는 ${p.pack}${p.unit} 단위, 최대 ${p.pack*2}${p.unit}까지 가능합니다.`);continue}const l=lines.find(x=>x.id===add.id);if(l)l.quantity+=q;else lines.push({id:add.id,quantity:q,home:false,removable:true});changes.push({label:`${p.name} ${q}${p.unit} 추가`,detail:`등록된 추가 옵션을 적용했어요.${add.quantity===null?` 분량 미지정으로 ${p.pack}${p.unit}을 제안합니다.`:""}`});steps.splice(1,0,`${p.name} 추가분을 같은 재료의 투입 단계에 함께 넣으세요. 새로 추가한 두부·버섯은 주재료와 함께 충분히 익혀주세요.`)}
 for(const home of intent.pantry){const l=lines.find(x=>x.id===home.id);if(!l)continue;const p=c.ingredients.find(i=>i.id===home.id)!;if(!l.removable){block(`${p.name}은 기본 구성에 포함되어 보유 재료로 차감할 수 없습니다. 보유 재료 요청을 수정하거나 다른 원안을 선택해주세요.`);continue}if(home.quantity===null||home.quantity<l.quantity){block(`집에 있는 ${p.name}이 ${l.quantity}${p.unit} 이상인지 입력해주세요.`);continue}l.home=true;changes.push({label:`${p.name} · 집에서 준비`,detail:`${l.quantity}${p.unit}을 구매 목록에서 제외하고 금액을 차감했어요.`})}
 if(intent.spicy===true)block("현재 원안에는 매운 양념 변형이 등록되어 있지 않습니다.");
 if(intent.allergy||/알레르기|알러지|allerg/i.test(fields.map(k=>input[k]).join(" ")))block("알레르기 요청은 원재료·소스·교차접촉에 대한 상인 확인이 필요합니다. 시연 주문을 진행하지 않습니다.");
 if(intent.equipment&&(!["냄비","프라이팬","팬","냄비, 프라이팬"].includes(intent.equipment)||(!intent.equipment.includes(r.equipment)&&!(r.equipment==="프라이팬"&&intent.equipment==="팬"))))block(`이 원안은 ${r.equipment} 조리만 등록되어 있습니다.`);
 const processingChanges=intent.swaps.length>0||intent.additions.length>0||servings!==r.servings;
 if(intent.minutes!==null&&intent.minutes<r.minutes)block(`원안의 조리시간은 ${r.minutes}분입니다. 요청하신 ${intent.minutes}분 내 조리는 확인되지 않았습니다.`);
 if(processingChanges)warnings.push(`변형 후 조리시간은 시험 확인이 필요합니다. 표시된 ${r.minutes}분은 원안 기준입니다.`);
 if(r.stock<=0)block("선택한 원안이 품절되었습니다. 다른 메뉴를 선택해주세요.");
 if(intent.unresolved.length)blocked=true;
 const rendered=lines.map(l=>{const p=c.ingredients.find(i=>i.id===l.id)!;return{id:l.id,name:p.name,shopId:p.shopId,quantity:l.quantity,unit:p.unit,price:l.home?0:Math.round(p.price*l.quantity/p.pack),source:l.home?"home" as const:"market" as const}});
 const fee=Math.round(r.fee*ratio);const total=fee+rendered.reduce((s,l)=>s+l.price,0);
 if(intent.budget!==null&&total>intent.budget)block(`총 ${total.toLocaleString("ko-KR")}원으로 예산 ${intent.budget.toLocaleString("ko-KR")}원을 초과합니다.`);
 if(!changes.length)changes.push({label:"원안 그대로",detail:"추가 변경 없이 상인 팀의 기본 구성을 유지했어요."});
 // Removed optional ingredients are explicitly omitted from the original cooking steps.
 const removed=intent.excluded.map(id=>c.ingredients.find(i=>i.id===id)?.name).filter(Boolean);
 if(removed.length)steps.unshift(`아래 원안 조리 안내에서 ${removed.join(", ")}은 사용하지 마세요. 제외된 재료의 투입은 건너뜁니다.`);
 return{id:crypto.randomUUID(),catalogRevision:c.revision,recipeId:r.id,recipeVersion:r.version,name:r.name,team:r.team,servings,minutes:r.minutes,equipment:r.equipment,lines:rendered,fee,total,originalTotal:recipePrice(r,c),changes,steps,warnings:[...new Set(warnings)],blocked,mode,context:intent.context,input,createdAt:new Date().toISOString()};
}
