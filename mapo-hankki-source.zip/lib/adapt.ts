import {type Catalog,type MealInput,type Intent,type Plan,type Unresolved,fields,recipePrice} from "./catalog";
import {registeredSwapRules,validateIntentEvidence} from "./intent";
export {emptyIntent} from "./intent";
function numberText(s:string){return s.replace(/두\s*명/g,"2명").replace(/세\s*명/g,"3명").replace(/네\s*명/g,"4명").replace(/한\s*명/g,"1명");}
function escapeRegex(s:string){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");}
// Korean ingredient particles may follow a name, but another word may not contain it.
function aliasPattern(alias:string){return `(?<![\\p{L}\\p{N}])${escapeRegex(alias)}(?=$|[^\\p{L}\\p{N}]|\\d|(?:으로|이랑|하고|은|는|이|가|을|를|과|와|도|만|로|랑)(?=$|[^\\p{L}\\p{N}]|\\d))`;}
function aliasRegex(alias:string,global=false){return new RegExp(aliasPattern(alias),global?"giu":"iu");}
function findIds(s:string,c:Catalog){return c.ingredients.filter(i=>i.aliases.some(a=>aliasRegex(a).test(s))).map(i=>i.id)}
function quantity(s:string,id:string,c:Catalog){const i=c.ingredients.find(x=>x.id===id)!;for(const a of [...i.aliases].sort((a,b)=>b.length-a.length)){const m=s.match(new RegExp(aliasPattern(a)+"(?:은|는|이|가|을|를)?\\s*(\\d+(?:\\.\\d+)?)\\s*(kg|g|ml|그램|킬로|팩|모|개)?","iu"));if(m)return Number(m[1])*(m[2]==="kg"||m[2]==="킬로"?1000:m[2]==="팩"||m[2]==="모"?i.pack:1)}return null}
export function demoIntent(input:MealInput,c:Catalog):Intent{
 const people=numberText(input.people);const counts=[...people.matchAll(/(\d+)\s*(?:명|인|인분)/g)].map(m=>+m[1]);const servings=counts.length?counts.reduce((a,b)=>a+b,0):/^\d+$/.test(people.trim())?+people:null;
 const bm=input.budget.replace(/,/g,"").match(/(\d+(?:\.\d+)?)\s*(만|천)?/);const budget=bm?Number(bm[1])*(bm[2]==="만"?10000:bm[2]==="천"?1000:1):null;
 const tm=input.time.match(/(\d+)\s*(시간|분)?/);const minutes=tm?+tm[1]*(tm[2]==="시간"?60:1):null;
 const menu=[input.meal,input.occasion].join(" ");
 let recipeId:string|null=c.recipes.find(r=>menu.includes(r.name))?.id??null;
 if(!recipeId){
  if(/beef|소고기|쇠고기|샤브/i.test(menu))recipeId="beef-pot";
  else if(/닭고기|닭다리|닭볶음|치킨/.test(menu)||aliasRegex("닭").test(menu))recipeId="chicken-pan";
  else if(/바지락|조개/.test(menu))recipeId="clam-soup";
  else if(/생선|대구/.test(menu)&&(/조림/.test(menu)||aliasRegex("무").test(menu)))recipeId="fish-radish";
  else if(/오징어/.test(menu)&&/볶음/.test(menu))recipeId="squid-pan";
  else if(/구운\s*채소|채소\s*두부|한상/.test(menu))recipeId="veggie-bowl";
  else if(/볶음|팬/.test(menu))recipeId="shrimp-pan";
  else if(/해물|수산|생선|새우/.test(menu))recipeId="sea-pot";
  else if(/두부|버섯|전골|국물|따뜻/.test(menu))recipeId="tofu-pot";
 }
 const ex=findIds(input.exclude,c);const all=fields.map(k=>input[k]).join(" ");const allergy=/알레르기|알러지|allerg/i.test(all);
 let spicy:null|boolean=null;if(/안\s*맵|맵지|순한|담백/.test(input.taste))spicy=false;else if(/맵|매콤/.test(input.taste))spicy=true;
 const subs=input.substitute.split(/대신|→|에서/);const swaps=subs.length===2?findIds(subs[0],c).slice(0,1).flatMap(from=>findIds(subs[1],c).slice(0,1).map(to=>({from,to}))):[];
 const unresolved:Unresolved[]=[];
 const unresolvedText=(text:string,type:Unresolved["type"]="ambiguous")=>unresolved.push({type,text});
 if(input.meal&&!recipeId&&!/상관|아무|없/.test(input.meal))unresolvedText("시연 모드에서 해당 메뉴를 이해하지 못했습니다. 등록 원안을 선택하거나 AI 모드를 사용해주세요.");
 if(input.people&&servings===null)unresolvedText("인원을 숫자로 확인해 주세요. 현재 원안 인분을 적용했습니다.");
 if(input.substitute&&!swaps.length)unresolvedText("대체할 재료를 ‘새우 대신 생선’처럼 적어주세요.");
 for(const [key,label] of [["add","추가"],["exclude","제외"],["pantry","보유"]] as const){if(input[key]&&!findIds(input[key],c).length&&!/없|상관/.test(input[key]))unresolvedText(`${label} 요청 ‘${input[key]}’은 등록 재료로 확인하지 못했습니다.`)}
 for(const key of ["add","pantry","exclude"] as const){let remainder=input[key];for(const item of c.ingredients)for(const alias of [...item.aliases].sort((a,b)=>b.length-a.length))remainder=remainder.replace(aliasRegex(alias,true),"");remainder=remainder.replace(/\d+(?:\.\d+)?\s*(?:kg|g|ml|그램|킬로|팩|모|개)?/g,"").replace(/없음|상관없음|넉넉히|추가|보유|제외|조금|더|있어요|있음|으로|하고|이랑|[은는이가을를과와도만,，\s]/g,"");if(remainder)unresolvedText(`시연 모드가 ${key==="add"?"추가":key==="pantry"?"보유":"제외"} 조건을 모두 이해하지 못했어요. AI 모드를 사용하거나 재료명과 g/ml 단위로 적어주세요.`)}
 const nuanced=[input.occasion,input.notes,input.taste].filter(s=>s&&!/안\s*맵|맵지|순한|담백|매콤|매운|맵게/.test(s));if(nuanced.length)unresolvedText("시연 모드에서는 상황·기타 취향을 의미까지 이해하지 못합니다. 입력 메모를 확인해 주세요.");
 const scalar=<T>(value:T,evidence:string,reason:string)=>({value,evidence:value===null?"":evidence,reason:value===null?"":reason});
 const rules=registeredSwapRules(c);
 const swapRuleIds=swaps.flatMap(swap=>{const rule=rules.find(rule=>rule.from===swap.from&&rule.to===swap.to);if(!rule){unresolvedText(`요청한 대체 ‘${input.substitute}’는 등록된 대체 규칙이 없습니다.`,"no_rule");return []}return [{id:rule.id,evidence:input.substitute,reason:"등록된 재료 대체 요청을 적용합니다."}]});
 const allergyEvidence=fields.map(k=>input[k]).find(value=>/알레르기|알러지|allerg/i.test(value))||"";
 return {recipeId,servings:scalar(servings,input.people,"명시한 인원을 합산합니다."),budget:scalar(budget,input.budget,"명시한 예산을 원 단위로 해석합니다."),minutes:scalar(minutes,input.time,"명시한 시간을 분 단위로 해석합니다."),equipment:scalar(input.equipment||null,input.equipment,"사용 가능한 조리 도구를 확인합니다."),spicy:scalar(spicy,input.taste,"입력한 매운맛 취향을 반영합니다."),excluded:ex.map(id=>({id,evidence:input.exclude,reason:"명시한 제외 요청을 반영합니다."})),pantry:findIds(input.pantry,c).map(id=>({id,quantity:quantity(input.pantry,id,c),evidence:input.pantry,reason:"명시한 집 재료와 분량을 확인합니다."})),additions:findIds(input.add,c).map(id=>({id,quantity:quantity(input.add,id,c),evidence:input.add,reason:"명시한 구매 추가 요청을 반영합니다."})),swapRuleIds,allergy:{value:allergy,evidence:allergyEvidence,reason:allergy?"알레르기는 상인 확인이 필요합니다.":""},unresolved,context:input.meal||"시장의 원안으로 준비하는 한 끼"};
}
export function makePlan(input:MealInput,rawIntent:Intent,c:Catalog,mode:Plan["mode"]):Plan{
 const checked=validateIntentEvidence(input,rawIntent,c);const intent=checked.intent;
 const r=c.recipes.find(x=>x.id===intent.recipeId)||c.recipes[0];
 const warnings=[...checked.warnings,...intent.unresolved.map(issue=>issue.text)];const changes:Plan["changes"]=[];let blocked=checked.blocked;
 const evidenceChecks=checked.evidenceChecks;const unresolved=[...intent.unresolved];
 const block=(s:string,type:Unresolved["type"]="no_rule")=>{warnings.push(s);if(!unresolved.some(issue=>issue.text===s))unresolved.push({type,text:s});blocked=true};
 if(intent.recipeId&&!c.recipes.some(x=>x.id===intent.recipeId))block("선택한 원안이 등록되어 있지 않습니다.");
 for(const id of [...intent.excluded.map(i=>i.id),...intent.pantry.map(i=>i.id),...intent.additions.map(i=>i.id)])if(!c.ingredients.some(i=>i.id===id))block("등록되지 않은 재료 변경이 있습니다. 상인 확인이 필요합니다.");
 const duplicate=(ids:string[])=>new Set(ids).size!==ids.length;
 if(duplicate(intent.additions.map(i=>i.id))||duplicate(intent.pantry.map(i=>i.id))||duplicate(intent.swapRuleIds.map(i=>i.id)))block("중복된 재료 변경이 있습니다. 다시 만들어주세요.");
 const requested=intent.servings.value??r.servings;
 const servings=[2,3,4].includes(requested)?requested:r.servings;
 if(![2,3,4].includes(requested))block("시연 상품은 2–4인분만 준비할 수 있습니다. 인원을 수정해주세요.");
 const ratio=servings/r.servings;
 if(servings!==r.servings)changes.push({label:`${r.servings}인분 → ${servings}인분`,detail:"원안 비율에 따라 재료 분량과 가격을 조정했어요."});
 let lines=r.lines.map(l=>({id:l.id,quantity:l.quantity*ratio,home:false,removable:l.removable}));
 const steps=[...r.steps];const removedIds:string[]=[];
 for(const swap of intent.swapRuleIds){const rule=registeredSwapRules(c).find(s=>s.id===swap.id&&s.recipeId===r.id);const old=rule?lines.find(l=>l.id===rule.from):undefined;if(!rule||!old){block("요청한 재료 대체는 이 원안의 허용 범위에 없습니다. 상인 검토가 필요합니다.");continue}const to=c.ingredients.find(i=>i.id===rule.to)!;const from=c.ingredients.find(i=>i.id===rule.from)!;old.id=rule.to;old.quantity=rule.quantity*ratio;steps[1]=`${rule.step} ${lines.some(l=>l.id==="squid")?"오징어도 함께 넣고 충분히 익혀주세요.":""}`;changes.push({label:`${from.name} → ${to.name}`,detail:"원안에 등록된 대체 재료와 조리 안내를 적용했어요."})}
 for(const {id} of intent.excluded){const l=lines.find(x=>x.id===id);const item=c.ingredients.find(i=>i.id===id);if(!item){block("등록되지 않은 제외 재료가 있습니다.","not_registered");continue}if(!l){block(`${item.name}은 선택 원안의 구성에 없어 제외 요청을 적용하지 않았습니다.`);continue}if(!l.removable){block(`${item.name}은 이 원안의 핵심 재료여서 제외할 수 없습니다. 다른 원안을 선택해주세요.`)}else{lines=lines.filter(x=>x.id!==id);removedIds.push(id);changes.push({label:`${item.name} 제외`,detail:"등록된 제외 옵션의 금액을 차감했어요."})}}
 for(const add of intent.additions){const p=c.ingredients.find(i=>i.id===add.id);if(!p||!r.additions.includes(add.id)){block("요청한 추가 재료는 이 원안에서 바로 주문할 수 없습니다.");continue}if(intent.excluded.some(item=>item.id===add.id)){block(`${p.name}의 추가와 제외가 동시에 요청되었습니다.`);continue}const q=add.quantity??p.pack;if(q<=0||q>p.pack*2||q%p.pack!==0){block(`${p.name} 추가는 ${p.pack}${p.unit} 단위, 최대 ${p.pack*2}${p.unit}까지 가능합니다.`);continue}const l=lines.find(x=>x.id===add.id);if(l)l.quantity+=q;else lines.push({id:add.id,quantity:q,home:false,removable:true});changes.push({label:`${p.name} ${q}${p.unit} 추가`,detail:`등록된 추가 옵션을 적용했어요.${add.quantity===null?` 분량 미지정으로 ${p.pack}${p.unit}을 제안합니다.`:""}`});steps.splice(1,0,`${p.name} 추가분을 같은 재료의 투입 단계에 함께 넣으세요. 새로 추가한 두부·버섯은 주재료와 함께 충분히 익혀주세요.`)}
 for(const home of intent.pantry){const l=lines.find(x=>x.id===home.id);const p=c.ingredients.find(i=>i.id===home.id)!;if(!l){block(`${p.name}은 선택 원안의 구성에 없어 보유 재료 차감 요청을 적용하지 않았습니다.`);continue}if(!l.removable){block(`${p.name}은 기본 구성에 포함되어 보유 재료로 차감할 수 없습니다. 보유 재료 요청을 수정하거나 다른 원안을 선택해주세요.`);continue}if(home.quantity===null||home.quantity<l.quantity){block(`집에 있는 ${p.name}이 ${l.quantity}${p.unit} 이상인지 입력해주세요.`,"ambiguous");continue}l.home=true;changes.push({label:`${p.name} · 집에서 준비`,detail:`${l.quantity}${p.unit}을 구매 목록에서 제외하고 금액을 차감했어요.`})}
 if(intent.spicy.value!==null&&intent.spicy.value!==r.spicy)block(r.spicy?"현재 원안에는 매운맛을 줄이는 변형이 등록되어 있지 않습니다.":"현재 원안에는 매운 양념 변형이 등록되어 있지 않습니다.");
 if(intent.allergy.value||/알레르기|알러지|allerg/i.test(fields.map(k=>input[k]).join(" ")))block("알레르기 요청은 원재료·소스·교차접촉에 대한 상인 확인이 필요합니다. 시연 주문을 진행하지 않습니다.","health_claim");
 if(/저염|저당|저나트륨|저혈당|질병식|당뇨|신장질환|고혈압|질환|치료|혈당|나트륨|글루텐\s*프리|gluten\s*free|무글루텐|임산부|임신|이유식|면역|저칼로리|저지방|무설탕|무염/i.test(fields.map(k=>input[k]).join(" ")))block("건강·질병식 요청에 대한 정량 변형과 적합성은 등록되어 있지 않습니다. 상인 확인 후 입력을 수정해주세요.","health_claim");
 if(intent.equipment.value&&(!["냄비","프라이팬","팬","냄비, 프라이팬"].includes(intent.equipment.value)||(!intent.equipment.value.includes(r.equipment)&&!(r.equipment==="프라이팬"&&intent.equipment.value==="팬"))))block(`이 원안은 ${r.equipment} 조리만 등록되어 있습니다.`);
 const processingChanges=intent.swapRuleIds.length>0||intent.additions.length>0||servings!==r.servings;
 if(intent.minutes.value!==null&&intent.minutes.value<r.minutes)block(`원안의 조리시간은 ${r.minutes}분입니다. 요청하신 ${intent.minutes.value}분 내 조리는 확인되지 않았습니다.`);
 if(processingChanges)warnings.push(`변형 후 조리시간은 시험 확인이 필요합니다. 표시된 ${r.minutes}분은 원안 기준입니다.`);
 if(r.stock<=0)block("선택한 원안이 품절되었습니다. 다른 메뉴를 선택해주세요.");
 if(intent.unresolved.length)blocked=true;
 const rendered=lines.map(l=>{const p=c.ingredients.find(i=>i.id===l.id)!;return{id:l.id,name:p.name,shopId:p.shopId,quantity:l.quantity,unit:p.unit,price:l.home?0:Math.round(p.price*l.quantity/p.pack),source:l.home?"home" as const:"market" as const}});
 const fee=Math.round(r.fee*ratio);const total=fee+rendered.reduce((s,l)=>s+l.price,0);
 if(intent.budget.value!==null&&total>intent.budget.value)block(`총 ${total.toLocaleString("ko-KR")}원으로 예산 ${intent.budget.value.toLocaleString("ko-KR")}원을 초과합니다.`);
 if(!changes.length)changes.push({label:"원안 그대로",detail:"추가 변경 없이 상인 팀의 기본 구성을 유지했어요."});
 // Removed optional ingredients are explicitly omitted from the original cooking steps.
 const removed=removedIds.map(id=>c.ingredients.find(i=>i.id===id)?.name).filter(Boolean);
 if(removed.length)steps.unshift(`아래 원안 조리 안내에서 ${removed.join(", ")}은 사용하지 마세요. 제외된 재료의 투입은 건너뜁니다.`);
 return{id:crypto.randomUUID(),catalogRevision:c.revision,recipeId:r.id,recipeVersion:r.version,name:r.name,team:r.team,servings,minutes:r.minutes,equipment:r.equipment,lines:rendered,fee,total,originalTotal:recipePrice(r,c),changes,steps,warnings:[...new Set(warnings)],blocked,mode,context:intent.context,input,createdAt:new Date().toISOString(),evidenceChecks,unresolved};
}
