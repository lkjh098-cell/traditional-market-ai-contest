import type {Catalog,Evidence,Intent,MealInput,Recipe} from './catalog';

export type FlavorRule={id:string;kind:'garlic'|'seasoning';label:string;ingredientId:string;mode:'add'|'scale';quantity:number;step:string};
export function registeredFlavorRules(catalog:Catalog){return catalog.recipes.flatMap(recipe=>(recipe.flavorRules??[]).filter(rule=>catalog.ingredients.some(i=>i.id===rule.ingredientId)).map(rule=>({...rule,recipeId:recipe.id})));}
const patterns:{suffix:string;pattern:RegExp}[]=[
 {suffix:'garlic-more',pattern:/(?:다진\s*)?마늘(?:은|을|향은|향을|향)?\s*(?:좀\s*)?(?:많이|듬뿍|넉넉히|풍부하게|진하게)(?:\s*(?:넣어\s*주세요|넣어줘|넣고\s*싶어요|넣기|주세요|해\s*주세요|해줘))?/g},
 {suffix:'garlic-less',pattern:/(?:다진\s*)?마늘(?:은|을|향은|향을|향)?\s*(?:조금|적게|살짝)(?:\s*(?:넣어\s*주세요|넣어줘|주세요|해줘))?/g},
 {suffix:'seasoning-less',pattern:/(?:간(?:은|을)?\s*(?:약하게|싱겁게)|양념(?:은|을)?\s*(?:적게|조금|약하게)|담백하게)(?:\s*(?:해\s*주세요|해주세요|해줘|주세요|먹고\s*싶어요))?/g},
 {suffix:'seasoning-more',pattern:/(?:간(?:은|을)?\s*(?:세게|진하게)|양념(?:은|을)?\s*(?:많이|진하게)|진한\s*풍미)(?:\s*(?:해\s*주세요|해주세요|해줘|주세요))?/g},
];
// Deterministic aliases are narrowly bounded to registered merchant rules, not free-text memos.
export function parseFlavorRequests(input:MealInput,catalog:Catalog,recipeId:string){
 const rules=registeredFlavorRules(catalog).filter(r=>r.recipeId===recipeId);
 const requests:(Evidence & {id:string})[]=[];let remainder=input.taste;
 for(const {suffix,pattern} of patterns){pattern.lastIndex=0;for(const match of input.taste.matchAll(pattern)){
  const rule=rules.find(r=>r.id===`${recipeId}:${suffix}`);if(!rule)continue;
  const evidence=match[0];
  // Negated/quoted examples are not customer requests.
  if(/아니|말고|넣지|원치|예시|예를|라고\s*(?:하면|쓰면)/.test(input.taste))continue;
  requests.push({id:rule.id,evidence,reason:`상인 등록 옵션 ‘${rule.label}’의 정량 기준을 적용합니다.`});remainder=remainder.replace(evidence,'');
 }}
 remainder=remainder.replace(/(?:그리고|하고|또|으로|해주세요|해\s*주세요|좋아요|좋겠어요|원해요|원합니다|부탁해요|[은는이가을를과와도,，.·!\s])/g,'');
 return {requests,fullySupported:requests.length>0&&!remainder};
}
export function normalizeFlavorIntent(input:MealInput,intent:Intent,catalog:Catalog):Intent{
 const recipeId=intent.recipeId??catalog.recipes[0]?.id;if(!recipeId)return intent;
 const parsed=parseFlavorRequests(input,catalog,recipeId);if(!parsed.requests.length)return intent;
 const result=structuredClone(intent);result.flavorRuleIds??=[];
 // A qualitative garlic preference uses the registered amount; avoid a second one-pack default.
 result.additions=result.additions.filter(add=>!(add.id==='garlic'&&add.quantity===null&&parsed.requests.some(entry=>entry.id.includes(':garlic-')&&add.evidence.includes(entry.evidence))&&!input.add.includes(add.evidence)));
 for(const entry of parsed.requests)if(!result.flavorRuleIds.some(existing=>existing.id===entry.id))result.flavorRuleIds.push(entry);
 // Clear only an explicitly named supported request. Unknown mixed requests and health flags remain.
 if(parsed.fullySupported)result.unresolved=result.unresolved.filter(issue=>issue.type==='health_claim'||!parsed.requests.some(entry=>issue.text.includes(entry.evidence)||issue.text.includes(input.taste)));
 return result;
}
export function flavorRuleForRecipe(recipe:Recipe,id:string){return recipe.flavorRules?.find(rule=>rule.id===id);}
