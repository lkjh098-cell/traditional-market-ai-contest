import {worldPoint,type LatLng} from './market-geo';

export type MapCamera={center:LatLng;zoom:number};
export type ScreenPoint={x:number;y:number};
export type MapSize={width:number;height:number};
export const clampMapZoom=(zoom:number)=>Math.max(16,Math.min(21,zoom));

function fromWorld({x,y}:ScreenPoint):LatLng{
 return {lng:x/256*360-180,lat:Math.atan(Math.sinh(Math.PI*(1-2*y/256)))*180/Math.PI};
}

/** Move/zoom the camera while retaining the same world coordinate beneath the anchor. */
export function anchoredCamera(camera:MapCamera,zoom:number,from:ScreenPoint,to:ScreenPoint,size:MapSize):MapCamera{
 const nextZoom=clampMapZoom(zoom),world=worldPoint(camera.center);
 return {zoom:nextZoom,center:fromWorld({
  x:world.x+(from.x-size.width/2)/2**camera.zoom-(to.x-size.width/2)/2**nextZoom,
  y:world.y+(from.y-size.height/2)/2**camera.zoom-(to.y-size.height/2)/2**nextZoom,
 })};
}

/** One affine transform applies to both the loaded satellite frame and its geographic overlays. */
export function cameraTransform(base:MapCamera,target:MapCamera){
 const a=worldPoint(base.center),b=worldPoint(target.center);
 return {scale:2**(target.zoom-base.zoom),x:(a.x-b.x)*2**target.zoom,y:(a.y-b.y)*2**target.zoom};
}

export function cameraScreenPoint(camera:MapCamera,point:LatLng,size:MapSize):ScreenPoint{
 const a=worldPoint(camera.center),b=worldPoint(point),scale=2**camera.zoom;
 return {x:size.width/2+(b.x-a.x)*scale,y:size.height/2+(b.y-a.y)*scale};
}

export function snapCamera(camera:MapCamera,anchor:ScreenPoint,size:MapSize):MapCamera{
 return anchoredCamera(camera,Math.round(camera.zoom),anchor,anchor,size);
}

export function pointerGeometry(points:ScreenPoint[]){
 const a=points[0],b=points[1];
 return {midpoint:b?{x:(a.x+b.x)/2,y:(a.y+b.y)/2}:a,distance:b?Math.hypot(b.x-a.x,b.y-a.y):0};
}

/** WheelEvent uses pixels, lines, or pages depending on the input device/browser. */
export function wheelPixels(delta:number,mode:number,pageHeight:number){
 return delta*(mode===1?16:mode===2?pageHeight:1);
}
