import {fields,type Catalog,type Intent,type MealInput} from './catalog';
import {emptyIntent} from './intent';
// Safety requests remain attached to the original plan and cannot be bypassed by recovery.
export function hasSafetyRequest(input:MealInput){return /알레르기|알러지|allerg|저염|저당|저나트륨|저혈당|질병식|당뇨|신장질환|고혈압|질환|치료|혈당|나트륨|글루텐\s*프리|gluten\s*free|무글루텐|임산부|임신|이유식|면역|저칼로리|저지방|무설탕|무염/i.test(fields.map(k=>input[k]).join(' '))}
export function hasInput(input:MealInput){return fields.some(k=>input[k].trim().length>0)}
export function originalIntent(input:MealInput,catalog:Catalog,selected:unknown,discardConstraints:unknown):Intent{
 if(typeof selected!=='string'||!catalog.recipes.some(r=>r.id===selected))throw new Error('원안 그대로 준비하려면 등록된 원안을 먼저 선택해주세요.');
 if(hasSafetyRequest(input))throw new Error('알레르기·건강 조건은 상인 확인이 필요해 원안 구매로 바로 넘어갈 수 없습니다.');
 if(hasInput(input)&&discardConstraints!==true)throw new Error('입력한 변경 조건을 적용하지 않는다는 안내를 확인해주세요.');
 const intent=emptyIntent(selected);
 intent.context=hasInput(input)?'직접 선택한 상인 원안 그대로입니다. 입력한 인원·예산·취향·재료 변경 조건은 적용하지 않았어요.':'직접 선택한 상인 원안의 인분·재료·금액을 확인해주세요.';
 return intent;
}
