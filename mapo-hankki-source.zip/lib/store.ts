import {env} from "cloudflare:workers";
import {initialCatalog,type Catalog} from "./catalog";
export function database(){if(!env.DB)throw new Error("저장소가 아직 준비되지 않았습니다.");return env.DB;}
export async function readCatalog():Promise<Catalog>{const db=database();await db.prepare("INSERT OR IGNORE INTO catalog_state(id,revision,data) VALUES('main',1,?)").bind(JSON.stringify(initialCatalog)).run();const row=await db.prepare("SELECT data FROM catalog_state WHERE id='main'").first<{data:string}>();if(!row)throw new Error("상품 정보를 불러오지 못했습니다.");return JSON.parse(row.data)}
export async function updateCatalog(c:Catalog,oldRevision:number){const next={...c,revision:oldRevision+1};const result=await database().prepare("UPDATE catalog_state SET revision=?,data=? WHERE id='main' AND revision=?").bind(next.revision,JSON.stringify(next),oldRevision).run();if(!result.meta.changes)throw new Error("다른 변경 사항이 있습니다. 새로고침 후 다시 시도해주세요.");return next}
