// Google Maps JavaScript API 동적 로더 (브라우저 전용)
import {googleMapsScriptUrl} from './market-geo';

/* eslint-disable @typescript-eslint/no-explicit-any */
export type GoogleNamespace=any;
type MapsWindow=Window&{google?:GoogleNamespace;__mapoGoogleMapsReady?:()=>void;gm_authFailure?:()=>void};

let pending:Promise<GoogleNamespace>|null=null;
const authListeners=new Set<()=>void>();

/** 키 인증 실패(잘못된 키·리퍼러 제한 불일치)는 지도 생성 뒤 전역 콜백으로만 알려진다. */
export function onGoogleMapsAuthFailure(listener:()=>void){
 authListeners.add(listener);
 return ()=>{authListeners.delete(listener)};
}

export function loadGoogleMaps(key:string,timeoutMs=12000):Promise<GoogleNamespace>{
 const w=window as MapsWindow;
 if(w.google?.maps?.Map&&w.google?.maps?.OverlayView)return Promise.resolve(w.google);
 if(pending)return pending;
 pending=new Promise((resolve,reject)=>{
  const timer=window.setTimeout(()=>fail(new Error('Google 지도 로딩 시간이 초과되었습니다.')),timeoutMs);
  const fail=(error:Error)=>{window.clearTimeout(timer);pending=null;reject(error)};
  w.__mapoGoogleMapsReady=()=>{window.clearTimeout(timer);resolve(w.google)};
  w.gm_authFailure=()=>{for(const l of authListeners)l()};
  const script=document.createElement('script');
  script.src=googleMapsScriptUrl(key);
  script.async=true;
  script.onerror=()=>{script.remove();fail(new Error('Google 지도 스크립트를 불러오지 못했습니다.'))};
  document.head.appendChild(script);
 });
 return pending;
}

/** 지도 위 HTML 마커 레이어. data-lat/data-lng 속성이 있는 자식을 좌표 위치로 옮긴다. */
export type HtmlLayer={draw:()=>void;setMap:(map:unknown)=>void};
export function createHtmlLayer(google:GoogleNamespace,container:HTMLElement):HtmlLayer{
 const Base=google.maps.OverlayView as {new():any;preventMapHitsFrom?:(el:HTMLElement)=>void};
 class Layer extends Base{
  onAdd(){
   container.style.position='absolute';container.style.left='0';container.style.top='0';
   // Keep marker clicks separate while allowing the SDK to receive drag, pinch and wheel gestures.
   Base.preventMapHitsFrom?.(container);
   this.getPanes().overlayMouseTarget.appendChild(container);
  }
  draw(){
   const projection=this.getProjection();if(!projection)return;
   container.querySelectorAll<HTMLElement>('[data-lat][data-lng]').forEach(el=>{
    const p=projection.fromLatLngToDivPixel(new google.maps.LatLng(Number(el.dataset.lat),Number(el.dataset.lng)));
    if(p){el.style.left=`${p.x}px`;el.style.top=`${p.y}px`;}
   });
  }
  onRemove(){container.remove()}
 }
 return new Layer() as unknown as HtmlLayer;
}
