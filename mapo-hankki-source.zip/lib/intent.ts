import {z} from 'zod';
import {fields,type Catalog,type EvidenceCheck,type Intent,type MealInput} from './catalog';

export const swapRuleId=(recipeId:string,from:string,to:string)=>`${recipeId}:${from}>${to}`;
export function registeredSwapRules(catalog:Catalog){return catalog.recipes.flatMap(recipe=>recipe.swaps.map(rule=>({id:swapRuleId(recipe.id,rule.from,rule.to),recipeId:recipe.id,...rule})));}
const evidenceShape={evidence:z.string().max(500),reason:z.string().max(600)};
const nullableValue=<T extends z.ZodTypeAny>(value:T)=>z.object({value:value.nullable(),...evidenceShape}).strict();
const enumOf=(values:string[]):z.ZodType<string>=>values.length?z.enum(values as [string,...string[]]):z.never();

// The wire schema and local validator both derive identifiers from the current catalog.
export function createIntentSchema(catalog:Catalog):z.ZodType<Intent>{
 const ingredient=enumOf(catalog.ingredients.map(i=>i.id));
 const item=z.object({id:ingredient,quantity:z.number().finite().positive().max(1_000_000).nullable(),...evidenceShape}).strict();
 const identified=(id:z.ZodType<string>)=>z.object({id,...evidenceShape}).strict();
 return z.object({
  recipeId:enumOf(catalog.recipes.map(r=>r.id)).nullable(),
  servings:nullableValue(z.number().finite().int().positive().max(100)),
  budget:nullableValue(z.number().finite().positive().max(1_000_000_000)),
  minutes:nullableValue(z.number().finite().positive().max(1440)),
  equipment:nullableValue(z.string().min(1).max(100)),spicy:nullableValue(z.boolean()),
  excluded:z.array(identified(ingredient)).max(catalog.ingredients.length),
  pantry:z.array(item).max(catalog.ingredients.length),additions:z.array(item).max(catalog.ingredients.length),
  swapRuleIds:z.array(identified(enumOf(registeredSwapRules(catalog).map(r=>r.id)))).max(registeredSwapRules(catalog).length),
  allergy:z.object({value:z.boolean(),...evidenceShape}).strict(),
  unresolved:z.array(z.object({type:z.enum(['not_registered','no_rule','health_claim','ambiguous']),text:z.string().trim().min(1).max(1000)}).strict()).max(24),
  context:z.string().max(1200)
 }).strict() as z.ZodType<Intent>;
}
export const intentSchema=createIntentSchema;

type JsonSchema=Record<string,unknown>;
const objectSchema=(properties:Record<string,JsonSchema>):JsonSchema=>({type:'object',properties,required:Object.keys(properties),additionalProperties:false});
const textSchema:JsonSchema={type:'string'};
const evidenceProperties={evidence:textSchema,reason:textSchema};
// Structured Outputs requires every property, including nullable scalars, and additionalProperties:false.
export function buildIntentJsonSchema(catalog:Catalog):JsonSchema{
 const idSchema=(ids:string[]):JsonSchema=>ids.length?{type:'string',enum:ids}:{type:'null'};
 const scalar=(type:string)=>objectSchema({value:{type:[type,'null']},...evidenceProperties});
 const ingredient=idSchema(catalog.ingredients.map(i=>i.id));
 const entry=objectSchema({id:ingredient,quantity:{type:['number','null']},...evidenceProperties});
 const array=(items:JsonSchema,maxItems:number):JsonSchema=>({type:'array',items,maxItems});
 return objectSchema({
  recipeId:{type:['string','null'],enum:[...catalog.recipes.map(r=>r.id),null]},
  servings:scalar('number'),budget:scalar('number'),minutes:scalar('number'),equipment:scalar('string'),spicy:scalar('boolean'),
  excluded:array(objectSchema({id:ingredient,...evidenceProperties}),catalog.ingredients.length),
  pantry:array(entry,catalog.ingredients.length),additions:array(entry,catalog.ingredients.length),
  swapRuleIds:array(objectSchema({id:idSchema(registeredSwapRules(catalog).map(r=>r.id)),...evidenceProperties}),registeredSwapRules(catalog).length),
  allergy:objectSchema({value:{type:'boolean'},...evidenceProperties}),
  unresolved:array(objectSchema({type:{type:'string',enum:['not_registered','no_rule','health_claim','ambiguous']},text:textSchema}),24),
  context:textSchema
 });
}

export function emptyIntent(recipeId?:string):Intent{
 const empty=<T>(value:T)=>({value,evidence:'',reason:''});
 return {recipeId:recipeId??null,servings:empty(null),budget:empty(null),minutes:empty(null),equipment:empty(null),spicy:empty(null),excluded:[],pantry:[],additions:[],swapRuleIds:[],allergy:empty(false),unresolved:[],context:'등록 원안의 구성을 확인해주세요.'};
}

export function validateIntentEvidence(input:MealInput,raw:unknown,catalog:Catalog):{intent:Intent;evidenceChecks:EvidenceCheck[];warnings:string[];blocked:boolean}{
 const evidenceChecks:EvidenceCheck[]=[];
 const result=createIntentSchema(catalog).safeParse(raw);
 if(!result.success){
  for(const issue of result.error.issues){
   let entry:unknown=raw;
   for(const part of issue.path.slice(0,-1))entry=entry&&typeof entry==='object'?(entry as Record<string,unknown>)[String(part)]:undefined;
   const attempted=entry&&typeof entry==='object'?entry as Record<string,unknown>:{};
   evidenceChecks.push({field:issue.path.join('.')||'intent',evidence:typeof attempted.evidence==='string'?attempted.evidence:'',reason:typeof attempted.reason==='string'?attempted.reason:'',status:'rejected',message:'등록된 해석 구조·ID·수량 범위를 벗어나 해석 결과의 변경을 적용하지 않았습니다.'});
  }
  const recipeId=raw&&typeof raw==='object'?(raw as Record<string,unknown>).recipeId:null;
  const intent=emptyIntent(typeof recipeId==='string'&&catalog.recipes.some(recipe=>recipe.id===recipeId)?recipeId:undefined);
  intent.unresolved=result.error.issues.map(issue=>({type:issue.path[0]==='swapRuleIds'?'no_rule':issue.code==='invalid_enum_value'?'not_registered':'ambiguous',text:`${issue.path.join('.')||'intent'} 해석 결과가 등록된 형식·ID·수량 범위를 벗어났습니다.`}));
  return {intent,evidenceChecks,warnings:['해석 결과에 등록되지 않은 값이나 잘못된 수량이 있어 변경을 적용하지 않았습니다. 입력을 수정해 다시 만들어주세요.'],blocked:true};
 }
 const intent=result.data as Intent;
 const warnings:string[]=[];
 const accept=(field:string,entry:{evidence:string;reason:string},extra?:string)=>{
  // Matching a quotation checks provenance only; it does not prove the interpretation is semantically correct.
  const grounded=entry.evidence.trim().length>0&&fields.some(k=>typeof input[k]==='string'&&input[k].includes(entry.evidence));
  const message=extra||(!grounded?'사용자 입력 한 항목에서 그대로 인용된 근거를 찾지 못했습니다.':!entry.reason.trim()?'변경 이유가 없습니다.':'입력에서 인용 근거를 확인했습니다. 의미 해석의 정확성을 보증하지 않습니다.');
  const status=!extra&&grounded&&entry.reason.trim()?'accepted':'rejected';
  evidenceChecks.push({field,evidence:entry.evidence,reason:entry.reason,status,message});
  if(status==='rejected')warnings.push(`${field} 변경을 적용하지 않았습니다. ${message} 입력을 수정해 다시 만들어주세요.`);
  return status==='accepted';
 };
 for(const field of ['servings','budget','minutes','equipment','spicy'] as const){const entry=intent[field];if(entry.value!==null&&!accept(field,entry))Object.assign(entry,{value:null});}
 if(intent.allergy.value&&!accept('allergy',intent.allergy))intent.allergy.value=false;
 for(const field of ['excluded','pantry','additions','swapRuleIds'] as const){
  const entries=intent[field];const duplicateIds=new Set(entries.filter((entry,index)=>entries.findIndex(e=>e.id===entry.id)!==index).map(e=>e.id));
  const accepted=entries.filter((entry,index)=>{
   const item=catalog.ingredients.find(i=>i.id===entry.id);
   const quantity='quantity' in entry?entry.quantity:null;
   const extra=duplicateIds.has(entry.id)?'같은 변경 ID가 중복되어 있습니다.':typeof quantity==='number'&&item&&quantity>item.pack*(field==='additions'?2:100)?'재료 분량이 등록된 한도를 초과했습니다.':undefined;
   return accept(`${field}[${index}]`,entry,extra);
  });
  // Every array member has the same evidence contract; assignment preserves its field-specific type.
  Object.assign(intent,{[field]:accepted});
 }
 for(const check of evidenceChecks.filter(check=>check.status==='rejected'))intent.unresolved.push({type:'ambiguous',text:`${check.field}: ${check.message}`});
 return {intent,evidenceChecks,warnings,blocked:evidenceChecks.some(check=>check.status==='rejected')};
}
