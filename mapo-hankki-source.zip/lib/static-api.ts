import {initialCatalog,type Catalog,type Plan,type Intent} from './catalog';
import {demoIntent,makePlan} from './adapt';
import type {ApiResults} from './api-types';
const KEY='mapo-public-demo-v1';
type State={catalog:Catalog;plans:Record<string,{plan:Plan;intent:Intent}>;used:string[]};
function read():State{try{const saved=JSON.parse(localStorage.getItem(KEY)||'null');if(saved?.catalog&&saved?.plans&&saved?.used)return saved}catch{}return{catalog:structuredClone(initialCatalog),plans:{},used:[]}}
function write(s:State){localStorage.setItem(KEY,JSON.stringify(s))}
// GitHub Pages is a browser-only demo. The production APIs live under app/api/.
export function staticApi<P extends keyof ApiResults>(path:P,body?:unknown):Promise<ApiResults[P]>;
export async function staticApi(path:string,body:any={}):Promise<unknown>{const s=read(),c=s.catalog;
if(path==='/api/catalog')return {catalog:c,aiConnected:false};
if(path==='/api/adapt'){if(body.mode==='live')throw new Error('이 공개 체험판은 규칙 기반 시연 모드입니다. 실제 AI는 서버 배포와 API 크레딧 설정 후 사용할 수 있어요.');const intent=demoIntent(body.input,c);if(body.recipeId)intent.recipeId=body.recipeId;const plan=makePlan(body.input,intent,c,'demo');s.plans[plan.id]={plan,intent};write(s);return{plan}}
if(path==='/api/admin'){if(body.revision!==c.revision)throw new Error('상품 정보가 바뀌었어요. 새로고침 후 저장해주세요.');const r=c.recipes.find(r=>r.id===body.id);if(!r)throw new Error('원안을 찾을 수 없어요.');if(!Number.isInteger(body.stock)||body.stock<0||body.stock>100||!Number.isInteger(body.fee)||body.fee<0||body.fee>50000||!Array.isArray(body.steps)||!body.steps.length)throw new Error('수량·준비비·조리법을 확인해주세요.');const changed=r.fee!==body.fee||r.subtitle!==body.subtitle||JSON.stringify(r.steps)!==JSON.stringify(body.steps);Object.assign(r,{stock:body.stock,fee:body.fee,subtitle:String(body.subtitle).slice(0,120),steps:body.steps,version:r.version+(changed?1:0)});c.revision++;write(s);return{catalog:c}}
if(path==='/api/orders'){if(!body.planIds?.length)throw new Error('밀키트를 먼저 담아주세요.');const plans:Plan[]=[];for(const id of body.planIds){const saved=s.plans[id];if(!saved||s.used.includes(id))throw new Error('이미 예약했거나 만료된 구성이에요. 다시 만들어주세요.');const r=c.recipes.find(r=>r.id===saved.plan.recipeId);if(!r||r.version!==saved.plan.recipeVersion||saved.plan.blocked)throw new Error('원안이 바뀌었어요. 구성을 다시 만들어주세요.');const fresh=makePlan(saved.plan.input,saved.intent,c,'demo');if(fresh.blocked||fresh.total!==saved.plan.total)throw new Error('품절 또는 구성 변경이 있어요. 다시 확인해주세요.');r.stock--;plans.push(saved.plan)}const extra=(body.extras||[]).reduce((sum:number,e:{id:string;count:number})=>sum+(c.ingredients.find(i=>i.id===e.id)?.price||0)*e.count,0);const receipt={code:'MP-'+crypto.randomUUID().slice(0,6).toUpperCase(),slot:body.slot,pickup:'시연 공동 픽업대 · 실제 장소 아님',total:plans.reduce((sum,p)=>sum+p.total,0)+extra,status:'시연 예약 완료'};c.revision++;s.used.push(...body.planIds);write(s);return{receipt,catalog:c}}
throw new Error('지원하지 않는 시연 기능입니다.');}
