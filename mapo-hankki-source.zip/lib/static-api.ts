import {initialCatalog,type Catalog,type Plan,type Intent} from './catalog';
import {demoIntent,makePlan} from './adapt';
import type {ApiResults,WorkflowAction,WorkflowOrder} from './api-types';
import {applyWorkflowAction,createWorkflowOrder,upgradeCatalog,validateExtras,validatePickupSlot,validatePlanIds,workflowReceipt} from './order-workflow';
import {hasInput,hasSafetyRequest,originalIntent} from './adaptation';
const KEY='mapo-public-demo-v2';
type State={catalog:Catalog;plans:Record<string,{plan:Plan;intent:Intent}>;used:string[];orders:WorkflowOrder[]};
function read():State{try{const saved=JSON.parse(localStorage.getItem(KEY)||'null');if(saved?.catalog&&saved?.plans&&Array.isArray(saved.used)){const catalog=upgradeCatalog(saved.catalog);if(JSON.stringify(catalog)!==JSON.stringify(saved.catalog))catalog.revision++;return{...saved,catalog,orders:Array.isArray(saved.orders)?saved.orders:[]};}}catch{}return{catalog:structuredClone(initialCatalog),plans:{},used:[],orders:[]}}
function write(s:State){localStorage.setItem(KEY,JSON.stringify(s))}
// GitHub Pages is a browser-only demo. The production APIs live under app/api/.
export function staticApi<P extends keyof ApiResults>(path:P,body?:unknown):Promise<ApiResults[P]>;
export async function staticApi(path:string,body:any={}):Promise<unknown>{const s=read(),c=s.catalog;
if(path==='/api/catalog')return {catalog:c,aiConnected:false};
if(path==='/api/adapt'){
 const original=body.original===true||(!hasInput(body.input)&&!!body.recipeId);
 if(body.mode==='live'&&!original)return{plan:null,aiError:{code:'unavailable',message:'이 공개 체험판은 규칙 기반 시연입니다. 실제 AI는 서버 연결 후 사용할 수 있어요.'},fallbackAvailable:!hasSafetyRequest(body.input)};
 if(body.recipeId&&!c.recipes.some(r=>r.id===body.recipeId))throw new Error('선택한 원안이 없습니다.');
 const intent=original?originalIntent(body.input,c,body.recipeId,body.discardConstraints):demoIntent(body.input,c);
 if(body.recipeId)intent.recipeId=body.recipeId;
 const plan=makePlan(body.input,intent,c,original?'original':'demo');
 if(original&&hasInput(body.input)&&!hasSafetyRequest(body.input))plan.warnings.push('원안 그대로 선택하여 입력한 변경 조건은 적용하지 않았습니다. 표시된 인분·재료·금액을 확인해주세요.');
 s.plans[plan.id]={plan,intent};write(s);return{plan}
}
if(path==='/api/admin'){if(body.revision!==c.revision)throw new Error('상품 정보가 바뀌었어요. 새로고침 후 저장해주세요.');const r=c.recipes.find(r=>r.id===body.id);if(!r)throw new Error('원안을 찾을 수 없어요.');if(!Number.isInteger(body.stock)||body.stock<0||body.stock>100||!Number.isInteger(body.fee)||body.fee<0||body.fee>50000||!Array.isArray(body.steps)||!body.steps.length)throw new Error('수량·준비비·조리법을 확인해주세요.');const changed=r.fee!==body.fee||r.subtitle!==body.subtitle||JSON.stringify(r.steps)!==JSON.stringify(body.steps);Object.assign(r,{stock:body.stock,fee:body.fee,subtitle:String(body.subtitle).slice(0,120),steps:body.steps,version:r.version+(changed?1:0)});c.revision++;write(s);return{catalog:c}}
if(path==='/api/workflow'){
 if(!body.action)return{orders:s.orders};const current=s.orders.find(o=>o.id===body.orderId);if(!current)throw new Error('예약을 찾을 수 없습니다.');const order=applyWorkflowAction(current,body as WorkflowAction,c);s.orders=s.orders.map(o=>o.id===order.id?order:o);write(s);return{orders:s.orders,order};
}
if(path==='/api/orders'){
 const ids=validatePlanIds(body.planIds),slot=validatePickupSlot(body.slot),extras=validateExtras(body.extras,c,body.sourceShopId),plans:Plan[]=[];
 for(const id of ids){const saved=s.plans[id];if(!saved||s.used.includes(id))throw new Error('이미 예약했거나 만료된 구성이에요. 다시 만들어주세요.');const r=c.recipes.find(r=>r.id===saved.plan.recipeId);if(!r||r.version!==saved.plan.recipeVersion||saved.plan.blocked)throw new Error('원안이 바뀌었어요. 구성을 다시 만들어주세요.');const fresh=makePlan(saved.plan.input,saved.intent,c,saved.plan.mode);if(fresh.blocked||fresh.total!==saved.plan.total||r.stock<=0)throw new Error('품절 또는 구성 변경이 있어요. 다시 확인해주세요.');r.stock--;plans.push(saved.plan);}
 const order=createWorkflowOrder(plans,extras,c,slot,body.sourceShopId),receipt=workflowReceipt(order);c.revision++;s.used.push(...ids);s.orders.unshift(order);write(s);return{receipt,catalog:c,order};
}
throw new Error('지원하지 않는 시연 기능입니다.');}
