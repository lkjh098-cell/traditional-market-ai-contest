import type {Catalog,Plan} from './catalog';
export type Receipt={code:string;slot:string;pickup:string;total:number;status:string};
export type AiErrorCode='refusal'|'incomplete'|'quota'|'rate_limit'|'unavailable'|'invalid_response';
export type AiFailure={code:AiErrorCode;message:string};
export type AdaptResult={plan:Plan;aiError?:never;fallbackAvailable?:never}|{plan:null;aiError:AiFailure;fallbackAvailable:boolean};
export type ApiResults={
 '/api/catalog':{catalog:Catalog;aiConnected:boolean};
 '/api/adapt':AdaptResult;
 '/api/orders':{catalog:Catalog;receipt:Receipt};
 '/api/admin':{catalog:Catalog};
};
