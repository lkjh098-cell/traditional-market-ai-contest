import type {Catalog,Plan} from './catalog';
export type Receipt={id?:string;orderId?:string;code:string;slot:string;pickup:string;total:number;status:string};
export type ShopTaskStatus='pending'|'preparing'|'ready';
export type WorkflowLine={id:string;name:string;quantity:number;unit:string;subtotal:number;kind:'meal'|'extra';planId?:string;count?:number;sourceShopId?:string};
export type ShopTask={shopId:string;shopName:string;status:ShopTaskStatus;lines:WorkflowLine[];ingredientTotal:number;preparationFee:number;total:number};
export type ExtraLine={id:string;name:string;shopId:string;count:number;price:number;quantity:number;unit:string;sourceShopId?:string};
export type WorkflowOrder={id:string;orderId:string;code:string;createdAt:string;slot:string;pickup:string;status:'pending'|'preparing'|'ready'|'collected'|'settled';plans:{id:string;name:string;servings:number;total:number}[];tasks:ShopTask[];extras:ExtraLine[];total:number;sourceShopId?:string;settlement:{status:'pending'|'confirmed';simulated:true;confirmedAt?:string};events:{at:string;label:string}[]};
export type WorkflowAction={action:'prepare'|'ready'|'collect'|'add_extra'|'settle';orderId:string;shopId?:string;ingredientId?:string;count?:number;sourceShopId?:string};
export type AiErrorCode='refusal'|'incomplete'|'quota'|'rate_limit'|'unavailable'|'invalid_response';
export type AiFailure={code:AiErrorCode;message:string};
export type AdaptResult={plan:Plan;aiError?:never;fallbackAvailable?:never}|{plan:null;aiError:AiFailure;fallbackAvailable:boolean};
export type ApiResults={
 '/api/catalog':{catalog:Catalog;aiConnected:boolean};
 '/api/adapt':AdaptResult;
 '/api/orders':{catalog:Catalog;receipt:Receipt;order:WorkflowOrder};
 '/api/admin':{catalog:Catalog};
 '/api/workflow':{orders:WorkflowOrder[];order?:WorkflowOrder};
};
