import type {Catalog,Plan} from './catalog';
export type Receipt={code:string;slot:string;pickup:string;total:number;status:string};
export type ApiResults={
 '/api/catalog':{catalog:Catalog;aiConnected:boolean};
 '/api/adapt':{plan:Plan};
 '/api/orders':{catalog:Catalog;receipt:Receipt};
 '/api/admin':{catalog:Catalog};
};
