// 고객 화면 주요 메뉴 순서: AI 한 끼 → 공동 메뉴 → 시장 지도 → 주문·픽업 → 추가 장보기
export type Page='map'|'meal'|'kits'|'shops'|'orders'|'admin'|'about';
export type NavItem={id:Page;label:string;short:string};
export const NAV_ITEMS:readonly NavItem[]=[
 {id:'meal',label:'AI 한 끼',short:'AI 한 끼'},
 {id:'kits',label:'공동 메뉴',short:'공동 메뉴'},
 {id:'map',label:'시장 지도',short:'시장 지도'},
 {id:'orders',label:'주문·픽업',short:'주문·픽업'},
 {id:'shops',label:'추가 장보기',short:'추가 장보기'},
];
/** 첫 화면은 메뉴 순서의 첫 항목(AI 한 끼) */
export const DEFAULT_PAGE:Page=NAV_ITEMS[0].id;
