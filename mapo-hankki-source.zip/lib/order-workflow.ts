import {initialCatalog,type Catalog,type Plan} from './catalog';
import type {ExtraLine,Receipt,ShopTask,WorkflowAction,WorkflowOrder} from './api-types';
export const PICKUP_SLOTS=['11:00–12:00','14:00–15:00','17:00–18:00'];
export const DEMO_PICKUP='시장 중심 공동 픽업대 · 시연 위치';
export function validatePlanIds(ids:unknown):string[]{if(!Array.isArray(ids)||!ids.length||ids.length>10||ids.some(id=>typeof id!=='string')||new Set(ids).size!==ids.length)throw new Error('장바구니를 확인해주세요.');return ids;}
export function validatePickupSlot(slot:unknown):string{if(typeof slot!=='string'||!PICKUP_SLOTS.includes(slot))throw new Error('픽업 시간을 선택해주세요.');return slot;}
function attribution(source:unknown,catalog:Catalog):string|undefined{if(source===undefined||source===null||source==='')return undefined;if(typeof source!=='string'||!catalog.shops.some(s=>s.id===source))throw new Error('안내 점포 정보를 확인해주세요.');return source;}
export function validateExtras(value:unknown,catalog:Catalog,source?:unknown):ExtraLine[]{
 const extras=value===undefined?[]:value;if(!Array.isArray(extras)||extras.length>20)throw new Error('추가 재료 수량을 확인해주세요.');
 const fallback=attribution(source,catalog);
 return extras.map((entry:unknown)=>{if(!entry||typeof entry!=='object')throw new Error('추가 재료를 확인해주세요.');const x=entry as Record<string,unknown>,i=catalog.ingredients.find(i=>i.id===x.id);if(!i||!Number.isInteger(x.count)||Number(x.count)<1||Number(x.count)>5)throw new Error('추가 재료를 확인해주세요.');const count=Number(x.count);return{id:i.id,name:i.name,shopId:i.shopId,count,price:i.price*count,quantity:i.pack*count,unit:i.unit,sourceShopId:attribution(x.sourceShopId,catalog)??fallback};});
}
function taskFor(tasks:ShopTask[],shopId:string,catalog:Catalog){let task=tasks.find(t=>t.shopId===shopId);if(!task){const shop=catalog.shops.find(s=>s.id===shopId);if(!shop)throw new Error('참여 점포를 확인해주세요.');task={shopId,shopName:shop.name,status:'pending',lines:[],ingredientTotal:0,preparationFee:0,total:0};tasks.push(task);}return task;}
function calculate(order:WorkflowOrder){for(const task of order.tasks){task.ingredientTotal=task.lines.reduce((s,l)=>s+l.subtotal,0);task.total=task.ingredientTotal+task.preparationFee;}order.total=order.tasks.reduce((s,t)=>s+t.total,0);if(order.settlement.status==='confirmed')order.status='settled';else if(order.status!=='collected')order.status=order.tasks.every(t=>t.status==='ready')?'ready':order.tasks.some(t=>t.status!=='pending')?'preparing':'pending';return order;}
export function createWorkflowOrder(plans:Plan[],extras:ExtraLine[],catalog:Catalog,slot:string,sourceShopId?:string,id=crypto.randomUUID(),now=new Date().toISOString()):WorkflowOrder{
 validatePickupSlot(slot);if(!plans.length||plans.some(p=>p.blocked)||new Set(plans.map(p=>p.id)).size!==plans.length)throw new Error('예약할 구성을 확인해주세요.');
 const order:WorkflowOrder={id,orderId:id,code:'MP-'+id.slice(0,6).toUpperCase(),createdAt:now,slot,pickup:DEMO_PICKUP,status:'pending',plans:plans.map(p=>({id:p.id,name:p.name,servings:p.servings,total:p.total})),tasks:[],extras:structuredClone(extras),total:0,sourceShopId:attribution(sourceShopId,catalog),settlement:{status:'pending',simulated:true},events:[{at:now,label:'공동 메뉴 시연 예약 · 실제 결제 없음'}]};
 for(const plan of plans){
  const market=plan.lines.filter(l=>l.source==='market'),ids=[...new Set(market.map(l=>l.shopId))];
  if(!ids.length)throw new Error('점포 준비 품목이 없는 구성입니다.');
  for(const line of market)taskFor(order.tasks,line.shopId,catalog).lines.push({id:line.id,name:line.name,quantity:line.quantity,unit:line.unit,subtotal:line.price,kind:'meal',planId:plan.id});
  const recipe=catalog.recipes.find(r=>r.id===plan.recipeId),feeShopId=(recipe as typeof recipe & {feeShopId?:string})?.feeShopId;
  if(feeShopId)taskFor(order.tasks,feeShopId,catalog).preparationFee+=plan.fee;
  else{const ingredientTotal=market.reduce((s,l)=>s+l.price,0);let allocated=0;ids.forEach((shopId,index)=>{const subtotal=market.filter(l=>l.shopId===shopId).reduce((s,l)=>s+l.price,0),fee=index===ids.length-1?plan.fee-allocated:Math.floor(plan.fee*(ingredientTotal?subtotal/ingredientTotal:1/ids.length));allocated+=fee;taskFor(order.tasks,shopId,catalog).preparationFee+=fee;});}
 }
 for(const extra of extras)taskFor(order.tasks,extra.shopId,catalog).lines.push({id:extra.id,name:extra.name,quantity:extra.quantity,unit:extra.unit,subtotal:extra.price,count:extra.count,kind:'extra',sourceShopId:extra.sourceShopId});
 calculate(order);const expected=plans.reduce((s,p)=>s+p.total,0)+extras.reduce((s,e)=>s+e.price,0);if(order.total!==expected)throw new Error('공동 주문 금액을 다시 확인해주세요.');return order;
}
export function workflowReceipt(order:WorkflowOrder):Receipt{return{id:order.id,orderId:order.id,code:order.code,slot:order.slot,pickup:order.pickup,total:order.total,status:'시연 예약 완료 · 실제 결제 없음'};}
export function applyWorkflowAction(current:WorkflowOrder,action:WorkflowAction,catalog:Catalog,now=new Date().toISOString()):WorkflowOrder{
 if(action.orderId!==current.id)throw new Error('예약을 찾을 수 없습니다.');const order=structuredClone(current);
 if(order.status==='settled'){if(action.action==='settle')return order;throw new Error('정산 확인을 마친 예약은 변경할 수 없습니다.');}
 let label='';
 if(action.action==='prepare'||action.action==='ready'){
  if(order.status==='collected')throw new Error('수령한 예약의 준비 상태는 변경할 수 없습니다.');const task=order.tasks.find(t=>t.shopId===action.shopId);if(!task)throw new Error('예약 참여 점포를 확인해주세요.');
  if(task.status==='ready'&&action.action==='prepare')throw new Error('준비 완료 점포는 이전 상태로 돌아갈 수 없습니다.');const status=action.action==='ready'?'ready':'preparing';if(task.status===status)return order;task.status=status;label=`${task.shopName} ${status==='ready'?'준비 완료':'준비 시작'}`;
 }else if(action.action==='collect'){
  if(order.status==='collected')return order;if(!order.tasks.every(t=>t.status==='ready'))throw new Error('모든 참여 점포가 준비 완료한 후 수령할 수 있습니다.');order.status='collected';label='공동 픽업 수령 확인';
 }else if(action.action==='add_extra'){
  const extra=validateExtras([{id:action.ingredientId,count:action.count,sourceShopId:action.sourceShopId}],catalog)[0];if(order.extras.length>=20)throw new Error('추가 구매는 20개 항목 이내로 가능합니다.');order.extras.push(extra);const task=taskFor(order.tasks,extra.shopId,catalog);task.lines.push({id:extra.id,name:extra.name,quantity:extra.quantity,unit:extra.unit,subtotal:extra.price,count:extra.count,kind:'extra',sourceShopId:extra.sourceShopId});task.status=order.status==='collected'?'ready':'pending';label=`현장 추가 구매 시연 · ${extra.name} ${extra.count}팩`;
 }else if(action.action==='settle'){
  if(order.status!=='collected')throw new Error('수령 확인 후 점포별 정산 내역을 확인할 수 있습니다.');order.settlement={status:'confirmed',simulated:true,confirmedAt:now};label='점포별 정산 확인 시연 · 실제 송금 없음';
 }else throw new Error('지원하지 않는 준비 작업입니다.');
 order.events.push({at:now,label});return calculate(order);
}
// Add newly released seed entries while preserving edited prices, recipes, stocks and revisions.
export function upgradeCatalog(saved:Catalog):Catalog{
 const next=structuredClone(saved);for(const field of ['shops','ingredients','recipes'] as const){const existing=new Set(next[field].map(item=>item.id));for(const seed of initialCatalog[field])if(!existing.has(seed.id))(next[field] as {id:string}[]).push(structuredClone(seed));}
 for(const recipe of next.recipes){const seed=initialCatalog.recipes.find(r=>r.id===recipe.id);if(seed){if((!recipe.image||recipe.image==='/images/jeongol.webp')&&seed.image)recipe.image=seed.image;const target=recipe as typeof recipe & {feeShopId?:string;category?:string},source=seed as typeof seed & {feeShopId?:string;category?:string};if(!target.feeShopId&&source.feeShopId)target.feeShopId=source.feeShopId;if(!target.category&&source.category)target.category=source.category;}}
 // 이전 SVG 안내도 좌표는 위성지도 배치(lib/market-geo)로 대체되었다.
 for(const shop of next.shops)delete (shop as typeof shop & {map?:unknown}).map;
 return next;
}
