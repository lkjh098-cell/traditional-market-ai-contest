// 마포농수산물시장 위성지도 좌표·투영·URL 유틸리티 (브라우저/서버 공용, 순수 함수)
export type LatLng={lat:number;lng:number};
export type GeoOffset={north:number;east:number};

/**
 * 시장 건물 중심 좌표.
 * OpenStreetMap 건물(way 38170384, amenity=marketplace) 중심점 37.56519, 126.8985 기준.
 * Waze(37.565222, 126.898512)·Tripadvisor(37.564907, 126.89858) 표기와 30m 이내로 일치한다.
 */
export const MARKET={
 name:'마포농수산물시장',
 address:'서울 마포구 월드컵로 235',
 center:{lat:37.56519,lng:126.8985} as LatLng,
 /** 데스크톱 기본 확대 수준(약 0.24m/px) */
 zoom:19,
 /** 폭이 좁은 화면(모바일)의 확대 수준 */
 compactZoom:18,
 compactWidth:560,
} as const;

/** 공동 픽업대는 시장 건물의 중심에 둔다. */
export const PICKUP_POINT:LatLng=MARKET.center;

/** 가상 점포의 기본 배치(픽업대 기준 북·동 방향 미터). 실제 점포 위치가 아니다. */
export const DEFAULT_SHOP_GEO:Record<string,GeoOffset>={
 "veg": {
  "north": 68,
  "east": -22
 },
 "veg-cabbage": {
  "north": 49,
  "east": -25
 },
 "veg-green": {
  "north": 28,
  "east": -19
 },
 "veg-root": {
  "north": -16,
  "east": -26
 },
 "veg-leaf": {
  "north": -42,
  "east": -20
 },
 "sea": {
  "north": 61,
  "east": 23
 },
 "sea-fish": {
  "north": 38,
  "east": 25
 },
 "sea-squid": {
  "north": 10,
  "east": 24
 },
 "sea-clam": {
  "north": -19,
  "east": 20
 },
 "sea-dried": {
  "north": -55,
  "east": 24
 },
 "meat": {
  "north": -73,
  "east": 18
 },
 "meat-chicken": {
  "north": -46,
  "east": 4
 },
 "meat-pork": {
  "north": -64,
  "east": -3
 },
 "tofu": {
  "north": 42,
  "east": 0
 },
 "tofu-soft": {
  "north": -69,
  "east": -25
 },
 "sauce": {
  "north": 74,
  "east": 2
 },
 "sauce-broth": {
  "north": -28,
  "east": -4
 },
 "fruit": {
  "north": 18,
  "east": 3
 }
};

const EARTH_RADIUS=6378137;
const TILE=256;

/** 픽업대(시장 중심)에서 북·동으로 m만큼 떨어진 좌표 */
export function offsetLatLng(origin:LatLng,{north,east}:GeoOffset):LatLng{
 const lat=origin.lat+(north/EARTH_RADIUS)*(180/Math.PI);
 const lng=origin.lng+(east/(EARTH_RADIUS*Math.cos(origin.lat*Math.PI/180)))*(180/Math.PI);
 return {lat:round(lat),lng:round(lng)};
}

/** 등록 점포가 아닌 경우를 위한 원형 배치(픽업대를 둘러싸는 반지름 34m) */
export function ringOffset(index:number,total:number,radius=34):GeoOffset{
 const n=Math.max(total,1),angle=(index/n)*Math.PI*2+Math.PI/2;
 return {north:round(Math.sin(angle)*radius,2),east:round(Math.cos(angle)*radius,2)};
}

type ShopLike={id:string;geo?:GeoOffset};
/** 점포 마커 좌표: catalog의 geo → 기본 배치 → 원형 배치 순으로 결정 */
export function shopLatLng(shop:ShopLike,index:number,total:number):LatLng{
 const geo=validOffset(shop.geo)?shop.geo:DEFAULT_SHOP_GEO[shop.id]||ringOffset(index,total);
 return offsetLatLng(PICKUP_POINT,geo);
}
function validOffset(v:unknown):v is GeoOffset{
 const g=v as GeoOffset|undefined;
 return !!g&&Number.isFinite(g.north)&&Number.isFinite(g.east)&&Math.abs(g.north)<=120&&Math.abs(g.east)<=120;
}

/** Web Mercator 세계 좌표(확대 0 기준 256px) */
export function worldPoint({lat,lng}:LatLng){
 const s=Math.min(Math.max(Math.sin(lat*Math.PI/180),-0.9999),0.9999);
 return {x:TILE*(0.5+lng/360),y:TILE*(0.5-Math.log((1+s)/(1-s))/(4*Math.PI))};
}

/** 지도 중심 기준 화면 픽셀 오프셋(동쪽 +x, 남쪽 +y). Google 지도 타일과 같은 투영을 쓴다. */
export function pixelOffset(center:LatLng,point:LatLng,zoom:number){
 const scale=2**zoom,a=worldPoint(center),b=worldPoint(point);
 return {x:round((b.x-a.x)*scale,1),y:round((b.y-a.y)*scale,1)};
}

/** 해당 위도·확대 수준에서 1px이 나타내는 실제 거리(m) */
export function metersPerPixel(lat:number,zoom:number){
 return round(2*Math.PI*EARTH_RADIUS*Math.cos(lat*Math.PI/180)/(TILE*2**zoom),4);
}

export function zoomForWidth(width:number){return width>0&&width<MARKET.compactWidth?MARKET.compactZoom:MARKET.zoom}

const coord=(p:LatLng)=>`${p.lat},${p.lng}`;

/**
 * 키 없이 열리는 Google 지도 위성 임베드.
 * t=k 위성, iwloc= 빈 값으로 정보창 숨김. 키가 있으면 Maps Embed API(maptype=satellite)를 쓴다.
 */
export function googleSatelliteEmbedUrl(center:LatLng=MARKET.center,zoom:number=MARKET.zoom,key?:string){
 if(key)return `https://www.google.com/maps/embed/v1/view?${new URLSearchParams({key,center:coord(center),zoom:String(zoom),maptype:'satellite',language:'ko',region:'KR'})}`;
 return `https://maps.google.com/maps?${new URLSearchParams({q:coord(center),t:'k',z:String(zoom),hl:'ko',ie:'UTF8',iwloc:'',output:'embed'})}`;
}

/** Google 지도 앱/웹에서 위성 보기로 열기 */
export function googleMapsViewUrl(center:LatLng=MARKET.center,zoom:number=MARKET.zoom){
 return `https://www.google.com/maps/@?${new URLSearchParams({api:'1',map_action:'map',center:coord(center),zoom:String(zoom),basemap:'satellite'})}`;
}

/** Google 지도 길찾기(대중교통) */
export function googleDirectionsUrl(destination:LatLng=MARKET.center){
 return `https://www.google.com/maps/dir/?${new URLSearchParams({api:'1',destination:coord(destination),travelmode:'transit'})}`;
}

/** Maps JavaScript API 스크립트 URL (브라우저 키는 HTTP 리퍼러 제한 필수) */
export function googleMapsScriptUrl(key:string,callback='__mapoGoogleMapsReady'){
 return `https://maps.googleapis.com/maps/api/js?${new URLSearchParams({key,v:'weekly',loading:'async',language:'ko',region:'KR',callback})}`;
}

/** 공개 빌드에 넣어도 되는 브라우저용 Maps 키인지 형식만 확인(빈 값·공백·자리표시자 제외) */
export function usableMapsKey(value:unknown):string|undefined{
 if(typeof value!=='string')return undefined;
 const key=value.trim();
 return /^[A-Za-z0-9_-]{20,}$/.test(key)?key:undefined;
}

function round(v:number,digits=7){const f=10**digits;return Math.round(v*f)/f}

/** OSM way38170384 main building boundary. Shop blocks remain demo positions. */
export const MARKET_FOOTPRINT:LatLng[]=[
 {lat:37.5659789,lng:126.8980599},{lat:37.5653568,lng:126.8980535},
 {lat:37.5646938,lng:126.8980467},{lat:37.5644051,lng:126.8980437},
 {lat:37.5643994,lng:126.8989295},{lat:37.5659731,lng:126.8989458},
 {lat:37.5659748,lng:126.8986868}
];
export function shopBlock(center:LatLng,width=12,height=10,angle=0):LatLng[]{
 const r=angle*Math.PI/180;
 return [[height/2,-width/2],[height/2,width/2],[-height/2,width/2],[-height/2,-width/2]].map(([n,e])=>offsetLatLng(center,{north:n*Math.cos(r)-e*Math.sin(r),east:e*Math.cos(r)+n*Math.sin(r)}));
}
/** Keep centre/pin projection consistent when the keyless Google view is panned. */
export function panCamera(center:LatLng,dx:number,dy:number,zoom:number):LatLng{
 const mpp=metersPerPixel(center.lat,zoom);
 return offsetLatLng(center,{north:dy*mpp,east:-dx*mpp});
}
export function insideFootprint(point:LatLng){
 let inside=false;
 for(let i=0,j=MARKET_FOOTPRINT.length-1;i<MARKET_FOOTPRINT.length;j=i++){
  const a=MARKET_FOOTPRINT[i],b=MARKET_FOOTPRINT[j];
  if((a.lat>point.lat)!==(b.lat>point.lat)&&point.lng<(b.lng-a.lng)*(point.lat-a.lat)/(b.lat-a.lat)+a.lng)inside=!inside;
 }
 return inside;
}
