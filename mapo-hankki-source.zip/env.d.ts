// Vite가 빌드 시 주입하는 공개 환경변수 (브라우저에 노출됨 — 서버 비밀값 금지)
interface ImportMetaEnv{readonly VITE_GOOGLE_MAPS_API_KEY?:string}
interface ImportMeta{readonly env:ImportMetaEnv}
