import {sqliteTable,text,integer} from "drizzle-orm/sqlite-core";
export const catalogState=sqliteTable("catalog_state",{id:text("id").primaryKey(),revision:integer("revision").notNull(),data:text("data").notNull()});
export const orders=sqliteTable("orders",{id:text("id").primaryKey(),createdAt:text("created_at").notNull(),data:text("data").notNull()});
export const plans=sqliteTable('plans',{id:text('id').primaryKey(),createdAt:text('created_at').notNull(),data:text('data').notNull()});
