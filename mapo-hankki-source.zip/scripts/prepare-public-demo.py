from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json, re, shutil
root = Path(__file__).resolve().parents[1]
built = root / "docs"
out = root / "outputs" / "github-publish"
out.mkdir(parents=True, exist_ok=True)
base = "/traditional-market-ai-contest/"
html = (built / "index.html").read_text()
assets = re.findall(r'(?:src|href)="' + re.escape(base) + r'assets/([^"]+)"', html)
for name in assets:
    src = built / "assets" / name
    text = src.read_text()
    if src.suffix == ".js":
        text = text.replace("/images/jeongol.webp", "/jeongol.webp").replace("/images/logo-horizontal.png", "/logo-horizontal.png").replace("/images/logo-icon.png", "/logo-icon.png")
    (out / name).write_text(text)
html = html.replace(base + "assets/", base)
(out / "index.html").write_text(html)
for name in ["jeongol.webp", "logo-horizontal.png", "logo-icon.png"]:
    shutil.copy2(root / "public" / "images" / name, out / name)
# Reuse the already published source manifest, replacing entries from current source.
archive = out / "mapo-hankki-source.zip"
with ZipFile(archive) as old:
    old_data = {i.filename: old.read(i.filename) for i in old.infolist() if not i.is_dir()}
    names = list(old_data)
names += ["public/images/logo-horizontal.png", "public/images/logo-icon.png", "scripts/prepare-public-demo.py", "vendor/lucide-selected.mjs"]
names = sorted(set(names))
new = out / "mapo-hankki-source.new.zip"
with ZipFile(new, "w", ZIP_DEFLATED) as z:
    for name in names:
        path = root / name
        if path.is_file():
            if any(part in {".git", "node_modules", ".next", ".wrangler", "outputs"} for part in path.parts):
                raise RuntimeError("Unexpected source entry: " + name)
            if path.name.startswith(".env") and path.name != ".env.example":
                raise RuntimeError("Private environment entry: " + name)
            if name in {"app/page.tsx", "app/globals.css", "app/layout.tsx", "components/ui/dialog.tsx", "static/index.html", "vite.pages.config.ts", "package.json", "package-lock.json", "public/images/logo-horizontal.png", "public/images/logo-icon.png", "scripts/prepare-public-demo.py", "vendor/lucide-selected.mjs"} or name not in old_data:
                z.write(path, name)
            else:
                z.writestr(name, old_data[name])
with ZipFile(new) as z:
    assert z.testzip() is None
    assert "app/page.tsx" in z.namelist()
    assert "public/images/logo-horizontal.png" in z.namelist()
new.replace(archive)
files = [out / "index.html", *[out / n for n in assets], *[out / n for n in ["logo-horizontal.png", "logo-icon.png", "jeongol.webp", "mapo-hankki-source.zip", "README.md"]]]
(root / "outputs" / "github-publish-manifest.json").write_text(json.dumps([str(p) for p in files], ensure_ascii=False))
for p in files:
    assert p.stat().st_size > 0
    print(p.name, p.stat().st_size)
