"""Package the current build and complete source without private runtime data."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json
import shutil
import subprocess
import argparse
from hashlib import sha1
root = Path(__file__).resolve().parents[1]
out = root / "outputs" / "github-publish"
out.mkdir(parents=True, exist_ok=True)
source_files = subprocess.check_output(["git", "ls-files", "-co", "--exclude-standard", "-z"], cwd=root).decode().split("\0")
blocked = {".git", "node_modules", ".next", ".vinext", ".wrangler", ".local-data", ".sites-runtime", ".openai", ".agents", ".codex", "work", "outputs", "output", "dist", "coverage"}
files = []
for name in sorted(set(source_files)):
    path = root / name
    if name == "mapo-hankki-source.zip":
        continue
    if not name or not path.is_file() or path.is_symlink():
        continue
    if any(part in blocked for part in Path(name).parts):
        continue
    if path.name.startswith(".env") and path.name != ".env.example":
        continue
    if path.suffix in {".pem", ".tsbuildinfo"}:
        continue
    files.append(name)
archive = out / "mapo-hankki-source.zip"
changed = {entry[3:] for entry in subprocess.check_output(
    ["git", "status", "--porcelain", "-z", "--untracked-files=no"], cwd=root
).decode().split("\0") if entry}
parser = argparse.ArgumentParser()
parser.add_argument("--source-cache", type=Path)
args = parser.parse_args()
contents = {}
if args.source_cache:
    indexed = subprocess.check_output(["git", "ls-files", "-s", "-z"], cwd=root).decode().split("\0")
    hashes = {entry.split("\t", 1)[1]: entry.split()[1] for entry in indexed if entry}
    with ZipFile(args.source_cache) as cache:
        for name in files:
            if name in changed or name not in hashes or name not in cache.namelist():
                continue
            data = cache.read(name)
            # Cache data is usable only when identical to the current Git blob.
            digest = sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
            if digest == hashes[name]:
                contents[name] = data
with ZipFile(archive, "w", ZIP_DEFLATED) as zipped:
    for name in files:
        if name in contents:
            zipped.writestr(name, contents[name])
        else:
            zipped.write(root / name, name)
with ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    assert "lib/ai.ts" in zipped.namelist()
    assert "scripts/local-server.mjs" in zipped.namelist()
    assert len([n for n in zipped.namelist() if n.startswith("public/images/recipes/") and n.endswith(".webp")]) == 9
built = root / "docs"
assert (built / "index.html").is_file(), "Run npm run build:pages first"
for path in built.iterdir():
    target = out / path.name
    if path.is_dir():
        shutil.copytree(path, target, dirs_exist_ok=True)
    else:
        shutil.copy2(path, target)
(out / ".nojekyll").touch()
shutil.copy2(root / "README.md", out / "README.md")
(root / "outputs" / "github-publish-manifest.json").write_text(json.dumps({"source_files": files, "archive": str(archive)}, ensure_ascii=False, indent=2))
print(f"Packaged {len(files)} source files, 9 menu images, and current public build")
