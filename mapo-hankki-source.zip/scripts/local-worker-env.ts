import {DatabaseSync} from 'node:sqlite';
import {readFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
const directory=resolve(process.cwd(),'.local-data');
mkdirSync(directory,{recursive:true});
const sqlite=new DatabaseSync(resolve(directory,'mapo.sqlite'));
sqlite.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
const schema=readFileSync(resolve(process.cwd(),'drizzle/0000_robust_purple_man.sql'),'utf8').replace(/CREATE TABLE\s+/g,'CREATE TABLE IF NOT EXISTS ');
sqlite.exec(schema);
type Binding=string|number|bigint|null|Uint8Array;
class LocalStatement{
 constructor(private sql:string,private bindings:Binding[]=[]){ }
 bind(...bindings:Binding[]){return new LocalStatement(this.sql,bindings);}
 execute(){const result=sqlite.prepare(this.sql).run(...this.bindings);return{success:true,results:[],meta:{changes:Number(result.changes),last_row_id:Number(result.lastInsertRowid)}};}
 async run(){return this.execute();}
 async first(column?:string){const row=sqlite.prepare(this.sql).get(...this.bindings);return row?(column?row[column]:row):null;}
 async all(){const results=sqlite.prepare(this.sql).all(...this.bindings);return{success:true,results,meta:{changes:0}};}
}
const DB={
 prepare:(sql:string)=>new LocalStatement(sql),
 async batch(statements:LocalStatement[]){sqlite.exec('BEGIN IMMEDIATE');try{const results=statements.map(statement=>statement.execute());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}
};
export const env={DB,GEMINI_API_KEY:process.env.GEMINI_API_KEY,GOOGLE_API_KEY:process.env.GOOGLE_API_KEY,GEMINI_MODEL:process.env.GEMINI_MODEL};
export function closeDatabase(){sqlite.close();}
