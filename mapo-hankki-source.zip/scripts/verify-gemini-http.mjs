import {writeFileSync} from 'node:fs';
const input=Object.fromEntries(['people','meal','occasion','taste','budget','time','equipment','pantry','add','exclude','substitute','notes'].map(k=>[k,'']));
Object.assign(input,{people:'2명',pantry:'두부 300g',add:'버섯 200g',budget:'2만 원',time:'25분',equipment:'냄비'});
const r=await fetch('http://127.0.0.1:5188/api/adapt',{method:'POST',headers:{'content-type':'application/json','origin':'http://127.0.0.1:5188'},body:JSON.stringify({input,recipeId:'tofu-pot',mode:'live'})});
const body=await r.json();const result={verifiedAt:new Date().toISOString(),httpStatus:r.status,mode:body.plan?.mode,total:body.plan?.total,blocked:body.plan?.blocked,evidence:body.plan?.evidenceChecks?.map(e=>({field:e.field,status:e.status})),aiError:body.aiError,error:body.error};
writeFileSync('/Users/cutems/Documents/Codex/2026-10-01/new-chat/work/mapo-stores18/gemini-live/http-report.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));if(r.status!==200||body.plan?.mode!=='live'||body.plan?.total!==19000||body.plan?.blocked!==false)process.exitCode=1;
