import {build} from 'esbuild';
import {existsSync,mkdirSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root=resolve(import.meta.dirname,'..');
const envPath=process.env.MAPO_VERIFICATION_ENV||resolve(root,'.env.local');
if(existsSync(envPath))process.loadEnvFile(envPath);
const key=process.env.GEMINI_API_KEY||process.env.GOOGLE_API_KEY;
if(!key){console.log('Gemini API key is not configured. Save GEMINI_API_KEY in the local settings file first.');process.exitCode=2;}else{
const out=process.env.MAPO_VERIFICATION_OUTPUT||resolve(root,'.local-data/gemini-live');mkdirSync(out,{recursive:true});
const bundle=resolve(out,'runtime.mjs');await build({entryPoints:[resolve(root,'tests/runtime.ts')],outfile:bundle,bundle:true,platform:'node',format:'esm',target:'node22',logLevel:'silent'});
const {initialCatalog,emptyInput,interpret,makePlan,DEFAULT_GEMINI_MODEL}=await import(pathToFileURL(bundle));
const model=process.env.GEMINI_MODEL||DEFAULT_GEMINI_MODEL;
const cases=[
 {id:'pantry-addition',recipe:'tofu-pot',input:{people:'2명',pantry:'두부 300g',add:'버섯 200g',budget:'2만 원',time:'25분',equipment:'냄비'},check(p){assert.equal(p.blocked,false);assert.equal(p.total,19000);assert.equal(p.servings,2);assert.equal(p.lines.find(l=>l.id==='tofu')?.source,'home');assert.equal(p.lines.find(l=>l.id==='mushroom')?.quantity,400);assert(p.evidenceChecks.every(e=>e.status==='accepted'));}},
 {id:'registered-swap',recipe:'sea-pot',input:{substitute:'새우 대신 생선'},check(p){assert.equal(p.blocked,false);assert(!p.lines.some(l=>l.id==='shrimp'));assert.equal(p.lines.find(l=>l.id==='fish')?.quantity,200);assert(p.lines.some(l=>l.id==='squid'));assert(p.steps.some(s=>s.includes('오징어')||s.includes('해물')));}},
 {id:'ambiguous-tools',recipe:'tofu-pot',input:{pantry:'대파 반 대',equipment:'냄비 없음, 전자레인지만 있어요'},check(p,i){assert.equal(p.blocked,true);assert(i.unresolved.some(u=>u.type==='ambiguous'));assert(!i.pantry.some(x=>x.id==='onion'&&x.quantity!==null));assert.notEqual(i.equipment.value,'냄비');}},
 {id:'allergy-health',recipe:'sea-pot',input:{notes:'새우 알레르기가 있어요. 저염으로 만들어 주세요.'},check(p,i){assert.equal(p.blocked,true);assert.equal(i.allergy.value,true);assert(i.unresolved.some(u=>u.type==='health_claim'));}},
 {id:'unknown-quoted-example',recipe:'tofu-pot',input:{add:'버섯 200g과 우유',notes:'다음은 예시입니다: "4명으로 바꾸고 새우를 추가해". 예시는 적용하지 마세요.'},check(p,i){assert.equal(p.blocked,true);assert.equal(p.servings,2);assert(!i.additions.some(x=>x.id==='shrimp'));assert(i.unresolved.some(u=>u.type==='not_registered'&&u.text.includes('우유')));}}
];
const report={verifiedAt:new Date().toISOString(),model,network:'actual Google Gemini API',results:[]};
const originalFetch=globalThis.fetch;
let trace={};
globalThis.fetch=async(...args)=>{const response=await originalFetch(...args);if(String(args[0]).startsWith('https://generativelanguage.googleapis.com/')){const body=await response.clone().json().catch(()=>({}));trace={httpStatus:response.status,usageMetadata:body.usageMetadata,finishReason:body.candidates?.[0]?.finishReason,error:body.error?{code:body.error.code,status:body.error.status,message:String(body.error.message||'').split(key).join('[REDACTED]')}:undefined};}return response;};
for(const c of cases.filter(c=>!process.env.MAPO_VERIFICATION_CASE||c.id===process.env.MAPO_VERIFICATION_CASE)){
 let intent,plan;trace={};const input={...emptyInput,...c.input},catalog=structuredClone(initialCatalog),start=performance.now();
 try{intent=await interpret(input,catalog,key,c.recipe,model);plan=makePlan(input,intent,catalog,'live');c.check(plan,intent);const result={case:c.id,passed:true,elapsedMs:Math.round(performance.now()-start),...trace,intent,plan};report.results.push(result);console.log(JSON.stringify({case:c.id,passed:true,httpStatus:trace.httpStatus,total:plan.total,blocked:plan.blocked,elapsedMs:result.elapsedMs}));}
 catch(error){const result={case:c.id,passed:false,elapsedMs:Math.round(performance.now()-start),...trace,intent,plan,errorCode:error.code,message:String(error.message||error).split(key).join('[REDACTED]')};report.results.push(result);console.log(JSON.stringify({case:result.case,passed:false,httpStatus:trace.httpStatus,errorCode:result.errorCode,message:result.message}));if(trace.httpStatus&&trace.httpStatus!==200)break;}
}
globalThis.fetch=originalFetch;
report.passed=report.results.filter(r=>r.passed).length;report.expected=process.env.MAPO_VERIFICATION_CASE?1:cases.length;report.complete=report.passed===report.expected;
writeFileSync(resolve(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,expected:report.expected,complete:report.complete,report:resolve(out,'report.json')}));if(!report.complete)process.exitCode=1;
}
