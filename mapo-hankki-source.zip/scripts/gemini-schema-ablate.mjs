import {pathToFileURL} from 'node:url';
process.loadEnvFile('/Users/cutems/Documents/Codex/2026-10-01/new-chat/work/mapo-stores18/source/.env.local');
const key=process.env.GEMINI_API_KEY||process.env.GOOGLE_API_KEY;
const {buildIntentJsonSchema,initialCatalog}=await import(pathToFileURL('/Users/cutems/Documents/Codex/2026-10-01/new-chat/work/mapo-stores18/gemini-live/runtime.mjs'));
const full=buildIntentJsonSchema(initialCatalog);
const names=Object.keys(full.properties);
for(const group of [names.slice(0,7),names.slice(7)]){
 const schema={...full,properties:Object.fromEntries(group.map(n=>[n,full.properties[n]])),required:group};
 const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent',{method:'POST',headers:{'x-goog-api-key':key,'Content-Type':'application/json'},body:JSON.stringify({contents:[{role:'user',parts:[{text:'Return JSON matching schema. Nulls and empty arrays are preferred.'}]}],generationConfig:{maxOutputTokens:300,responseMimeType:'application/json',responseJsonSchema:schema}}),signal:AbortSignal.timeout(45000)});
 const b=await r.json();console.log(JSON.stringify({group,status:r.status,error:b.error?.message?.split(key).join('[REDACTED]'),finish:b.candidates?.[0]?.finishReason}));
}
