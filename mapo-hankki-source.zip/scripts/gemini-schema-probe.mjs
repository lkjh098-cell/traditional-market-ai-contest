import {pathToFileURL} from 'node:url';
process.loadEnvFile('/Users/cutems/Documents/Codex/2026-10-01/new-chat/work/mapo-stores18/source/.env.local');
const key=process.env.GEMINI_API_KEY||process.env.GOOGLE_API_KEY;
const {buildIntentJsonSchema,initialCatalog}=await import(pathToFileURL('/Users/cutems/Documents/Codex/2026-10-01/new-chat/work/mapo-stores18/gemini-live/runtime.mjs'));
const tiny={type:'object',properties:{ok:{type:'boolean'}},required:['ok'],additionalProperties:false};
for(const c of [
  {name:'full-new',config:{responseFormat:{text:{mimeType:'APPLICATION_JSON',schema:buildIntentJsonSchema(initialCatalog)}}}}
]){
 const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent',{method:'POST',headers:{'x-goog-api-key':key,'Content-Type':'application/json'},body:JSON.stringify({contents:[{role:'user',parts:[{text:'Return a JSON object matching the schema. Use null where possible, empty arrays and strings.'}]}],generationConfig:{maxOutputTokens:1500,temperature:0.1,...c.config}}),signal:AbortSignal.timeout(45000)});
 const b=await r.json();console.log(JSON.stringify({probe:c.name,status:r.status,error:b.error?.message?.split(key).join('[REDACTED]'),finish:b.candidates?.[0]?.finishReason,text:b.candidates?.[0]?.content?.parts?.filter(p=>!p.thought).map(p=>p.text).join(''),usage:b.usageMetadata}));
}
