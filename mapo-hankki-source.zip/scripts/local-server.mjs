import {createServer} from 'node:http';
import {existsSync,mkdirSync,realpathSync,statSync,readFileSync} from 'node:fs';
import {resolve,dirname,extname,sep} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {build} from 'esbuild';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
process.chdir(root);
const localEnv=resolve(root,'.env.local');
if(existsSync(localEnv))process.loadEnvFile(localEnv);
const port=Number(process.env.LOCAL_PORT||5173);
if(!Number.isInteger(port)||port<1024||port>65535)throw new Error('LOCAL_PORT must be an integer between 1024 and 65535.');
mkdirSync(resolve(root,'.local-data'),{recursive:true});
const runtimePath=resolve(root,'.local-data/runtime.mjs');
await build({entryPoints:[resolve(root,'scripts/local-runtime.ts')],outfile:runtimePath,bundle:true,platform:'node',format:'esm',target:'node22',alias:{'cloudflare:workers':resolve(root,'scripts/local-worker-env.ts')},external:['node:sqlite'],logLevel:'silent'});
const {handleApi,closeDatabase}=await import(pathToFileURL(runtimePath).href);
const docs=realpathSync(resolve(root,'docs'));
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.webp':'image/webp','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.woff':'font/woff','.woff2':'font/woff2','.ico':'image/x-icon'};
const sendJson=(res,status,error)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify({error}));};
const server=createServer(async(req,res)=>{
 try{
  // Reject raw traversal before URL normalization can hide dot segments.
  const rawPath=(req.url||'/').split('?')[0];let decoded;try{decoded=decodeURIComponent(rawPath);}catch{return sendJson(res,400,'주소 형식을 확인해주세요.');}
  if(decoded.includes('\\')||decoded.includes('\0')||decoded.split('/').includes('..'))return sendJson(res,400,'지원하지 않는 파일 경로입니다.');
  const origin=`http://127.0.0.1:${port}`,url=new URL(req.url||'/',origin);
  if(url.origin!==origin)return sendJson(res,400,'로컬 주소로 다시 요청해주세요.');
  if(url.pathname.startsWith('/api/')){
   const contentLength=Number(req.headers['content-length']||0);if(contentLength>16000)return sendJson(res,413,'입력 내용이 너무 깁니다.');
   const chunks=[];let size=0;
   for await(const chunk of req){size+=chunk.length;if(size>16000)return sendJson(res,413,'입력 내용이 너무 깁니다.');chunks.push(chunk);}
   const headers=new Headers();for(const [name,value] of Object.entries(req.headers)){if(value!==undefined)headers.set(name,Array.isArray(value)?value.join(', '):value);}
   const method=req.method||'GET';const body=Buffer.concat(chunks);
   const request=new Request(url,{method,headers,...(method!=='GET'&&method!=='HEAD'?{body:body.toString('utf8')}:{} )});
   const response=await handleApi(request);res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));return;
  }
  if(req.method!=='GET'&&req.method!=='HEAD')return sendJson(res,405,'지원하지 않는 요청 방식입니다.');
  let pathname=decoded.replace(/^\/traditional-market-ai-contest(?=\/|$)/,'');
  if(pathname==='/'||pathname==='')pathname='/index.html';
  const candidate=resolve(docs,'.'+pathname);if(candidate!==docs&&!candidate.startsWith(docs+sep))return sendJson(res,404,'파일을 찾을 수 없습니다.');
  if(!existsSync(candidate)||!statSync(candidate).isFile())return sendJson(res,404,'파일을 찾을 수 없습니다.');
  const file=realpathSync(candidate);if(!file.startsWith(docs+sep))return sendJson(res,404,'파일을 찾을 수 없습니다.');
  res.writeHead(200,{'Content-Type':mime[extname(file)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?undefined:readFileSync(file));
 }catch{if(!res.headersSent)sendJson(res,500,'로컬 서비스를 처리하지 못했습니다.');else res.end();}
});
server.listen(port,'127.0.0.1',()=>console.log(`마포한끼 로컬 서비스: http://127.0.0.1:${port}/ · Gemini ${process.env.GEMINI_API_KEY||process.env.GOOGLE_API_KEY?'키 설정됨':'키 미설정'}`));
server.on('error',error=>{console.error(`로컬 포트를 열지 못했습니다 (${error.code||'unknown'}). LOCAL_PORT를 확인해주세요.`);closeDatabase();process.exitCode=1;});
let closing=false;function shutdown(){if(closing)return;closing=true;server.close(()=>{closeDatabase();process.exit(0);});server.closeIdleConnections();}
process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
