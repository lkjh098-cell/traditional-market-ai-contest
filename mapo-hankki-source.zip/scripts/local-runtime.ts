import * as catalog from '../app/api/catalog/route';
import * as adapt from '../app/api/adapt/route';
import * as orders from '../app/api/orders/route';
import * as admin from '../app/api/admin/route';
import * as workflow from '../app/api/workflow/route';
export {closeDatabase} from './local-worker-env';
const routes:Record<string,Record<string,(request:Request)=>Promise<Response>>>= {
 '/api/catalog':{GET:catalog.GET},
 '/api/adapt':{POST:adapt.POST},
 '/api/orders':{POST:orders.POST},
 '/api/admin':{POST:admin.POST},
 '/api/workflow':{GET:workflow.GET,POST:workflow.POST}
};
export async function handleApi(request:Request){const route=routes[new URL(request.url).pathname];if(!route)return Response.json({error:'지원하지 않는 요청입니다.'},{status:404});const handler=route[request.method];if(!handler)return Response.json({error:'지원하지 않는 요청 방식입니다.'},{status:405,headers:{Allow:Object.keys(route).join(', ')}});return handler(request);}
