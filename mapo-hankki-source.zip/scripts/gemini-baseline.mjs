import {readFileSync} from 'node:fs';
process.loadEnvFile('/Users/cutems/Documents/Codex/2026-10-01/new-chat/work/mapo-stores18/source/.env.local');
const key=process.env.GEMINI_API_KEY||process.env.GOOGLE_API_KEY;
console.log(JSON.stringify({keyConfigured:!!key,keyHasWhitespace:/\s/.test(key),keyLength:key.length}));
const response=await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent',{method:'POST',headers:{'x-goog-api-key':key,'Content-Type':'application/json'},body:JSON.stringify({contents:[{role:'user',parts:[{text:'Reply exactly OK.'}]}],generationConfig:{maxOutputTokens:128}}),signal:AbortSignal.timeout(45000)});
const body=await response.json();
console.log(JSON.stringify({httpStatus:response.status,error:body.error?{code:body.error.code,status:body.error.status,message:String(body.error.message).split(key).join('[REDACTED]'),details:body.error.details}:undefined,finishReason:body.candidates?.[0]?.finishReason,text:body.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join(''),usage:body.usageMetadata}));
