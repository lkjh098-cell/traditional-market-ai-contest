import {defineConfig} from 'vite';
import path from 'node:path';
export default defineConfig({root:'static',base:'/traditional-market-ai-contest/',publicDir:'../public',resolve:{alias:{'@':path.resolve(import.meta.dirname)}},build:{outDir:'../docs',emptyOutDir:true},css:{postcss:{plugins:[]}}});
