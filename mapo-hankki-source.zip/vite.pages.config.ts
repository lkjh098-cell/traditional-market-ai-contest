import {defineConfig} from 'vite';
import path from 'node:path';
export default defineConfig({root:'static',envDir:import.meta.dirname,envPrefix:'VITE_GOOGLE_MAPS_',base:'/traditional-market-ai-contest/',publicDir:'../public',resolve:{alias:{'@':path.resolve(import.meta.dirname),'lucide-react':path.resolve(import.meta.dirname,'vendor/lucide-selected.mjs')}},build:{outDir:'../docs',emptyOutDir:true},css:{postcss:{plugins:[]}}});
